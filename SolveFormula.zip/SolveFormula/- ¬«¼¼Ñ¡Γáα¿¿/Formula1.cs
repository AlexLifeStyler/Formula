﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Formula1 : MonoBehaviour {

	[HideInInspector]
	public static string [,] NameVariables1; 
	[HideInInspector]
	public static float [,] ResultVariables1; 
	[HideInInspector]
	public static int CountVariables; 
	[HideInInspector]
	public static int CountVariables2; 
	[HideInInspector]
	public static int CheckRegistr; 
	[HideInInspector]
	public static bool CleanVariables; 
	[HideInInspector]
	public static bool CleanSpaces; 
	[HideInInspector]
	public static bool ChangeMainFormula; 
	[HideInInspector]
	public static bool FindResultOnly; 





	void Start () {	

		CountVariables2 = 4; 
		CountVariables = 5; 
		NameVariables1 = new string[CountVariables+CountVariables2,4];
		ResultVariables1 = new float[CountVariables+CountVariables2,2];


		for (int i = 0; i <= (CountVariables+CountVariables2)-1; i++) {
			NameVariables1[i,0] = " ";
			NameVariables1[i,1] = " ";
			NameVariables1[i,2] = " ";
			NameVariables1[i,3] = "-";
			ResultVariables1[i,0] = 0;
			ResultVariables1[i,1] = 0;
		}

		CleanVariables = true; 
		CleanSpaces = true; 
		ChangeMainFormula = false; 
		FindResultOnly = false; 
		CheckRegistr = 0; 

		NameVariables1[0,0] = "Gg1";
		NameVariables1[0,2] = "Переменная 0"; 
		NameVariables1[0,3] = "[ Любое число , от 0 до 255 ]"; 
		ResultVariables1[0,0] = 0; 
		ResultVariables1[0,1] = 2; 
		NameVariables1[1,0] = "K+Jf";
		NameVariables1[1,2] = "Переменная 1";
		NameVariables1[1,3] = "[ Любое число , Любое число ]";
		ResultVariables1[1,0] = 0;
		ResultVariables1[1,1] = 2;
		NameVariables1[2,0] = "R";
		NameVariables1[2,2] = "Переменная 2";
		NameVariables1[2,3] = "-";
		ResultVariables1[2,0] = 255;
		ResultVariables1[2,1] = 0;
		NameVariables1[3,0] = "G";
		NameVariables1[3,2] = "Переменная 3";
		NameVariables1[3,3] = "-";
		ResultVariables1[3,0] = 127;
		ResultVariables1[3,1] = 0;
		NameVariables1[4,0] = "B";
		NameVariables1[4,2] = "Переменная 4";
		NameVariables1[4,3] = "-";
		ResultVariables1[4,0] = 0;
		ResultVariables1[4,1] = 0;






		AddVariables ();


















	}

	public static float SolveFormula (string s1 
		,out string sClean
		,out string stext 
		,out string sActions
		,out string[] sTextProperty
		,out int[,] AllSymbols1, out int CountOfSymbols1
		,out int CountOfUnActSymbols1, out int CountOfCommas1
		,out int[,] AllNumbers1, out int CountOfNumbers1
		,out int[,] AllVariables1, out int CountOfVariables1
		,out float[] AllVariables_N
		,out int[,] BracketStep, out int CountBracket, out int CountAddBracket
		,out float[] BracketStep_N
		,out string[] BracketStep_T
		,out int[,] AllActions, out int CountOfActions
		,out float[,] AllActions_N
		,out string[] AllActions_T
	) { 











































		if (s1.Length<1) s1 = " ";


		char[] Bracket_L = new[] {'(','|','[','{','('}; 
		char[] Bracket_R = new[] {')','|',']','}',')'}; 




		stext = "";
		if (CheckRegistr == 0) { 

			stext = "(" + s1 + ")"; 

		}
		else { 

			stext = "("+s1.ToUpper()+")"; 

		}



		bool BoolTryParse = false;
		int Pp0 = 0;
		int Pp1 = 0;
		int Pp2 = 0;
		int Pp3 = 0;
		string sVariable = "";

		for (int i = 0; i <= stext.Length - 1; i++) 
			sVariable = sVariable+" "; 


		char[] sVariable_c = new char[stext.Length];
		sVariable_c = sVariable.ToCharArray();
		char[] s_c = new char[stext.Length];
		s_c = stext.ToCharArray();


		for (int i = 0; i <= (CountVariables+CountVariables2) - 1; i++) {
			Pp1 = stext.IndexOf (NameVariables1 [i,CheckRegistr], 0);
			if (Pp1 > -1)
				while (Pp1 > -1) {
					for (int j = Pp1; j <= (Pp1 + NameVariables1 [i,CheckRegistr].Length - 1); j++) {
						sVariable_c [j] = ".".ToCharArray () [0];	
					}

					Pp1 = stext.IndexOf (NameVariables1 [i,CheckRegistr], Pp1 + 1);			
				}	
		}



		CountOfVariables1 = 0; 
		string sAllVariables = ";"; 
		int startnumber = -1;

		int numberv_1 = -1;
		int lengthv_1 = -1;
		string scopy_1;
		for (int i = 0; i <= stext.Length - 1; i++) {
			if (sVariable_c [i] == ".".ToCharArray () [0]) { 
				if (startnumber == -1)
					startnumber = i;


			} else {
				if (startnumber > -1) {

					scopy_1 = stext.Substring (startnumber, i - startnumber);

					lengthv_1 = -1;
					numberv_1 = -1;
					Pp1 = -1;
					Pp2 = -1;					

					for (int j = 0; j <= (CountVariables + CountVariables2) - 1; j++) {
						if (NameVariables1 [j, CheckRegistr].Length > lengthv_1) {
							Pp0 = scopy_1.IndexOf (NameVariables1 [j, CheckRegistr], 0);
							if (Pp0 > -1) {
								lengthv_1 = NameVariables1 [j, CheckRegistr].Length;
								numberv_1 = j;
								Pp1 = Pp0;
								Pp2 = lengthv_1 + Pp0 - 1;
							}
						}
					}

					if (lengthv_1 > -1) { 
						CountOfVariables1 = CountOfVariables1 + 1;

						sAllVariables = sAllVariables
							+ numberv_1.ToString ()
							+ "|" + (startnumber + Pp1).ToString ()
							+ "-" + (startnumber + Pp2).ToString () + ";";



					}



					if (CleanVariables == true) { 



						if (numberv_1 > -1) { 

							if (Pp1 - 1 > -1) {

								for (int j = startnumber; j <= (startnumber + Pp1 - 1); j++) {
									s_c [j] = " ".ToCharArray () [0];
									sVariable_c [j] = " ".ToCharArray () [0];
								}
							}

							if (scopy_1.Length - (Pp2 + 1) > 0) {

								for (int j = (startnumber + (Pp2 + 1)); j <= (startnumber + (scopy_1.Length - 1)); j++) {
									s_c [j] = " ".ToCharArray () [0];
									sVariable_c [j] = " ".ToCharArray () [0];	
								}
							}
						} else { 

							for (int j = startnumber; j <= startnumber + (scopy_1.Length - 1); j++) {
								s_c [j] = " ".ToCharArray () [0];
								sVariable_c [j] = " ".ToCharArray () [0];	
							}
						}

					}

					startnumber = -1;
				}
			}			
		}
		stext = new string(s_c); 
		sClean = stext.Substring (1, stext.Length-2);





		BoolTryParse = false;
		Pp0 = 0;
		Pp1 = 0;
		Pp2 = 0;
		Pp3 = 0;

		AllVariables1 = new int[CountOfVariables1,9]; 

		AllVariables_N = new float[CountOfVariables1]; 
		for (int i = 0; i <= CountOfVariables1 - 1; i++) {
			Pp0 = sAllVariables.IndexOf (";", Pp3);	
			Pp1 = sAllVariables.IndexOf ("|", Pp0);	
			Pp2 = sAllVariables.IndexOf ("-", Pp1);	
			Pp3 = sAllVariables.IndexOf (";", Pp2);	
			if ((Pp0 > -1) & (Pp1 > -1) & (Pp2 > -1) & (Pp3 > -1)) {			



				BoolTryParse = int.TryParse (sAllVariables.Substring (Pp1 + 1, Pp2 - Pp1 - 1), out AllVariables1 [i, 0]); 
				if (BoolTryParse == false)
					AllVariables1 [i, 0] = -1;
				BoolTryParse = int.TryParse (sAllVariables.Substring (Pp2 + 1, Pp3 - Pp2 - 1), out AllVariables1 [i, 1]); 
				if (BoolTryParse == false)
					AllVariables1 [i, 1] = -1;
				AllVariables1 [i, 2] = -1;
				AllVariables1 [i, 3] = -1;
				AllVariables1 [i, 4] = -1;
				BoolTryParse = int.TryParse (sAllVariables.Substring (Pp0 + 1, Pp1 - Pp0 - 1), out AllVariables1 [i, 5]); 
				if (BoolTryParse == false)
					AllVariables1 [i, 5] = -1;
				AllVariables1 [i, 6] = AllVariables1 [i, 0]; 
				AllVariables1 [i, 7] = AllVariables1 [i, 1]; 
				AllVariables1 [i, 8] = -1; 
			} else {
				AllVariables1 [i, 0] = -1;
				AllVariables1 [i, 1] = -1;
				AllVariables1 [i, 2] = -1;
				AllVariables1 [i, 3] = -1;
				AllVariables1 [i, 4] = -1;
				AllVariables1 [i, 5] = -1; 
				AllVariables1 [i, 6] = -1; 
				AllVariables1 [i, 7] = -1; 
				AllVariables1 [i, 8] = -1; 
			}
		}		








		CountOfNumbers1 = 0; 
		int countnumber = 0;
		int textnumber1,lastnumber1;
		BoolTryParse = false;
		startnumber = -1;
		lastnumber1 = 0;
		string sAllNumbers = ";"; 
		for (int i = 0; i <= stext.Length - 1; i++) {
			if (sVariable_c [i] != ".".ToCharArray () [0]) {			

				BoolTryParse = int.TryParse (stext [i].ToString (), out textnumber1); 
				if (BoolTryParse == false)
					textnumber1 = -1;
				if (textnumber1 > -1) { 
					sVariable_c [i] = "№".ToCharArray () [0];	
					lastnumber1 = i;
					if (startnumber == -1)
						startnumber = i;
					countnumber = countnumber + 1;
				} else if ((lastnumber1 == i - 1) &
					(stext [i] == ".".ToCharArray () [0])) {					
					sVariable_c [i] = "№".ToCharArray () [0];
					if (startnumber == -1)
						startnumber = i;
					countnumber = countnumber + 1;
				} else {
					if (countnumber > 0) {
						sAllNumbers = sAllNumbers
							+ startnumber.ToString ()
							+ "-" + (startnumber + countnumber - 1).ToString () + ";";
						CountOfNumbers1 = CountOfNumbers1 + 1; 
					}
					countnumber = 0;
					startnumber = -1;
				}
			} else {
				if (countnumber > 0) {
					sAllNumbers = sAllNumbers
						+ startnumber.ToString ()
						+ "-" + (startnumber + countnumber - 1).ToString () + ";";
					CountOfNumbers1 = CountOfNumbers1 + 1; 
				}
				countnumber = 0;
				startnumber = -1;
			}
		}			




		BoolTryParse = false;
		Pp0 = 0;
		Pp1 = 0;
		Pp2 = 0;

		AllNumbers1 = new int[CountOfNumbers1,6]; 
		float[] AllNumbers_N = new float[CountOfNumbers1]; 
		for (int i = 0; i <= CountOfNumbers1 - 1; i++) {
			Pp0 = sAllNumbers.IndexOf (";", Pp2);	
			Pp1 = sAllNumbers.IndexOf ("-", Pp0);	
			Pp2 = sAllNumbers.IndexOf (";", Pp1);	
			if ((Pp0 > -1) & (Pp1 > -1) & (Pp2 > -1)) {			



				BoolTryParse = int.TryParse (sAllNumbers.Substring (Pp0+1, Pp1 - Pp0-1), out AllNumbers1 [i, 0]); 
				if (BoolTryParse == false)	AllNumbers1 [i, 0] = -1;
				BoolTryParse = int.TryParse (sAllNumbers.Substring (Pp1+1, Pp2 - Pp1-1), out AllNumbers1 [i, 1]); 
				if (BoolTryParse == false)	AllNumbers1 [i, 1] = -1;
				if ((AllNumbers1 [i, 0]>-1) & (AllNumbers1 [i, 1]>-1)) { 

					float.TryParse (stext.Substring (AllNumbers1 [i, 0], AllNumbers1 [i, 1] - AllNumbers1 [i, 0]+1), out AllNumbers_N [i]); 

				}

				AllNumbers1 [i, 2] = -1;
				AllNumbers1 [i, 3] = -1;
				AllNumbers1 [i, 4] = AllNumbers1 [i, 0]; 
				AllNumbers1 [i, 5] = AllNumbers1 [i, 1]; 
			} else {
				AllNumbers1 [i, 0] = -1;
				AllNumbers1 [i, 1] = -1;
				AllNumbers1 [i, 2] = -1;
				AllNumbers1 [i, 3] = -1;
				AllNumbers1 [i, 4] = -1;
				AllNumbers1 [i, 5] = -1;
			}
		}



		char[] Symbols = new[] {'+','-','*','/','^',','}; 

		CountOfSymbols1 = 0; 

		CountOfCommas1 = 0; 
		int CountBracketPlus = 0; 
		for (int i = 0; i <= stext.Length - 1; i++) {

			if (sVariable_c [i] != ".".ToCharArray () [0]) { 
				for (int j = 0; j <= Symbols.Length - 1; j++) {	
					if (stext [i] == Symbols [j]) { 
						if (j > 1) 
							CountBracketPlus = CountBracketPlus + 1; 
						if (j != 5) 
							sVariable_c [i] = "+".ToCharArray () [0];
						else { 
							sVariable_c [i] = ",".ToCharArray () [0];
							CountOfCommas1 = CountOfCommas1+1; 
							CountBracketPlus = CountBracketPlus + 2; 
						}
						CountOfSymbols1 = CountOfSymbols1 + 1;
						break;
					}				
				}
			}
		}	

		int[,] CommasInText = new int[CountOfCommas1,2]; 
		if (CountOfCommas1 > 0) {
			CountOfCommas1 = 0; 
			for (int i = 0; i <= stext.Length - 1; i++) {
				if (sVariable_c [i] == Symbols [5]) { 
					CommasInText [CountOfCommas1, 0] = i; 
					CommasInText [CountOfCommas1, 1] = i; 
					CountOfCommas1 = CountOfCommas1 + 1; 
				}				
			}
		}






		int[,] Bracket3 = new int[stext.Length,5]; 
		int CountBracket3 = 0;
		int[,] CountOfjBrackets = new int[4,2]; 
		int LastModuleBracketPos = 0;

		for (int k1 = 0; k1 <= 3; k1++) {	
			for (int k2 = 0; k2 <= 1; k2++) {	
				CountOfjBrackets [k1, k2] = 0; 
			}
		}

		for (int i = 0; i <= stext.Length - 1; i++) {
			if (sVariable_c [i] == " ".ToCharArray () [0]) { 
				for (int j = 0; j <= 3; j++) {	
					if (stext [i] == Bracket_L [j]) { 
						Bracket3 [CountBracket3, 0] = i; 
						Bracket3 [CountBracket3, 1] = j; 

						CountOfjBrackets[j,0] = CountOfjBrackets[j,0]+1; 
						if (j == 1) {
							LastModuleBracketPos = CountBracket3;
						}

						Bracket3 [CountBracket3, 2] = 0; 
						sVariable_c [i] = "(".ToCharArray () [0];
						CountBracket3 = CountBracket3 + 1;
						break;
					} else if (stext [i] == Bracket_R [j]) { 
						Bracket3 [CountBracket3, 0] = i; 
						Bracket3 [CountBracket3, 1] = j; 

						CountOfjBrackets[j,1] = CountOfjBrackets[j,1]+1; 
						if (j == 1) {
							LastModuleBracketPos = CountBracket3;
						}

						Bracket3 [CountBracket3, 2] = 1; 
						sVariable_c [i] = "(".ToCharArray () [0];
						CountBracket3 = CountBracket3 + 1;			
						break;
					}					
				}
			}
		}








		s_c = new char[stext.Length];
		s_c = stext.ToCharArray();

		float CountModulHalf = 0;
		int OddCountOfBrackets = 0; 
		int LRBrackets1 = 0;
		int CheckCountBracket3 = CountBracket3;
		int searchpos1 = 0;
		int searchpos2 = 0;

		for (int k1 = 0; k1 <= 3; k1++) {
			if (k1 != 1) { 
				LRBrackets1 = CountOfjBrackets [k1, 0] - CountOfjBrackets [k1, 1];		

				if (LRBrackets1 > 0) { 
					searchpos1 = stext.Length - 1;
					searchpos2 = CountBracket3 - 1;

					while (LRBrackets1 != 0) {
						while (searchpos1 >= 0) {
							if ((sVariable_c [searchpos1] == "(".ToCharArray () [0]) &
								(s_c [searchpos1] == Bracket_L [k1])) { 
								s_c [searchpos1] = " ".ToCharArray () [0];
								sVariable_c [searchpos1] = " ".ToCharArray () [0];

								for (int k2 = searchpos2; k2 >= 0; k2--) { 
									if (Bracket3 [k2, 0] == searchpos1) {
										Bracket3 [k2, 0] = -1; 
										Bracket3 [k2, 1] = -1; 
										Bracket3 [k2, 2] = -1; 
										CheckCountBracket3 = CheckCountBracket3-1;
										searchpos2 = k2-1;
									}
								}
								LRBrackets1 = LRBrackets1 - 1;
								if (LRBrackets1 <= 0) {
									break;
								}
							}
							searchpos1 = searchpos1 - 1;
						}
					}
				} else if (LRBrackets1 < 0) { 

					while (LRBrackets1 != 0) {
						while (searchpos1 <= stext.Length - 1) {
							if ((sVariable_c [searchpos1] == "(".ToCharArray () [0]) &
								(s_c [searchpos1] == Bracket_R [k1])) { 
								s_c [searchpos1] = " ".ToCharArray () [0];
								sVariable_c [searchpos1] = " ".ToCharArray () [0];

								for (int k2 = searchpos2; k2 <= CountBracket3 - 1; k2++) { 
									if (Bracket3 [k2, 0] == searchpos1) {
										Bracket3 [k2, 0] = -1; 
										Bracket3 [k2, 1] = -1; 
										Bracket3 [k2, 2] = -1; 
										CheckCountBracket3 = CheckCountBracket3-1;
										searchpos2 = k2+1;
									}
								}
								LRBrackets1 = LRBrackets1 + 1;
								if (LRBrackets1 >= 0) {
									break;
								}
							}
							searchpos1 = searchpos1 + 1;
						}
					}
				}	
			} else { 
				CountModulHalf = (CountOfjBrackets [k1, 0] + CountOfjBrackets [k1, 1]) / 2f;
				OddCountOfBrackets = Mathf.CeilToInt (CountModulHalf - Mathf.FloorToInt (CountModulHalf)); 

				if (OddCountOfBrackets > 0) { 
					s_c [Bracket3 [LastModuleBracketPos, 0]] = " ".ToCharArray () [0];
					sVariable_c [Bracket3 [LastModuleBracketPos, 0]] = " ".ToCharArray () [0];

					Bracket3 [LastModuleBracketPos, 0] = -1; 
					Bracket3 [LastModuleBracketPos, 1] = -1; 
					Bracket3 [LastModuleBracketPos, 2] = -1; 

					CheckCountBracket3 = CheckCountBracket3-1;
				}
			}				
		}



		if (CountBracket3 > 0) {
			bool foundnot_1 = false;
			int i1 = 0;
			while (i1 < CountBracket3) {
				if (Bracket3 [i1, 0] == -1) {
					if (i1 < CountBracket3 - 1) {
						for (int j = i1; j < CountBracket3 - 1; j++) {
							Bracket3 [j, 0] = Bracket3 [j + 1, 0]; 
							Bracket3 [j, 1] = Bracket3 [j + 1, 1]; 
							Bracket3 [j, 2] = Bracket3 [j + 1, 2]; 
							if (Bracket3 [j, 0] > -1) {
								foundnot_1 = true;
							}
						}
					}
					if ((foundnot_1 == true) & (Bracket3 [i1, 0] == -1)) {				
						i1 = i1 - 1;
					}
				}
				i1 = i1 + 1;
			}		
		}

		CountBracket3 = CheckCountBracket3;






		int CountOpenBracket = 0;
		int CountCloseBracket = 0;

		for (int k1 = 0; k1 <= 3; k1++) {
			if (k1 != 1) { 
				CountOpenBracket = 0;
				CountCloseBracket = 0;


				for (int i2 = 0; i2 <= CountBracket3 - 1; i2++) {
					if (Bracket3 [i2, 1] == k1) { 

						if (Bracket3 [i2, 2] == 0) { 
							CountOpenBracket = CountOpenBracket + 1;
						} else { 
							CountCloseBracket = CountCloseBracket + 1;
						}
						if (CountOpenBracket < CountCloseBracket) { 
							s_c [Bracket3 [i2, 0]] = Bracket_L [k1]; 




							Bracket3 [i2, 2] = 0; 

							CountOpenBracket = CountOpenBracket + 1;
							CountCloseBracket = CountCloseBracket - 1;
						}
					}
				}


				for (int i2 = CountBracket3 - 1; i2 >= 0; i2--) {
					if (Bracket3 [i2, 1] == k1) { 

						if (Bracket3 [i2, 2] == 1) { 
							CountOpenBracket = CountOpenBracket + 1;
						} else { 
							CountCloseBracket = CountCloseBracket + 1;
						}
						if (CountOpenBracket > CountCloseBracket) { 
							s_c [Bracket3 [i2, 0]] = Bracket_R [k1]; 




							Bracket3 [i2, 2] = 1; 

							CountOpenBracket = CountOpenBracket - 1;
							CountCloseBracket = CountCloseBracket + 1;
						}
					}
				}					
			}
		}















		int stepsymbols1 = 0;
		int stepstart1 = 0;
		int stepend1 = 0;
		bool PM_1,PM_Main;


		PM_1 = false;
		PM_Main = true; 
		Pp0 = 0;
		while (Pp0<=sVariable_c.Length - 1) {
			if (sVariable_c [Pp0] != " ".ToCharArray () [0]) { 
				if (s_c [Pp0] == Symbols [0]) { 
					stepsymbols1 = stepsymbols1 + 1;
					PM_1 = true; 
				} else if (s_c [Pp0] == Symbols [1]) { 
					stepsymbols1 = stepsymbols1 + 1;
					PM_1 = false; 
				} else {
					if (stepsymbols1 > 1) { 
						for (int i = stepstart1; i <= stepend1; i++) {
							s_c [i] = " ".ToCharArray () [0];
							sVariable_c [i] = " ".ToCharArray () [0];
						}

						if (PM_Main == false) { 


							s_c [stepstart1] = "-".ToCharArray () [0];
							sVariable_c [stepstart1] = "+".ToCharArray () [0];
						} else {


							s_c [stepstart1] = "+".ToCharArray () [0];
							sVariable_c [stepstart1] = "+".ToCharArray () [0];
						}
						Pp0 = stepstart1;
						CountOfSymbols1 = CountOfSymbols1-(stepsymbols1-1);
					}
					stepsymbols1 = 0;
				}

				if (stepsymbols1 > 0) { 
					if (stepsymbols1 == 1) {
						stepstart1 = Pp0;
						PM_Main = true; 
					}
					stepend1 = Pp0;
					if (PM_1 == false) { 
						if (PM_Main == true)
							PM_Main = false;
						else
							PM_Main = true;
					}
				}
			}
			Pp0 = Pp0 + 1;
		}	


		stext = new string(s_c); 
		sVariable = new string(sVariable_c); 




		BoolTryParse = false;

		AllSymbols1 = new int[CountOfSymbols1,4]; 

		for (int i = 0; i <= CountOfSymbols1 - 1; i++) { 
			AllSymbols1 [i, 0] = -1; 
			AllSymbols1 [i, 1] = -1; 
			AllSymbols1 [i, 2] = -1; 
			AllSymbols1 [i, 3] = -1; 
		}

		int countsymbol = 0;
		for (int i = 0; i <= sVariable_c.Length - 1; i++) {
			if (sVariable_c [i] == Symbols [0]) { 
				AllSymbols1 [countsymbol, 0] = i; 
				AllSymbols1 [countsymbol, 3] = i; 
				for (int j = 0; j <= Symbols.Length-1; j++) {
					if (s_c [i] == Symbols [j]) { 
						AllSymbols1 [countsymbol, 1] = j; 



					}
				}
				AllSymbols1 [countsymbol, 2] = 0; 





				countsymbol = countsymbol + 1;
			}				
		}





















		int CountBracket2_2 = Mathf.CeilToInt(CountBracket3/2);
		int[,] BracketStep2 = new int[CountBracket2_2+CountBracketPlus+1,12]; 
		int[,] Bracket3_r = new int[CountBracket2_2,2]; 
		for (int i = 0; i <= CountBracket2_2 - 1; i++) { 
			Bracket3_r [i,0] = -1; 
			Bracket3_r [i,1] = -1; 
		}		
		for (int i = 0; i <= (CountBracket2_2+CountBracketPlus) - 1; i++) { 
			BracketStep2 [i, 5] = -1; 
			BracketStep2 [i, 6] = -1; 
			BracketStep2 [i, 7] = -1; 
			BracketStep2 [i, 8] = 0; 
			BracketStep2 [i, 9] = -1; 
			BracketStep2 [i, 10] = -1; 
			BracketStep2 [i, 11] = -1; 
		}		
		int CountBracket2 = 0;
		for (int i = 0; i <= CountBracket3 - 1; i++) {
			if ((Bracket3 [i, 2] == 1) & (Bracket3 [i, 1] != 1)) { 
				for (int j = i; j >= 0; j--) {			
					if ((Bracket3 [j, 2] == 0) &
						(Bracket3 [j, 1] == Bracket3 [i, 1]) &
						(Bracket3 [j, 3] != 1)) { 
						Bracket3 [j, 3] = 1; 
						Bracket3 [i, 3] = 1; 
						Bracket3 [j, 4] = CountBracket2; 
						Bracket3 [i, 4] = CountBracket2; 
						Bracket3_r [CountBracket2, 0] = j; 
						Bracket3_r [CountBracket2, 1] = i; 
						BracketStep2 [CountBracket2, 0] = Bracket3 [j, 0]; 
						BracketStep2 [CountBracket2, 1] = Bracket3 [i, 0]; 
						BracketStep2 [CountBracket2, 10] = Bracket3 [j, 0]; 
						BracketStep2 [CountBracket2, 11] = Bracket3 [i, 0]; 
						BracketStep2 [CountBracket2, 2] = Bracket3 [j, 1]; 
						BracketStep2 [CountBracket2, 3] = j; 
						BracketStep2 [CountBracket2, 4] = i; 





						CountBracket2 = CountBracket2 + 1;			
						break;
					}
				}
			} else {
				if (Bracket3 [i, 1] == 1) { 
					Bracket3 [i, 4] = CountBracket2; 
				}
			}
		}






		if (CleanVariables == true) { 
			for (int i = 0; i <= stext.Length - 1; i++) {
				if ((sVariable_c [i] == " ".ToCharArray () [0]) &
					(s_c [i] != " ".ToCharArray () [0])) { 
					s_c [i] = " ".ToCharArray () [0];
				}
			}

			stext = new string (s_c); 
			sClean = stext.Substring (1, stext.Length - 2);
		}







		int leftOk1 = 0; 
		int rightOk1 = 0; 
		if (CountOfNumbers1 > 0) {
			for (int i = 0; i <= CountOfNumbers1 - 1; i++) {
				if ((AllNumbers1 [i, 0] > -1) & (AllNumbers1 [i, 1] > -1)) {

					for (int j = AllNumbers1 [i, 0] - 1; j >= 0; j--) {
						if (sVariable_c [j] != " ".ToCharArray () [0]) {
							if (sVariable_c [j] == Bracket_L [0]) {
								for (int k = 0; k <= Bracket_L.Length - 1; k++) {
									if (s_c [j] == Bracket_L [k]) {
										leftOk1 = 1; 
										break;
									}
								}

							} else if (sVariable_c [j] == Symbols [0]) 								
							{

								leftOk1 = 2; 
							} else if (sVariable_c [j] == Symbols [5]) 								
							{

								leftOk1 = 3; 
							}
							break;
						}
					}
					if (leftOk1 > 0) {

						for (int j = AllNumbers1 [i, 1] + 1; j <= stext.Length - 1; j++) {
							if (sVariable_c [j] != " ".ToCharArray () [0]) {
								if (sVariable_c [j] == Bracket_L [0]) {
									for (int k = 0; k <= Bracket_R.Length - 1; k++) {
										if (s_c [j] == Bracket_R [k]) {
											rightOk1 = 1; 
											break;
										}
									}

								} else if ((sVariable_c [j] == Symbols [0]) 
								) {

									rightOk1 = 2; 
								} else if (sVariable_c [j] == Symbols [5]) {
									rightOk1 = 3; 
								}
								break;
							}
						}
					}
					if ((leftOk1 == 0) | (rightOk1 == 0)) { 
						for (int j = AllNumbers1 [i, 0]; j <= AllNumbers1 [i, 1]; j++) {
							sVariable_c [j] = " ".ToCharArray () [0];
							if (CleanVariables == true) { 
								s_c [j] = " ".ToCharArray () [0];					
							}
						}

						AllNumbers1 [i, 0] = -1;
						AllNumbers1 [i, 1] = -1;
						AllNumbers1 [i, 2] = -1;
						AllNumbers1 [i, 3] = -1;
						AllNumbers1 [i, 4] = -1;
						AllNumbers1 [i, 5] = -1;
					}
					leftOk1 = 0;
					rightOk1 = 0;	
				}
			}
		}	












		leftOk1 = 0; 
		rightOk1 = 0; 
		if (CountOfVariables1 > 0) {
			for (int i = 0; i <= CountOfVariables1 - 1; i++) {
				if ((AllVariables1 [i, 0] > -1) & (AllVariables1 [i, 1] > -1)) {

					for (int j = AllVariables1 [i, 0] - 1; j >= 0; j--) {
						if (sVariable_c [j] != " ".ToCharArray () [0]) {
							if (sVariable_c [j] == Bracket_L [0]) {
								for (int k = 0; k <= Bracket_L.Length - 1; k++) {
									if (s_c [j] == Bracket_L [k]) {
										leftOk1 = 1; 
										break;
									}
								}

							} else if (sVariable_c [j] == Symbols [0]) 								
							{

								leftOk1 = 2; 
							} else if (sVariable_c [j] == Symbols [5]) 								
							{

								leftOk1 = 3; 
							}
							break;
						}
					}
					if (leftOk1 > 0) {

						for (int j = AllVariables1 [i, 1] + 1; j <= stext.Length - 1; j++) {
							if (sVariable_c [j] != " ".ToCharArray () [0]) {
								if (sVariable_c [j] == Bracket_L [0]) {
									for (int k = 0; k <= Bracket_L.Length - 1; k++) {
										if (s_c [j] == Bracket_L [k]) {
											rightOk1 = 1; 
											break;
										}
									}
									if (rightOk1 == 0) {
										for (int k = 0; k <= Bracket_R.Length - 1; k++) {
											if (s_c [j] == Bracket_R [k]) {
												rightOk1 = 2; 
												break;
											}
										}
									}
								} else if ((sVariable_c [j] == Symbols [0]) 
								) {

									rightOk1 = 3; 
								} else if (sVariable_c [j] == Symbols [5]) {

									rightOk1 = 4; 
								}
								break;
							}
						}
					}
					if ((leftOk1 == 0) | (rightOk1 == 0)) { 


						for (int j = AllVariables1 [i, 0]; j <= AllVariables1 [i, 1]; j++) {
							sVariable_c [j] = " ".ToCharArray () [0];
							if (CleanVariables == true) { 
								s_c [j] = " ".ToCharArray () [0];					
							}
						}


					}
					leftOk1 = 0;
					rightOk1 = 0;	
				}
			}
		}

		stext = new string (s_c); 
		sClean = stext.Substring (1, stext.Length - 2);
		sVariable = new string(sVariable_c);
		string sCleanVariable = sVariable.Substring (1, sVariable.Length - 2);





		int CountBracket2_3 = CountBracket2;
		int CountBadModul_1 = 0;
		int CountBadModul_2 = 0;
		int CurrentNum_1 = 0;
		char[] Symbols2 = new[] {' ','+','-','.','№','('}; 
		string sModule = new string(sVariable_c);
		char[] sModule_c = new char[sModule.Length];
		sModule_c = sModule.ToCharArray();

		for (int i = 0; i <= CountBracket2_2 - 1; i++) {		
			if (BracketStep2 [i, 3] != BracketStep2 [i, 4]) { 



				int CountOfBrackets1 = BracketStep2 [i, 4]-BracketStep2 [i, 3];
				int[] NumberOfModule = new int[CountOfBrackets1];

				int ModulesInRange = 0;
				if (CountOfBrackets1 > 0) {
					float CountModulHalf1 = CountOfBrackets1 / 2f;
					OddCountOfBrackets = Mathf.CeilToInt (CountModulHalf1 - Mathf.FloorToInt (CountModulHalf1)); 

					int k2 = 0;
					for (int j = BracketStep2 [i, 3]; j <= BracketStep2 [i, 4]; j++) {

						if ((Bracket3 [j, 1] == 1) & (Bracket3 [j, 3] != 1)) { 
							NumberOfModule[ModulesInRange] = j;
							ModulesInRange = ModulesInRange + 1;
						}				
					}

				}

				int CountOfPairs1 = Mathf.FloorToInt(ModulesInRange/2f); 
				int CountOfPairs2 = 0; 



				CountBadModul_2 = -1;
				while (CountBadModul_1 != CountBadModul_2) { 
					CountBadModul_2 = CountBadModul_1;
					CountBadModul_1 = 0;
					for (int j = BracketStep2 [i, 3]; j <= BracketStep2 [i, 4]; j++) {	
						if ((Bracket3 [j, 1] == 1) & (Bracket3 [j, 3] != 1)) { 

							if (Bracket3 [j, 0] + 1 <= Bracket3 [BracketStep2 [i, 4], 0]) {
								for (int k = Bracket3 [j, 0] + 1; k <= Bracket3 [BracketStep2 [i, 4], 0]; k++) {	
									if (sModule_c [k] != Symbols2 [0]) { 





										if (

											(((sModule_c [k] == Symbols2 [1]) & 
												((stext [k] == Symbols2 [1]) | 
													(stext [k] == Symbols2 [2]))) | 
												(sModule_c [k] == Symbols2 [3]) | 
												(sModule_c [k] == Symbols2 [4]) | 
												(stext [k] == Bracket_L [0]) | 
												(stext [k] == Bracket_L [2]) | 
												(stext [k] == Bracket_L [3]) 
											)) { 

											if ((j + 1) <= BracketStep2 [i, 4]) {
												for (int k2 = j + 1; k2 <= BracketStep2 [i, 4]; k2++) { 
													if ((Bracket3 [k2, 1] == 1) & (Bracket3 [k2, 3] != 1)) { 
														Bracket3 [j, 3] = 1; 
														Bracket3 [k2, 3] = 1; 


														CurrentNum_1 = Bracket3 [BracketStep2 [i, 4], 4];


														for (int j2 = CountBracket2_2 - 1; j2 > CurrentNum_1; j2--) {															
															Bracket3_r [j2, 0] = Bracket3_r [j2 - 1, 0]; 
															Bracket3_r [j2, 1] = Bracket3_r [j2 - 1, 1]; 

															if (Bracket3_r [j2, 0] > -1) {
																Bracket3 [Bracket3_r [j2, 0], 4] = j2; 
																Bracket3 [Bracket3_r [j2, 1], 4] = j2; 
															}
															BracketStep2 [j2, 0] = BracketStep2 [j2 - 1, 0]; 
															BracketStep2 [j2, 1] = BracketStep2 [j2 - 1, 1]; 
															BracketStep2 [j2, 10] = BracketStep2 [j2 - 1, 0]; 
															BracketStep2 [j2, 11] = BracketStep2 [j2 - 1, 1]; 
															BracketStep2 [j2, 2] = BracketStep2 [j2 - 1, 2]; 
															BracketStep2 [j2, 3] = BracketStep2 [j2 - 1, 3]; 
															BracketStep2 [j2, 4] = BracketStep2 [j2 - 1, 4]; 
														}

														Bracket3_r [CurrentNum_1, 0] = j;  
														Bracket3_r [CurrentNum_1, 1] = k2; 
														Bracket3 [j, 4] = CurrentNum_1;   
														Bracket3 [k2, 4] = CurrentNum_1;   
														Bracket3 [j, 2] = 0; 
														Bracket3 [k2, 2] = 1; 
														BracketStep2 [CurrentNum_1, 0] = Bracket3 [j, 0]; 
														BracketStep2 [CurrentNum_1, 1] = Bracket3 [k2, 0]; 
														BracketStep2 [CurrentNum_1, 10] = Bracket3 [j, 0]; 
														BracketStep2 [CurrentNum_1, 11] = Bracket3 [k2, 0]; 
														BracketStep2 [CurrentNum_1, 2] = 1; 
														BracketStep2 [CurrentNum_1, 3] = j; 
														BracketStep2 [CurrentNum_1, 4] = k2; 

														sModule_c [Bracket3 [j, 0]] = "№".ToCharArray () [0];  
														sModule_c [Bracket3 [k2, 0]] = "№".ToCharArray () [0];





														CountBracket2_3 = CountBracket2_3 + 1;	
														CountOfPairs2 = CountOfPairs2+1; 
														break;
													}
												}
											}
										} else {
											CountBadModul_1 = CountBadModul_1 + 1;
										}
										break;
									}
								}
							}
						}
					}
				}


				if (CountOfBrackets1-OddCountOfBrackets > 0) {	

					if (CountOfPairs2 < CountOfPairs1) { 


						int j = 0;
						while (j < (CountOfBrackets1-OddCountOfBrackets)) {

							Bracket3 [NumberOfModule [j], 3] = 1; 
							Bracket3 [NumberOfModule [j + 1], 3] = 1; 


							CurrentNum_1 = Bracket3 [BracketStep2 [i, 4], 4];


							for (int j2 = CountBracket2_2 - 1; j2 > CurrentNum_1; j2--) {															
								Bracket3_r [j2, 0] = Bracket3_r [j2 - 1, 0]; 
								Bracket3_r [j2, 1] = Bracket3_r [j2 - 1, 1]; 

								if (Bracket3_r [j2, 0] > -1) {
									Bracket3 [Bracket3_r [j2, 0], 4] = j2; 
									Bracket3 [Bracket3_r [j2, 1], 4] = j2; 
								}
								BracketStep2 [j2, 0] = BracketStep2 [j2 - 1, 0]; 
								BracketStep2 [j2, 1] = BracketStep2 [j2 - 1, 1]; 
								BracketStep2 [j2, 10] = BracketStep2 [j2 - 1, 0]; 
								BracketStep2 [j2, 11] = BracketStep2 [j2 - 1, 1]; 
								BracketStep2 [j2, 2] = BracketStep2 [j2 - 1, 2]; 
								BracketStep2 [j2, 3] = BracketStep2 [j2 - 1, 3]; 
								BracketStep2 [j2, 4] = BracketStep2 [j2 - 1, 4]; 
							}

							Bracket3_r [CurrentNum_1, 0] = NumberOfModule [j];  
							Bracket3_r [CurrentNum_1, 1] = NumberOfModule [j + 1]; 
							Bracket3 [NumberOfModule [j], 4] = CurrentNum_1;   
							Bracket3 [NumberOfModule [j + 1], 4] = CurrentNum_1;   
							Bracket3 [NumberOfModule [j], 2] = 0; 
							Bracket3 [NumberOfModule [j + 1], 2] = 1; 
							BracketStep2 [CurrentNum_1, 0] = Bracket3 [NumberOfModule [j], 0]; 
							BracketStep2 [CurrentNum_1, 1] = Bracket3 [NumberOfModule [j + 1], 0]; 
							BracketStep2 [CurrentNum_1, 10] = Bracket3 [NumberOfModule [j], 0]; 
							BracketStep2 [CurrentNum_1, 11] = Bracket3 [NumberOfModule [j + 1], 0]; 
							BracketStep2 [CurrentNum_1, 2] = 1; 
							BracketStep2 [CurrentNum_1, 3] = NumberOfModule [j]; 
							BracketStep2 [CurrentNum_1, 4] = NumberOfModule [j + 1]; 

							sModule_c [Bracket3 [NumberOfModule [j], 0]] = "№".ToCharArray () [0];  
							sModule_c [Bracket3 [NumberOfModule [j + 1], 0]] = "№".ToCharArray () [0];





							CountBracket2_3 = CountBracket2_3 + 1;	

							j = j + 2;
						}				
					}



				}					


			}						
		}









		for (int i = 0; i <= CountBracket2_2 - 1; i++) {	


			sVariable_c [Bracket3 [Bracket3_r [i, 0], 0]] = Bracket_L [0]; 
			sVariable_c [Bracket3 [Bracket3_r [i, 1], 0]] = Bracket_R [0]; 

		}







		CountOfUnActSymbols1 = 0; 
		for (int i = 0; i <= CountBracket2_3 - 1; i++) {	
			Pp1 = BracketStep2 [i, 0]; 

			if (Pp1 + 1 <= stext.Length - 1) {
				for (int j = Pp1 + 1; j <= stext.Length - 1; j++) {
					if (sVariable_c [j] != Symbols2 [0]) { 



						if ((sVariable_c [j] == Symbols [0]) &
							((stext [j] == Symbols [0]) |
								(stext [j] == Symbols [1]))) { 
							if (j + 1 <= stext.Length - 1) {

								for (int k = j + 1; k <= stext.Length - 1; k++) {
									if (sVariable_c [k] != Symbols2 [0]) { 
										if (sVariable_c [k] == Bracket_L [0]) { 
											for (int k2 = 0; k2 <= 3; k2++) {
												if (stext [k] == Bracket_L [k2]) { 
													sVariable_c [j] = "_".ToCharArray () [0];
													CountOfUnActSymbols1 = CountOfUnActSymbols1+1; 

													for (int k3 = 0; k3 <= CountOfSymbols1-1; k3++) { 
														if (AllSymbols1 [k3,0] == j) {
															AllSymbols1 [k3,2] = 1; 
															break;
														}
													}
													break;
												}
											}
										} else if ((sVariable_c [k] == ".".ToCharArray () [0]) |
											(sVariable_c [k] == "№".ToCharArray () [0])) { 
											sVariable_c [j] = "_".ToCharArray () [0];
											CountOfUnActSymbols1 = CountOfUnActSymbols1+1; 

											for (int k3 = 0; k3 <= CountOfSymbols1-1; k3++) { 
												if (AllSymbols1 [k3,0] == j) {
													AllSymbols1 [k3,2] = 1; 
													break;
												}
											}
											break;
										} 
										break;
									}
								}

							}
						}
						break;
					}
				}
			}
		}


		Pp1 = 0;
		while (Pp1 <= stext.Length - 1) {
			if (sVariable_c [Pp1] != Symbols2 [0]) { 

				if (((sVariable_c [Pp1] == Symbols [0]) |
					(sVariable_c [Pp1] == Symbols [5])) &
					((stext [Pp1] == Symbols [2]) |
						(stext [Pp1] == Symbols [3]) |
						(stext [Pp1] == Symbols [4]) |
						(stext [Pp1] == Symbols [5]))) { 
					if (Pp1 + 1 <= stext.Length - 1) {
						for (int k = Pp1 + 1; k <= stext.Length - 1; k++) {
							if (sVariable_c [k] != Symbols2 [0]) { 
								if ((sVariable_c [k] == Symbols [0]) &
									((stext [k] == Symbols [0]) |
										(stext [k] == Symbols [1]))) { 
									sVariable_c [k] = "_".ToCharArray () [0];
									CountOfUnActSymbols1 = CountOfUnActSymbols1+1; 

									for (int k3 = 0; k3 <= CountOfSymbols1 - 1; k3++) { 
										if (AllSymbols1 [k3, 0] == k) {
											AllSymbols1 [k3, 2] = 1; 
											break;
										}
									}

									Pp1 = k;
									break;		
								}
								break;
							}
						}
					}
				}
			}
			Pp1 = Pp1 + 1;
		}





		bool NextStep1 = false;
		Pp1 = 0;
		for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
			Pp1 = AllVariables1 [i, 1] + 1; 
			while (Pp1 <= stext.Length - 1) {
				if (sVariable_c [Pp1] != Symbols2 [0]) { 

					if (sVariable_c [Pp1] == Symbols2 [3]) { 
						sVariable_c [Pp1] = Symbols2 [0]; 
						NextStep1 = true;
					}
					else
						if (sVariable_c [Pp1] == Bracket_L [0]) { 
							for (int k = 0; k <= CountBracket2_3 - 1; k++) {
								if (BracketStep2 [k, 0] == Pp1) { 
									AllVariables1 [i, 2] = k; 
									BracketStep2 [k, 7] = i; 
									break;
								}
							}
						}

					if (NextStep1 == true) {
						NextStep1 = false;							     	
					}
					else {
						break;
					}
				}
				Pp1 = Pp1 + 1;
			}		
		}			







		for (int i = 0; i <= CountOfSymbols1 - 1; i++) {
			if ((AllSymbols1 [i, 1] == 0) | (AllSymbols1 [i, 1] == 1)) { 


				for (int j = AllSymbols1 [i, 0]+1; j <= sVariable_c.Length - 1; j++) {
					if (sVariable_c [j] != Symbols2 [0]) { 

						for (int k = 3; k <= 5; k++) { 
							if (sVariable_c [j] == Symbols2 [k]) { 
								if (k == 3) { 
									for (int k2 = 0; k2 <= CountOfVariables1 - 1; k2++) {						
										if (AllVariables1 [k2, 0] == j) { 
											AllVariables1 [k2, 3] = i; 
											if (AllSymbols1 [i, 2] == 1)  
												AllVariables1 [k2, 4] = AllSymbols1 [i, 1]; 
											else AllVariables1 [k2, 4] = -(AllSymbols1 [i, 1]+2); 
											break;
										}
									}
								} else if (k == 4) { 
									for (int k2 = 0; k2 <= CountOfNumbers1 - 1; k2++) {						
										if (AllNumbers1 [k2, 0] == j) { 
											AllNumbers1 [k2, 2] = i; 
											if (AllSymbols1 [i, 2] == 1)  
												AllNumbers1 [k2, 3] = AllSymbols1 [i, 1]; 
											else AllNumbers1 [k2, 3] = -(AllSymbols1 [i, 1]+2); 
											break;
										}
									}
								} else if (k == 5) { 
									for (int k2 = 0; k2 <= CountBracket2_3 - 1; k2++) {						
										if (BracketStep2 [k2, 0] == j) { 
											BracketStep2 [k2, 5] = i; 
											if (AllSymbols1 [i, 2] == 1)  
												BracketStep2 [k2, 6] = AllSymbols1 [i, 1]; 
											else {
												BracketStep2 [k2, 6] = -(AllSymbols1 [i, 1]+2); 
											}



											break;
										}
									}
								}
								break;
							}					
						}
						break;
					}
				}
			}								
		}







		sVariable = new string(sVariable_c);


		int Pp1_2 = 0;


		int CountBracket2_4 = CountBracket2_3+1;
		CountAddBracket = 0; 
		Pp1 = 0;
		Pp2 = 0;
		Pp3 = -1;
		NextStep1 = false;
		bool MakeBracketR = false;
		bool MakeBracketL = false;
		int TheSame_L = -1;
		bool TheSameR = false;
		int TheSameN_L = -1;
		int TheSameV_L = -1;
		int TheSameS_L = -1;
		int TheSame_R = -1;
		int TheSameN_R = -1;
		int TheSameV_R = -1;

		Pp1 = stext.Length - 1;
		while (Pp1 >= 0) {	
			if (sVariable [Pp1] != Symbols2 [0]) { 

				if ((sVariable [Pp1] == Symbols [0]) &
					(stext [Pp1] == Symbols [4]) & ((MakeBracketL == false) | 
						(MakeBracketR == false))) { 





					if (Pp1 + 1 <= stext.Length - 1) {
						Pp2 = Pp1 + 1;
						while (Pp2 <= stext.Length - 1) {

							if (sVariable [Pp2] != Symbols2 [0]) { 


								if ((sVariable [Pp2] == Bracket_L [0]) |
									(sVariable [Pp2] == Bracket_L [2])) { 

									MakeBracketR = true;
									for (int k = 0; k <= CountBracket2_4 - 1; k++) {
										if (BracketStep2 [k, 0] == Pp2) { 
											TheSameN_R = -1; 
											TheSameV_R = -1; 
											TheSame_R = k; 
											Pp3 = BracketStep2 [k, 1]; 

											Pp2 = Pp3;

											break;
										}
									}
								} else if ((sVariable [Pp2] == "_".ToCharArray () [0]) &
									((stext [Pp2] == Symbols [0]) |
										(stext [Pp2] == Symbols [1]))) { 
									NextStep1 = true;	





								} else if (sVariable [Pp2] == Symbols2 [3]) { 

									MakeBracketR = true;
									for (int k = 0; k <= CountOfVariables1 - 1; k++) { 
										if (AllVariables1 [k, 0] == Pp2) {
											if (AllVariables1 [k, 2] > -1) { 
												TheSameN_R = -1; 
												TheSameV_R = -1; 
												TheSame_R = AllVariables1 [k, 2]; 
												Pp3 = BracketStep2 [AllVariables1 [k, 2], 1]; 

												Pp2 = Pp3;
											} else { 
												TheSameN_R = -1; 
												TheSameV_R = k; 
												TheSame_R = -1; 
												Pp3 = AllVariables1 [k, 1]; 

												Pp2 = Pp3;
											}

											break;
										}
									}
								} else if (sVariable [Pp2] == Symbols2 [4]) { 

									MakeBracketR = true;
									for (int k = 0; k <= CountOfNumbers1 - 1; k++) { 
										if (AllNumbers1 [k, 0] == Pp2) {
											TheSameN_R = k; 
											TheSameV_R = -1; 
											TheSame_R = -1; 

											Pp3 = AllNumbers1 [k, 1]; 

											Pp2 = Pp3;

											break;
										}
									}
								}

								if (NextStep1 == true) {
									NextStep1 = false;

								} else {
									break;
								}
							}
							Pp2 = Pp2 + 1;
						}
					}




					if (MakeBracketL == false) {
						if (Pp1 - 1 >= 0) {
							Pp2 = Pp1 - 1;
							Pp1_2 = Pp1;
							while (Pp2 >= 0) {

								if (sVariable [Pp2] != Symbols2 [0]) { 
									Pp1 = Pp2+1; 

									if ((sVariable [Pp2] == Bracket_R [0]) |
										(sVariable [Pp2] == Bracket_R [2])) { 
										NextStep1 = true;
										MakeBracketL = true;
										for (int k = 0; k <= CountBracket2_4 - 1; k++) {
											if (BracketStep2 [k, 1] == Pp2) { 
												TheSameN_L = -1; 
												TheSameV_L = -1; 
												TheSame_L = k; 
												TheSameS_L = -1; 
												Pp1 = BracketStep2 [k, 0]; 
												Pp2 = Pp1;
												break;
											}
										}
									} else if ((sVariable [Pp2] == "_".ToCharArray () [0]) &
										((stext [Pp2] == Symbols [0]) |
											(stext [Pp2] == Symbols [1]))) { 
										for (int k = 0; k <= CountOfSymbols1 - 1; k++) {	
											if (AllSymbols1 [k, 0] == Pp2) {
												TheSameS_L = k; 
												break;
											}
										}
										NextStep1 = true;
										MakeBracketL = true;
										Pp1 = Pp2; 




									} else if (sVariable [Pp2] == Symbols2 [3]) { 
										NextStep1 = true;
										MakeBracketL = true;
										for (int k = 0; k <= CountOfVariables1 - 1; k++) { 
											if (AllVariables1 [k, 1] == Pp2) {
												TheSameN_L = -1; 
												TheSameV_L = k; 
												TheSame_L = -1; 
												TheSameS_L = -1; 
												Pp1 = AllVariables1 [k, 0]; 
												Pp2 = Pp1;
												break;
											}
										}
									} else if (sVariable [Pp2] == Symbols2 [4]) { 
										NextStep1 = true;
										MakeBracketL = true;
										for (int k = 0; k <= CountOfNumbers1 - 1; k++) { 
											if (AllNumbers1 [k, 1] == Pp2) {

												TheSameN_L = k; 
												TheSameV_L = -1; 
												TheSame_L = -1; 
												TheSameS_L = -1; 
												Pp1 = AllNumbers1 [k, 0]; 

												Pp2 = Pp1;
												break;
											}
										}
									}

									if (NextStep1 == true) {
										NextStep1 = false;

									} else {
										break;
									}
								}
								Pp2 = Pp2 - 1;
							}
						}


					}


				} else {
					if ((MakeBracketL == true) & (MakeBracketR == true)) { 

						TheSameR = false; 

						{ 
							Pp1 = Pp1 + 1;
							Pp3 = Pp3 + 1;

							if ((sVariable [Pp3] == Bracket_R [0]) |
								(sVariable [Pp3] == Bracket_R [2]) |
								(sVariable [Pp3] == Bracket_R [3])) { 
								for (int k = 0; k <= CountBracket2_4 - 1; k++) {
									if (BracketStep2 [k, 1] == Pp3) { 
										if (BracketStep2 [k, 0] == Pp1-1) { 
											TheSameN_L = -1; 
											TheSameV_L = -1; 
											TheSame_L = k; 
											TheSameR = true; 

											break;
										}
									}
								}
							}
						}




						if ((TheSame_L == -1) | (TheSameR == false)) { 

							{
								stext = stext.Insert (Pp1, "(");
								sVariable = sVariable.Insert (Pp1, "[");



								if (CountOfCommas1 > 0) {
									for (int i = 0; i <= CountOfCommas1 - 1; i++) {
										if (CommasInText [i, 0] >= Pp1)
											CommasInText [i, 0] = CommasInText [i, 0]+1; 
									}
								}
								if (CountOfSymbols1 > 0) {
									for (int i = 0; i <= CountOfSymbols1 - 1; i++) {	
										if (AllSymbols1 [i, 0] >= Pp1)
											AllSymbols1 [i, 0] = AllSymbols1 [i, 0] + 1;
									}
								}
								if (CountOfVariables1 > 0) {
									for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
										if (AllVariables1 [i, 0] >= Pp1) {
											AllVariables1 [i, 0] = AllVariables1 [i, 0] + 1;

											AllVariables1 [i, 1] = AllVariables1 [i, 1] + 1;					
										}
									}
								}
								if (CountOfNumbers1 > 0) {
									for (int i = 0; i <= CountOfNumbers1 - 1; i++) {	
										if (AllNumbers1 [i, 0] >= Pp1) {
											AllNumbers1 [i, 0] = AllNumbers1 [i, 0] + 1;

											AllNumbers1 [i, 1] = AllNumbers1 [i, 1] + 1;					


										}
									}
								}
								if (CountBracket2_4 > 0) {
									for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
										if (BracketStep2 [i, 0] >= Pp1)
											BracketStep2 [i, 0] = BracketStep2 [i, 0] + 1;
										if (BracketStep2 [i, 1] >= Pp1)
											BracketStep2 [i, 1] = BracketStep2 [i, 1] + 1;					
									}		
								}


								BracketStep2 [CountBracket2_4 - 1, 0] = Pp1; 


							}


							{
								Pp3 = Pp3 + 1;
								Pp1 = Pp3;
								stext = stext.Insert (Pp3, ")");
								sVariable = sVariable.Insert (Pp3, "]");



								if (CountOfCommas1 > 0) {
									for (int i = 0; i <= CountOfCommas1 - 1; i++) {
										if (CommasInText [i, 0] >= Pp3)
											CommasInText [i, 0] = CommasInText [i, 0]+1; 
									}
								}
								if (CountOfSymbols1 > 0) {
									for (int i = 0; i <= CountOfSymbols1 - 1; i++) {	
										if (AllSymbols1 [i, 0] >= Pp3)
											AllSymbols1 [i, 0] = AllSymbols1 [i, 0] + 1;
									}
								}
								if (CountOfVariables1 > 0) {
									for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
										if (AllVariables1 [i, 0] >= Pp3) {
											AllVariables1 [i, 0] = AllVariables1 [i, 0] + 1;

											AllVariables1 [i, 1] = AllVariables1 [i, 1] + 1;					
										}
									}
								}
								if (CountOfNumbers1 > 0) {
									for (int i = 0; i <= CountOfNumbers1 - 1; i++) {	
										if (AllNumbers1 [i, 0] >= Pp3) {
											AllNumbers1 [i, 0] = AllNumbers1 [i, 0] + 1;

											AllNumbers1 [i, 1] = AllNumbers1 [i, 1] + 1;					


										}
									}
								}
								if (CountBracket2_4 > 0) {
									for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
										if (BracketStep2 [i, 0] >= Pp3)
											BracketStep2 [i, 0] = BracketStep2 [i, 0] + 1;
										if (BracketStep2 [i, 1] >= Pp3)
											BracketStep2 [i, 1] = BracketStep2 [i, 1] + 1;					
									}		
								}


								BracketStep2 [CountBracket2_4 - 1, 1] = Pp3; 
								BracketStep2 [CountBracket2_4 - 1, 2] = 4; 
								BracketStep2 [CountBracket2_4 - 1, 5] = -1; 
								BracketStep2 [CountBracket2_4 - 1, 6] = -1; 
							}

							if (TheSame_L > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 10] = BracketStep2 [TheSame_L, 10]; 





								BracketStep2 [CountBracket2_4 - 1, 5] = BracketStep2 [TheSame_L, 5]; 
								BracketStep2 [CountBracket2_4 - 1, 6] = BracketStep2 [TheSame_L, 6]; 

								BracketStep2 [TheSame_L, 5] = -1; 
								BracketStep2 [TheSame_L, 6] = -1; 
							} else if (TheSameN_L > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 10] = AllNumbers1 [TheSameN_L, 4]; 

								if (AllNumbers1 [TheSameN_L, 3] < -1) { 

									BracketStep2 [CountBracket2_4 - 1, 5] = AllNumbers1 [TheSameN_L, 2]; 
									BracketStep2 [CountBracket2_4 - 1, 6] = AllNumbers1 [TheSameN_L, 3]; 

									AllNumbers1 [TheSameN_L, 2] = -1; 
									AllNumbers1 [TheSameN_L, 3] = -1; 
								}
							} else if (TheSameV_L > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 10] = AllVariables1 [TheSameV_L, 6]; 

								if (AllVariables1 [TheSameV_L, 4] < -1) { 

									BracketStep2 [CountBracket2_4 - 1, 5] = AllVariables1 [TheSameV_L, 3]; 
									BracketStep2 [CountBracket2_4 - 1, 6] = AllVariables1 [TheSameV_L, 4]; 

									AllVariables1 [TheSameV_L, 3] = -1; 
									AllVariables1 [TheSameV_L, 4] = -1; 
								}
							}
							if (TheSameS_L > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 10] = AllSymbols1 [TheSameS_L, 3]; 
							}

							if (TheSame_R > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 11] = BracketStep2 [TheSame_R, 11]; 
							} else if (TheSameN_R > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 11] = AllNumbers1 [TheSameN_R, 5]; 
							} else if (TheSameV_R > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 11] = AllVariables1 [TheSameV_R, 7]; 
							}








							CountBracket2_4 = CountBracket2_4 + 1;	
							CountAddBracket = CountAddBracket + 1; 
						}
						TheSameN_L = -1; 
						TheSameV_L = -1; 
						TheSame_L = -1; 
						TheSameS_L = -1; 
						TheSameN_R = -1; 
						TheSameV_R = -1; 
						TheSame_R = -1; 

						MakeBracketL = false;
						MakeBracketR = false;
						Pp1 = Pp1_2;
					}
				}

			}
			Pp1 = Pp1 - 1;		
		}



		Pp1_2 = 0;
		Pp1 = 0;
		Pp2 = 0;
		Pp3 = -1;
		NextStep1 = false;
		MakeBracketR = false;
		MakeBracketL = false;
		TheSame_L = -1;
		TheSameN_L = -1;
		TheSameV_L = -1;
		TheSameS_L = -1;
		TheSame_R = -1;
		TheSameN_R = -1;
		TheSameV_R = -1;
		while (Pp1 <= stext.Length - 1) {
			if (sVariable [Pp1] != Symbols2 [0]) { 

				if ((sVariable [Pp1] == Symbols [0]) &
					((stext [Pp1] == Symbols [2]) |
						(stext [Pp1] == Symbols [3]))) { 



					if (MakeBracketL == false) {
						if (Pp1 - 1 >= 0) {
							Pp2 = Pp1 - 1;
							while (Pp2 >= 0) {

								if (sVariable [Pp2] != Symbols2 [0]) { 
									Pp3 = Pp2+1; 

									if ((sVariable [Pp2] == Bracket_R [0]) |
										(sVariable [Pp2] == Bracket_R [2])) { 
										NextStep1 = true;
										MakeBracketL = true;
										for (int k = 0; k <= CountBracket2_4 - 1; k++) {
											if (BracketStep2 [k, 1] == Pp2) { 
												TheSameN_L = -1; 
												TheSameV_L = -1; 
												TheSame_L = k; 
												TheSameS_L = -1; 
												Pp3 = BracketStep2 [k, 0]; 
												Pp2 = Pp3;
												break;
											}
										}
									} else if ((sVariable [Pp2] == "_".ToCharArray () [0]) &
										((stext [Pp2] == Symbols [0]) |
											(stext [Pp2] == Symbols [1]))) { 
										for (int k = 0; k <= CountOfSymbols1 - 1; k++) {	
											if (AllSymbols1 [k, 0] == Pp2) {
												TheSameS_L = k; 
												break;
											}
										}
										NextStep1 = true;
										MakeBracketL = true;
										Pp3 = Pp2; 
									} else if ((sVariable [Pp2] == "+".ToCharArray () [0]) &
										((stext [Pp2] == Symbols [2]) |
											(stext [Pp2] == Symbols [3]))) { 
										NextStep1 = true;


									} else if (sVariable [Pp2] == Symbols2 [3]) { 
										NextStep1 = true;
										MakeBracketL = true;
										for (int k = 0; k <= CountOfVariables1 - 1; k++) { 
											if (AllVariables1 [k, 1] == Pp2) {
												TheSameN_L = -1; 
												TheSameV_L = k; 
												TheSame_L = -1; 
												TheSameS_L = -1; 
												Pp3 = AllVariables1 [k, 0]; 
												Pp2 = Pp3;
												break;
											}
										}
									} else if (sVariable [Pp2] == Symbols2 [4]) { 
										NextStep1 = true;
										MakeBracketL = true;
										for (int k = 0; k <= CountOfNumbers1 - 1; k++) { 
											if (AllNumbers1 [k, 1] == Pp2) {

												TheSameN_L = k; 
												TheSameV_L = -1; 
												TheSame_L = -1; 
												TheSameS_L = -1; 
												Pp3 = AllNumbers1 [k, 0]; 
												Pp2 = Pp3;
												break;
											}
										}
									}

									if (NextStep1 == true) {
										NextStep1 = false;

									} else {
										break;
									}
								}
								Pp2 = Pp2 - 1;
							}
						}


					}



					if (Pp1 + 1 <= stext.Length - 1) {
						Pp2 = Pp1 + 1;
						Pp1_2 = Pp1;
						while (Pp2 <= stext.Length - 1) {

							if (sVariable [Pp2] != Symbols2 [0]) { 

								if ((sVariable [Pp2] == Bracket_L [0]) |
									(sVariable [Pp2] == Bracket_L [2])) { 
									NextStep1 = true;
									MakeBracketR = true;
									for (int k = 0; k <= CountBracket2_4 - 1; k++) {
										if (BracketStep2 [k, 0] == Pp2) { 
											TheSameN_R = -1; 
											TheSameV_R = -1; 
											TheSame_R = k; 
											Pp1 = BracketStep2 [k, 1]; 
											Pp2 = Pp1;



											break;
										}
									}
								} else if ((sVariable [Pp2] == "_".ToCharArray () [0]) &
									((stext [Pp2] == Symbols [0]) |
										(stext [Pp2] == Symbols [1]))) { 
									NextStep1 = true;


								} else if ((sVariable [Pp2] == "+".ToCharArray () [0]) &
									((stext [Pp2] == Symbols [2]) |
										(stext [Pp2] == Symbols [3]))) { 
									NextStep1 = true;


								} else if (sVariable [Pp2] == Symbols2 [3]) { 
									NextStep1 = true;
									MakeBracketR = true;
									for (int k = 0; k <= CountOfVariables1 - 1; k++) { 
										if (AllVariables1 [k, 0] == Pp2) {
											if (AllVariables1 [k, 2] > -1) { 
												TheSameN_R = -1; 
												TheSameV_R = -1; 
												TheSame_R = AllVariables1 [k, 2]; 
												Pp1 = BracketStep2 [AllVariables1 [k, 2], 1]; 
												Pp2 = Pp1;

											} else { 
												TheSameN_R = -1; 
												TheSameV_R = k; 
												TheSame_R = -1; 
												Pp1 = AllVariables1 [k, 1]; 
												Pp2 = Pp1;

											}


											break;
										}
									}
								} else if (sVariable [Pp2] == Symbols2 [4]) { 
									NextStep1 = true;
									MakeBracketR = true;
									for (int k = 0; k <= CountOfNumbers1 - 1; k++) { 
										if (AllNumbers1 [k, 0] == Pp2) {
											TheSameN_R = k; 
											TheSameV_R = -1; 
											TheSame_R = -1; 

											Pp1 = AllNumbers1 [k, 1]; 
											Pp2 = Pp1;



											break;
										}
									}
								}

								if (NextStep1 == true) {
									NextStep1 = false;

								} else {
									break;
								}
							}
							Pp2 = Pp2 + 1;
						}
					}


				} else {



					if ((MakeBracketL == true) & (MakeBracketR == true)) 
					{ 

						TheSameR = false; 

						{ 
							if ((sVariable [Pp1] == Bracket_R [0]) |
								(sVariable [Pp1] == Bracket_R [2]) |
								(sVariable [Pp1] == Bracket_R [3])) { 
								for (int k = 0; k <= CountBracket2_4 - 1; k++) {
									if (BracketStep2 [k, 1] == Pp1) { 
										if (BracketStep2 [k, 0] == Pp3-1) { 
											TheSameN_L = -1; 
											TheSameV_L = -1; 
											TheSame_L = k; 
											TheSameR = true; 



											break;
										}
									}
								}
							}
						}






						if ((TheSame_L == -1) | (TheSameR == false)) 
						{ 

							{



								stext = stext.Insert (Pp3, "(");
								sVariable = sVariable.Insert (Pp3, "[");


								if (CountOfCommas1 > 0) {
									for (int i = 0; i <= CountOfCommas1 - 1; i++) {
										if (CommasInText [i, 0] >= Pp3)
											CommasInText [i, 0] = CommasInText [i, 0]+1; 
									}
								}
								if (CountOfSymbols1 > 0) {
									for (int i = 0; i <= CountOfSymbols1 - 1; i++) {	
										if (AllSymbols1 [i, 0] >= Pp3)
											AllSymbols1 [i, 0] = AllSymbols1 [i, 0] + 1;
									}
								}
								if (CountOfVariables1 > 0) {
									for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
										if (AllVariables1 [i, 0] >= Pp3) {
											AllVariables1 [i, 0] = AllVariables1 [i, 0] + 1;

											AllVariables1 [i, 1] = AllVariables1 [i, 1] + 1;					
										}
									}
								}
								if (CountOfNumbers1 > 0) {
									for (int i = 0; i <= CountOfNumbers1 - 1; i++) {	
										if (AllNumbers1 [i, 0] >= Pp3) {
											AllNumbers1 [i, 0] = AllNumbers1 [i, 0] + 1;

											AllNumbers1 [i, 1] = AllNumbers1 [i, 1] + 1;					


										}
									}
								}
								if (CountBracket2_4 > 0) {
									for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
										if (BracketStep2 [i, 0] >= Pp3)
											BracketStep2 [i, 0] = BracketStep2 [i, 0] + 1;
										if (BracketStep2 [i, 1] >= Pp3)
											BracketStep2 [i, 1] = BracketStep2 [i, 1] + 1;					
									}		
								}			


								BracketStep2 [CountBracket2_4 - 1, 0] = Pp3; 


							}


							{
								Pp1 = Pp1 + 1;
								Pp3 = Pp1;
								stext = stext.Insert (Pp1, ")");
								sVariable = sVariable.Insert (Pp1, "]");



								if (CountOfCommas1 > 0) {
									for (int i = 0; i <= CountOfCommas1 - 1; i++) {
										if (CommasInText [i, 0] >= Pp1)
											CommasInText [i, 0] = CommasInText [i, 0]+1; 
									}
								}
								if (CountOfSymbols1 > 0) {
									for (int i = 0; i <= CountOfSymbols1 - 1; i++) {	
										if (AllSymbols1 [i, 0] >= Pp1)
											AllSymbols1 [i, 0] = AllSymbols1 [i, 0] + 1;
									}
								}
								if (CountOfVariables1 > 0) {
									for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
										if (AllVariables1 [i, 0] >= Pp1) {
											AllVariables1 [i, 0] = AllVariables1 [i, 0] + 1;

											AllVariables1 [i, 1] = AllVariables1 [i, 1] + 1;					
										}
									}
								}
								if (CountOfNumbers1 > 0) {
									for (int i = 0; i <= CountOfNumbers1 - 1; i++) {	
										if (AllNumbers1 [i, 0] >= Pp1) {
											AllNumbers1 [i, 0] = AllNumbers1 [i, 0] + 1;

											AllNumbers1 [i, 1] = AllNumbers1 [i, 1] + 1;					


										}
									}
								}
								if (CountBracket2_4 > 0) {
									for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
										if (BracketStep2 [i, 0] >= Pp1)
											BracketStep2 [i, 0] = BracketStep2 [i, 0] + 1;
										if (BracketStep2 [i, 1] >= Pp1)
											BracketStep2 [i, 1] = BracketStep2 [i, 1] + 1;					
									}		
								}


								BracketStep2 [CountBracket2_4 - 1, 1] = Pp1; 
								BracketStep2 [CountBracket2_4 - 1, 2] = 4; 
								BracketStep2 [CountBracket2_4 - 1, 5] = -1; 
								BracketStep2 [CountBracket2_4 - 1, 6] = -1; 
							}

							if (TheSame_L > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 10] = BracketStep2 [TheSame_L, 10]; 





								BracketStep2 [CountBracket2_4 - 1, 5] = BracketStep2 [TheSame_L, 5]; 
								BracketStep2 [CountBracket2_4 - 1, 6] = BracketStep2 [TheSame_L, 6]; 

								BracketStep2 [TheSame_L, 5] = -1; 
								BracketStep2 [TheSame_L, 6] = -1; 
							} else if (TheSameN_L > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 10] = AllNumbers1 [TheSameN_L, 4]; 

								if (AllNumbers1 [TheSameN_L, 3] < -1) { 

									BracketStep2 [CountBracket2_4 - 1, 5] = AllNumbers1 [TheSameN_L, 2]; 
									BracketStep2 [CountBracket2_4 - 1, 6] = AllNumbers1 [TheSameN_L, 3]; 

									AllNumbers1 [TheSameN_L, 2] = -1; 
									AllNumbers1 [TheSameN_L, 3] = -1; 
								}
							} else if (TheSameV_L > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 10] = AllVariables1 [TheSameV_L, 6]; 

								if (AllVariables1 [TheSameV_L, 4] < -1) { 

									BracketStep2 [CountBracket2_4 - 1, 5] = AllVariables1 [TheSameV_L, 3]; 
									BracketStep2 [CountBracket2_4 - 1, 6] = AllVariables1 [TheSameV_L, 4]; 

									AllVariables1 [TheSameV_L, 3] = -1; 
									AllVariables1 [TheSameV_L, 4] = -1; 
								}
							}
							if (TheSameS_L > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 10] = AllSymbols1 [TheSameS_L, 3]; 
							}

							if (TheSame_R > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 11] = BracketStep2 [TheSame_R, 11]; 
							} else if (TheSameN_R > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 11] = AllNumbers1 [TheSameN_R, 5]; 
							} else if (TheSameV_R > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 11] = AllVariables1 [TheSameV_R, 7]; 
							}








							CountBracket2_4 = CountBracket2_4 + 1;	
							CountAddBracket = CountAddBracket + 1; 
						}
						TheSameN_L = -1; 
						TheSameV_L = -1; 
						TheSame_L = -1; 
						TheSameS_L = -1; 
						TheSameN_R = -1; 
						TheSameV_R = -1; 
						TheSame_R = -1; 

						MakeBracketL = false;
						MakeBracketR = false;
						Pp1 = Pp1_2;
					}
				}

			}
			Pp1 = Pp1 + 1;		

		}








		Pp0 = 0;
		Pp1 = 0;
		Pp2 = 0;
		Pp3 = -1;
		NextStep1 = false;
		MakeBracketR = false;
		MakeBracketL = false;
		int TheSame_Main = -1; 
		int TheSame_L2 = -1;
		int TheSame_R2 = -1;
		int TheSame_C = 0;
		TheSame_L = -1;
		TheSameN_L = -1;
		TheSameV_L = -1;
		TheSameS_L = -1;
		TheSame_R = -1;
		TheSameN_R = -1;
		TheSameV_R = -1;

		bool MakeBracketL2 = false;
		while (Pp1 <= stext.Length - 1) {
			if (sVariable [Pp1] != Symbols2 [0]) { 

				if ((sVariable [Pp1] == Symbols [5])) { 

					for (int i = TheSame_C; i <= CountOfCommas1 - 1; i++) {
						if (CommasInText [i, 0] == Pp1) {
							TheSame_C = i; 
							break;
						}
					}

					Pp0 = Pp1;

					if (MakeBracketL2 == false) {
						if (Pp1 - 1 >= 0) {
							Pp2 = Pp1 - 1;
							while (Pp2 >= 0) {

								if (sVariable [Pp2] != Symbols2 [0]) { 

									if ((sVariable [Pp2] == Bracket_R [0]) |
										(sVariable [Pp2] == Bracket_R [2])) { 
										NextStep1 = true;

										for (int k = 0; k <= CountBracket2_4 - 1; k++) {
											if (BracketStep2 [k, 1] == Pp2) { 
												if (TheSame_L2 == k) { 
													NextStep1 = false;
													break;
												}
												TheSameN_L = -1; 
												TheSameV_L = -1; 
												TheSame_L = k; 
												TheSameS_L = -1; 
												TheSame_L2 = k; 
												Pp3 = BracketStep2 [k, 0]; 
												Pp2 = Pp3;
												break;
											}
										}
									} else if ((sVariable [Pp2] == "_".ToCharArray () [0]) |
										(sVariable [Pp2] == Symbols [0])) { 
										for (int k = 0; k <= CountOfSymbols1 - 1; k++) {	
											if (AllSymbols1 [k, 0] == Pp2) {
												TheSameS_L = k; 
												break;
											}
										}
										NextStep1 = true;


									} else if (sVariable [Pp2] == Symbols2 [3]) { 
										NextStep1 = true;

										for (int k = 0; k <= CountOfVariables1 - 1; k++) { 
											if (AllVariables1 [k, 1] == Pp2) {
												TheSameN_L = -1; 
												TheSameV_L = k; 
												TheSame_L = -1; 
												TheSameS_L = -1; 
												Pp3 = AllVariables1 [k, 0]; 
												Pp2 = Pp3;
												break;
											}
										}
									} else if (sVariable [Pp2] == Symbols2 [4]) { 
										NextStep1 = true;

										for (int k = 0; k <= CountOfNumbers1 - 1; k++) { 
											if (AllNumbers1 [k, 1] == Pp2) {
												TheSameN_L = k; 
												TheSameV_L = -1; 
												TheSame_L = -1; 
												TheSameS_L = -1; 

												Pp3 = AllNumbers1 [k, 0]; 
												Pp2 = Pp3;
												break;
											}
										}
									}
									else if ((sVariable [Pp2] == Bracket_L [0]) |
										(sVariable [Pp2] == Bracket_L [2])) { 

										MakeBracketL = true;
										MakeBracketL2 = true;
										for (int k = 0; k <= CountBracket2_4 - 1; k++) {
											if (BracketStep2 [k, 0] == Pp2) { 


												TheSame_Main = k; 
												Pp3 = Pp2+1; 
												Pp2 = Pp3;

												break;
											}
										}
									}

















									if (NextStep1 == true) {
										NextStep1 = false;

									} else {
										break;
									}
								}
								Pp2 = Pp2 - 1;
							}
						}					
					}



					if (Pp1 + 1 <= stext.Length - 1) {
						Pp2 = Pp1 + 1;
						while (Pp2 <= stext.Length - 1) {

							if (sVariable [Pp2] != Symbols2 [0]) { 

								if ((sVariable [Pp2] == Bracket_L [0]) |
									(sVariable [Pp2] == Bracket_L [2])) { 
									NextStep1 = true;	

									for (int k = 0; k <= CountBracket2_4 - 1; k++) {
										if (BracketStep2 [k, 0] == Pp2) { 
											TheSameN_R = -1; 
											TheSameV_R = -1; 
											TheSame_R = k; 
											TheSame_R2 = k; 
											Pp1 = BracketStep2 [k, 1]; 
											Pp2 = Pp1; 


											break;
										}
									}
								} else if ((sVariable [Pp2] == "_".ToCharArray () [0]) |
									(sVariable [Pp2] == Symbols [0])) { 
									NextStep1 = true;	

								} else if (sVariable [Pp2] == Symbols2 [3]) { 
									NextStep1 = true;	

									for (int k = 0; k <= CountOfVariables1 - 1; k++) { 
										if (AllVariables1 [k, 0] == Pp2) {
											if (AllVariables1 [k, 2] > -1) { 
												TheSameN_R = -1; 
												TheSameV_R = -1; 
												TheSame_R = AllVariables1 [k, 2]; 
												Pp1 = BracketStep2 [AllVariables1 [k, 2], 1]; 
											} else { 
												TheSameN_R = -1; 
												TheSameV_R = k; 
												TheSame_R = -1; 
												Pp1 = AllVariables1 [k, 1]; 
											}
											Pp2 = Pp1; 

											break;
										}
									}
								} else if (sVariable [Pp2] == Symbols2 [4]) { 
									NextStep1 = true;	

									for (int k = 0; k <= CountOfNumbers1 - 1; k++) { 
										if (AllNumbers1 [k, 0] == Pp2) {
											TheSameN_R = k; 
											TheSameV_R = -1; 
											TheSame_R = -1; 

											Pp1 = AllNumbers1 [k, 1]; 
											Pp2 = Pp1; 

											break;
										}
									}
								}
								else if ((sVariable [Pp2] == Bracket_R [0]) |
									(sVariable [Pp2] == Bracket_R [2])) { 

									MakeBracketR = true;
									for (int k = 0; k <= CountBracket2_4 - 1; k++) {
										if (BracketStep2 [k, 1] == Pp2) { 


											MakeBracketL2 = false;
											Pp1 = Pp2-1; 


											break;
										}
									}
								} else if (sVariable [Pp2] == Symbols [5]) { 

									MakeBracketR = true;
									Pp1 = Pp2-1;












								}




								if (NextStep1 == true) {
									NextStep1 = false;

								} else {
									break;
								}
							}
							Pp2 = Pp2 + 1;
						}
					}


					if (MakeBracketL == true) { 

						TheSameR = false; 
						if (TheSame_L2 > -1) { 






							if ((BracketStep2 [TheSame_L2, 0] == Pp3) & 
								(BracketStep2 [TheSame_L2, 1] == Pp0-1)) {
								TheSameR = true; 
							}



						}



						if ((TheSame_L2 == -1) | (TheSameR == false)) { 





							{
								stext = stext.Insert (Pp3, "(");
								sVariable = sVariable.Insert (Pp3, "[");

								Pp1 = Pp1 + 1; 


								if (CountOfCommas1 > 0) {
									for (int i = 0; i <= CountOfCommas1 - 1; i++) {
										if (CommasInText [i, 0] >= Pp3)
											CommasInText [i, 0] = CommasInText [i, 0]+1; 
									}
								}
								if (CountOfSymbols1 > 0) {
									for (int i = 0; i <= CountOfSymbols1 - 1; i++) {	
										if (AllSymbols1 [i, 0] >= Pp3)
											AllSymbols1 [i, 0] = AllSymbols1 [i, 0] + 1;
									}
								}
								if (CountOfVariables1 > 0) {
									for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
										if (AllVariables1 [i, 0] >= Pp3) {
											AllVariables1 [i, 0] = AllVariables1 [i, 0] + 1;

											AllVariables1 [i, 1] = AllVariables1 [i, 1] + 1;					
										}
									}
								}
								if (CountOfNumbers1 > 0) {
									for (int i = 0; i <= CountOfNumbers1 - 1; i++) {	
										if (AllNumbers1 [i, 0] >= Pp3) {
											AllNumbers1 [i, 0] = AllNumbers1 [i, 0] + 1;

											AllNumbers1 [i, 1] = AllNumbers1 [i, 1] + 1;					


										}
									}
								}
								if (CountBracket2_4 > 0) {
									for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
										if (BracketStep2 [i, 0] >= Pp3)
											BracketStep2 [i, 0] = BracketStep2 [i, 0] + 1;
										if (BracketStep2 [i, 1] >= Pp3)
											BracketStep2 [i, 1] = BracketStep2 [i, 1] + 1;					
									}		
								}	


								BracketStep2 [CountBracket2_4 - 1, 0] = Pp3; 


							}						


							{
								Pp0 = Pp0 + 1;
								Pp3 = Pp0;
								stext = stext.Insert (Pp3, ")");
								sVariable = sVariable.Insert (Pp3, "]");

								Pp0 = Pp0 + 1; 
								Pp1 = Pp1 + 1; 


								if (CountOfCommas1 > 0) {
									for (int i = 0; i <= CountOfCommas1 - 1; i++) {
										if (CommasInText [i, 0] >= Pp3)
											CommasInText [i, 0] = CommasInText [i, 0]+1; 
									}
								}
								if (CountOfSymbols1 > 0) {
									for (int i = 0; i <= CountOfSymbols1 - 1; i++) {	
										if (AllSymbols1 [i, 0] >= Pp3)
											AllSymbols1 [i, 0] = AllSymbols1 [i, 0] + 1;
									}
								}
								if (CountOfVariables1 > 0) {
									for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
										if (AllVariables1 [i, 0] >= Pp3) {
											AllVariables1 [i, 0] = AllVariables1 [i, 0] + 1;

											AllVariables1 [i, 1] = AllVariables1 [i, 1] + 1;					
										}
									}
								}
								if (CountOfNumbers1 > 0) {
									for (int i = 0; i <= CountOfNumbers1 - 1; i++) {	
										if (AllNumbers1 [i, 0] >= Pp3) {
											AllNumbers1 [i, 0] = AllNumbers1 [i, 0] + 1;

											AllNumbers1 [i, 1] = AllNumbers1 [i, 1] + 1;					


										}
									}
								}
								if (CountBracket2_4 > 0) {
									for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
										if (BracketStep2 [i, 0] >= Pp3)
											BracketStep2 [i, 0] = BracketStep2 [i, 0] + 1;
										if (BracketStep2 [i, 1] >= Pp3)
											BracketStep2 [i, 1] = BracketStep2 [i, 1] + 1;					
									}		
								}


								BracketStep2 [CountBracket2_4 - 1, 1] = Pp3; 
								BracketStep2 [CountBracket2_4 - 1, 2] = 4; 
								BracketStep2 [CountBracket2_4 - 1, 5] = -1; 
								BracketStep2 [CountBracket2_4 - 1, 6] = -1; 
								BracketStep2 [CountBracket2_4 - 1, 9] = TheSame_Main; 
							}



							if (TheSame_L > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 10] = BracketStep2 [TheSame_L, 10]; 
							} else if (TheSameN_L > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 10] = AllNumbers1 [TheSameN_L, 4]; 
							} else if (TheSameV_L > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 10] = AllVariables1 [TheSameV_L, 6]; 
							}
							if (TheSameS_L > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 10] = AllSymbols1 [TheSameS_L, 3]; 
							}
							if (TheSame_C > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 11] = CommasInText [TheSame_C, 1]-1; 
							}








							CountBracket2_4 = CountBracket2_4 + 1;	
							CountAddBracket = CountAddBracket + 1; 
						}

						TheSameN_L = -1; 
						TheSameV_L = -1; 
						TheSame_L = -1; 
						TheSameS_L = -1; 
						TheSame_L2 = -1; 
						MakeBracketL = false;



					}

					if (MakeBracketR == true) { 


						BracketStep2 [TheSame_Main, 8] = BracketStep2 [TheSame_Main, 8]+1; 

						TheSameR = false; 
						if (TheSame_R2 > -1) { 






							if ((BracketStep2 [TheSame_R2, 0] == Pp0+1) & 
								(BracketStep2 [TheSame_R2, 1] == Pp1)) {
								TheSameR = true; 
							}



						}



						if ((TheSame_R2 == -1) | (TheSameR == false)) { 





							{
								Pp1 = Pp1 + 1; 
								Pp3 = Pp0+1;
								stext = stext.Insert (Pp3, "(");
								sVariable = sVariable.Insert (Pp3, "[");



								if (CountOfCommas1 > 0) {
									for (int i = 0; i <= CountOfCommas1 - 1; i++) {
										if (CommasInText [i, 0] >= Pp3)
											CommasInText [i, 0] = CommasInText [i, 0]+1; 
									}
								}
								if (CountOfSymbols1 > 0) {
									for (int i = 0; i <= CountOfSymbols1 - 1; i++) {	
										if (AllSymbols1 [i, 0] >= Pp3)
											AllSymbols1 [i, 0] = AllSymbols1 [i, 0] + 1;
									}
								}
								if (CountOfVariables1 > 0) {
									for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
										if (AllVariables1 [i, 0] >= Pp3) {
											AllVariables1 [i, 0] = AllVariables1 [i, 0] + 1;

											AllVariables1 [i, 1] = AllVariables1 [i, 1] + 1;					
										}
									}
								}
								if (CountOfNumbers1 > 0) {
									for (int i = 0; i <= CountOfNumbers1 - 1; i++) {	
										if (AllNumbers1 [i, 0] >= Pp3) {
											AllNumbers1 [i, 0] = AllNumbers1 [i, 0] + 1;

											AllNumbers1 [i, 1] = AllNumbers1 [i, 1] + 1;					


										}
									}
								}
								if (CountBracket2_4 > 0) {
									for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
										if (BracketStep2 [i, 0] >= Pp3)
											BracketStep2 [i, 0] = BracketStep2 [i, 0] + 1;
										if (BracketStep2 [i, 1] >= Pp3)
											BracketStep2 [i, 1] = BracketStep2 [i, 1] + 1;					
									}		
								}			


								BracketStep2 [CountBracket2_4 - 1, 0] = Pp3; 


							}


							{
								Pp1 = Pp1+1;
								Pp3 = Pp1;
								stext = stext.Insert (Pp3, ")");
								sVariable = sVariable.Insert (Pp3, "]");



								if (CountOfCommas1 > 0) {
									for (int i = 0; i <= CountOfCommas1 - 1; i++) {
										if (CommasInText [i, 0] >= Pp3)
											CommasInText [i, 0] = CommasInText [i, 0]+1; 
									}
								}
								if (CountOfSymbols1 > 0) {
									for (int i = 0; i <= CountOfSymbols1 - 1; i++) {	
										if (AllSymbols1 [i, 0] >= Pp3)
											AllSymbols1 [i, 0] = AllSymbols1 [i, 0] + 1;
									}
								}
								if (CountOfVariables1 > 0) {
									for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
										if (AllVariables1 [i, 0] >= Pp3) {
											AllVariables1 [i, 0] = AllVariables1 [i, 0] + 1;

											AllVariables1 [i, 1] = AllVariables1 [i, 1] + 1;					
										}
									}
								}
								if (CountOfNumbers1 > 0) {
									for (int i = 0; i <= CountOfNumbers1 - 1; i++) {	
										if (AllNumbers1 [i, 0] >= Pp3) {
											AllNumbers1 [i, 0] = AllNumbers1 [i, 0] + 1;

											AllNumbers1 [i, 1] = AllNumbers1 [i, 1] + 1;					


										}
									}
								}
								if (CountBracket2_4 > 0) {
									for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
										if (BracketStep2 [i, 0] >= Pp3)
											BracketStep2 [i, 0] = BracketStep2 [i, 0] + 1;
										if (BracketStep2 [i, 1] >= Pp3)
											BracketStep2 [i, 1] = BracketStep2 [i, 1] + 1;					
									}		
								}


								BracketStep2 [CountBracket2_4 - 1, 1] = Pp3; 
								BracketStep2 [CountBracket2_4 - 1, 2] = 4; 
								BracketStep2 [CountBracket2_4 - 1, 5] = -1; 
								BracketStep2 [CountBracket2_4 - 1, 6] = -1; 
								BracketStep2 [CountBracket2_4 - 1, 9] = TheSame_Main; 
							}

							if (TheSame_C > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 10] = CommasInText [TheSame_C, 1]+1; 
							}
							if (TheSame_R > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 11] = BracketStep2 [TheSame_R, 11]; 
							} else if (TheSameN_R > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 11] = AllNumbers1 [TheSameN_R, 5]; 
							} else if (TheSameV_R > -1) { 
								BracketStep2 [CountBracket2_4 - 1, 11] = AllVariables1 [TheSameV_R, 7]; 
							}








							CountBracket2_4 = CountBracket2_4 + 1;	
							CountAddBracket = CountAddBracket + 1; 
						}

						TheSameN_R = -1; 
						TheSameV_R = -1; 
						TheSame_R = -1; 
						TheSame_R2 = -1; 

						MakeBracketR = false;


					}

				}

			}
			Pp1 = Pp1 + 1;		
		}


		for (int i = 0; i <= CountOfVariables1 - 1; i++) {
			if (AllVariables1 [i, 3] > -1) {
				AllVariables1 [i, 8] = AllSymbols1 [AllVariables1 [i, 3], 3]; 
				AllVariables1 [i, 3] = AllSymbols1 [AllVariables1 [i, 3], 0]; 
			}




		}












		CountBracket = 0;
		string sBracketStep = ";";
		Pp1 = 0;
		while (Pp1 <= sVariable.Length - 1) {

			if (sVariable [Pp1] != Symbols2 [0]) { 

				if ((sVariable [Pp1] == Bracket_R [0]) |
					(sVariable [Pp1] == Bracket_R [2])) { 
					sBracketStep = sBracketStep + Pp1.ToString () + ";";
					CountBracket = CountBracket + 1;
				}
			}
			Pp1 = Pp1 + 1;			
		}


		BoolTryParse = false;

		BracketStep = new int[CountBracket,14]; 
		int[] BracketStep_by2 = new int[CountBracket]; 

		BracketStep_N = new float[CountBracket]; 
		BracketStep_T = new string[CountBracket]; 



		Pp0 = 0;	
		Pp1 = 0;	
		for (int i = 0; i <= CountBracket - 1; i++) {
			Pp0 = Pp1;	
			Pp1 = sBracketStep.IndexOf (";", Pp0 + 1);	

			if ((Pp0 > -1) & (Pp1 > -1)) {			


				BoolTryParse = int.TryParse (sBracketStep.Substring (Pp0 + 1, Pp1 - Pp0 - 1), out BracketStep [i, 1]); 
				if (BoolTryParse == true) {	
					for (int j = 0; j <= CountBracket2_4 - 1; j++) {	
						if (BracketStep2 [j, 1] == BracketStep [i, 1]) {
							BracketStep_by2 [j] = i; 
							BracketStep [i, 0] = BracketStep2 [j, 0]; 
							BracketStep [i, 2] = BracketStep2 [j, 2]; 
							if (BracketStep2 [j, 5] > -1) {
								BracketStep [i, 3] = AllSymbols1 [BracketStep2 [j, 5], 0]; 
								BracketStep [i, 10] = AllSymbols1 [BracketStep2 [j, 5], 3]; 
							} else {
								BracketStep [i, 3] = -1;
								BracketStep [i, 10] = -1;
							}

							BracketStep [i, 4] = BracketStep2 [j, 6]; 
							BracketStep [i, 5] = BracketStep2 [j, 7]; 
							if (BracketStep [i, 5]>-1) 
								AllVariables1[BracketStep [i, 5],2] = i; 
							BracketStep [i, 6] = BracketStep2 [j, 8]; 
							BracketStep [i, 7] = BracketStep2 [j, 9]; 
							BracketStep [i, 8] = BracketStep2 [j, 10]; 
							BracketStep [i, 9] = BracketStep2 [j, 11]; 














							break;
						}
					}
				}
			}		
		}







		for (int i = 0; i <= CountBracket - 1; i++) {
			if (BracketStep [i, 2] == 4) { 
				for (int j = i; j <= CountBracket - 1; j++) {
					if (BracketStep [j, 2] < 4) { 
						if ((BracketStep [i, 0] > BracketStep [j, 0]) &
							(BracketStep [i, 1] < BracketStep [j, 1])) { 



							BracketStep [i, 11] = j; 
							break;
						}
					}
				}
			} else {
				BracketStep [i, 11] = -1; 
			}

			for (int j = i; j <= CountBracket - 1; j++) {
				if ((BracketStep [i, 0] > BracketStep [j, 0]) &
					(BracketStep [i, 1] < BracketStep [j, 1])) { 
					BracketStep [i, 12] = j; 
					break;
				}
			}
		}


		for (int i = 0; i <= CountBracket - 1; i++) {	
			if (BracketStep [i, 7] > -1) {
				BracketStep [i, 7] = BracketStep_by2 [BracketStep [i, 7]]; 
			}
		}


















		for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
			if (AllVariables1 [i, 5] > -1) {
				AllVariables_N [i] = ResultVariables1 [AllVariables1 [i, 5], 0];

				if ((AllVariables1 [i, 4] == -3) | (AllVariables1 [i, 4] == 1)) { 
					AllVariables_N [i] = -AllVariables_N [i];
				}
			} else
				AllVariables_N [i] = 0;	
		}


		for (int i = 0; i <= CountOfNumbers1 - 1; i++) {	

			if ((AllNumbers1 [i, 3]==-3) | (AllNumbers1 [i, 3]==1)) { 
				AllNumbers_N [i] = -AllNumbers_N [i];
			}
		}


		sActions = "";
		string sActions2 = "";
		string sActions3 = "";
		int TypeOfAction1 = 0; 
		int TypeOfSymbol = 0; 





		CountOfActions = CountBracket+CountOfSymbols1
			-CountOfCommas1-CountOfUnActSymbols1; 

		AllActions = new int[CountOfActions+1,16]; 

		AllActions_N = new float[CountOfActions+1,3]; 

		AllActions_T = new string[CountOfActions+1]; 
		CountOfActions = 0; 
		int CountOfExcessCommas = 0; 

		float AllPartResult1 = 0; 
		string AllPartResultText = ""; 
		float SecondPartResult1 = 0; 
		string MinusBefore = "+"; 
		string VariableBefore = ""; 
		string TextMainBracket = ""; 
		int o = 0;
		string s__0 = "";
		string s__1 = "";
		float[] AllPartResultMass = new float[1];
		for (int i = 0; i <= CountBracket - 1; i++) {	
			if ((BracketStep [i, 0] > -1) &
				(BracketStep [i, 1] > -1)) {









				Pp1 = BracketStep [i, 0] + 1;
				TypeOfAction1 = -1; 
				TypeOfSymbol = -1; 
				AllPartResult1 = 0; 
				sActions2 = "";
				sActions3 = "";

				AllActions[CountOfActions,0] = -1; 
				AllActions[CountOfActions,1] = -1; 
				AllActions[CountOfActions,2] = -1; 
				AllActions[CountOfActions,3] = -1; 
				AllActions[CountOfActions,4] = -1; 
				AllActions[CountOfActions,5] = -1; 
				AllActions[CountOfActions,6] = -1; 
				AllActions[CountOfActions,7] = -1; 
				AllActions[CountOfActions,8] = -1; 
				AllActions[CountOfActions,9] = -1; 
				AllActions[CountOfActions,10] = -1; 
				AllActions[CountOfActions,11] = -1; 
				AllActions[CountOfActions,12] = -1; 
				AllActions[CountOfActions,13] = -1; 
				AllActions[CountOfActions,14] = -1; 
				AllActions[CountOfActions,15] = -1; 
				AllActions_N[CountOfActions,0] = 0; 
				AllActions_N[CountOfActions,1] = 0; 
				AllActions_N[CountOfActions,2] = 0; 


				while (Pp1 <= BracketStep [i, 1] - 1) {

					if (sVariable [Pp1] != Symbols2 [0]) { 


						if (sVariable [Pp1] == "_".ToCharArray () [0]) { 

							for (int j = 0; j <= CountOfSymbols1 - 1; j++) {	
								if (AllSymbols1 [j, 0] == Pp1) { 
									if (sActions2.Length == 0) 
										AllActions[CountOfActions,1] = j; 
									else AllActions[CountOfActions,7] = j; 
									break;
								}
							}

						} else if (sVariable [Pp1] == Symbols [0]) { 
							if (stext [Pp1] == Symbols [2]) { 
								TypeOfAction1 = 2; 
							} else if (stext [Pp1] == Symbols [3]) { 
								TypeOfAction1 = 3; 
							} else if (stext [Pp1] == Symbols [4]) { 
								TypeOfAction1 = 4; 
							} 

							for (int j = 0; j <= CountOfSymbols1 - 1; j++) {	
								if (AllSymbols1 [j, 0] == Pp1) { 
									AllActions[CountOfActions,0] = AllSymbols1 [j, 1]; 
									AllActions[CountOfActions,6] = j; 
									break;
								}
							}

						} else if (sVariable [Pp1] == Symbols [5]) { 
							TypeOfAction1 = 5; 
						} else if (sVariable [Pp1] == Symbols2 [4]) { 
							TypeOfSymbol = 0; 
							for (int j = 0; j <= CountOfNumbers1 - 1; j++) {	
								if (AllNumbers1 [j, 0] == Pp1) { 

									if (AllActions[CountOfActions,2] == -1) { 
										AllActions[CountOfActions,2] = 0; 
										AllActions[CountOfActions,3] = j; 
									} else { 
										AllActions[CountOfActions,4] = AllActions[CountOfActions,8]; 
										AllActions[CountOfActions,5] = AllActions[CountOfActions,9]; 
										AllActions[CountOfActions,8] = 0; 
										AllActions[CountOfActions,9] = j; 
									}							


									Pp1 = AllNumbers1 [j, 1]; 
									SecondPartResult1 = AllNumbers_N [j]; 

									break;
								}
							}
						} else if (sVariable [Pp1] == Symbols2 [3]) { 
							TypeOfSymbol = 1; 
							for (int j = 0; j <= CountOfVariables1 - 1; j++) {	
								if (AllVariables1 [j, 0] == Pp1) { 
									if (AllVariables1 [j, 2] > -1) { 

										if (AllActions[CountOfActions,2] == -1) { 
											AllActions[CountOfActions,2] = 3; 
											AllActions[CountOfActions,3] = j; 
										} else { 
											AllActions[CountOfActions,4] = AllActions[CountOfActions,8]; 
											AllActions[CountOfActions,5] = AllActions[CountOfActions,9]; 
											AllActions[CountOfActions,8] = 3; 
											AllActions[CountOfActions,9] = j; 
										}							


										Pp1 = BracketStep [AllVariables1 [j, 2], 1]; 
									} else { 

										if (AllActions[CountOfActions,2] == -1) { 
											AllActions[CountOfActions,2] = 1; 
											AllActions[CountOfActions,3] = j; 
										} else { 
											AllActions[CountOfActions,4] = AllActions[CountOfActions,8]; 
											AllActions[CountOfActions,5] = AllActions[CountOfActions,9]; 
											AllActions[CountOfActions,8] = 1; 
											AllActions[CountOfActions,9] = j; 
										}							


										Pp1 = AllVariables1 [j, 1]; 
									}
									SecondPartResult1 = AllVariables_N [j]; 

									break;
								}
							}
						} else if ((sVariable [Pp1] == Bracket_L [0]) | 
							(sVariable [Pp1] == Bracket_L [2])) {  
							TypeOfSymbol = 2; 
							for (int j = 0; j <= CountBracket - 1; j++) {	
								if (BracketStep [j, 0] == Pp1) { 

									if (AllActions[CountOfActions,2] == -1) { 
										AllActions[CountOfActions,2] = 2; 
										AllActions[CountOfActions,3] = j; 
									} else { 
										AllActions[CountOfActions,4] = AllActions[CountOfActions,8]; 
										AllActions[CountOfActions,5] = AllActions[CountOfActions,9]; 
										AllActions[CountOfActions,8] = 2; 
										AllActions[CountOfActions,9] = j; 
									}							


									Pp1 = BracketStep [j, 1]; 
									SecondPartResult1 = BracketStep_N [j]; 

									break;
								}
							}
						}


						if (TypeOfSymbol > -1) {

							if (TypeOfAction1 == 2) { 

								AllActions_N[CountOfActions,0] = AllPartResult1; 
								AllActions_N[CountOfActions,1] = SecondPartResult1; 


								AllPartResult1 = AllPartResult1 * SecondPartResult1;


								AllActions_N[CountOfActions,2] = AllPartResult1; 


								sActions2 = sActions2
									+ Symbols [TypeOfAction1].ToString ()
									+ SecondPartResult1.ToString ();	
								sActions3 = Symbols [TypeOfAction1].ToString ()
									+ SecondPartResult1.ToString ();

							} else if (TypeOfAction1 == 3) { 

								AllActions_N[CountOfActions,0] = AllPartResult1; 
								AllActions_N[CountOfActions,1] = SecondPartResult1; 


								AllPartResult1 = AllPartResult1 / SecondPartResult1;


								AllActions_N[CountOfActions,2] = AllPartResult1; 


								sActions2 = sActions2
									+ Symbols [TypeOfAction1].ToString ()
									+ SecondPartResult1.ToString ();
								sActions3 = Symbols [TypeOfAction1].ToString ()
									+ SecondPartResult1.ToString ();

							} else if (TypeOfAction1 == 4) { 

								AllActions_N[CountOfActions,0] = AllPartResult1; 
								AllActions_N[CountOfActions,1] = SecondPartResult1; 


								AllPartResult1 = Mathf.Pow (AllPartResult1, SecondPartResult1);


								AllActions_N[CountOfActions,2] = AllPartResult1; 


								sActions2 = sActions2
									+ Symbols [TypeOfAction1].ToString ()
									+ SecondPartResult1.ToString ();
								sActions3 = Symbols [TypeOfAction1].ToString ()
									+ SecondPartResult1.ToString ();

							} else if (TypeOfAction1 == 5) { 

								sActions2 = sActions2
									+ Symbols [TypeOfAction1].ToString ()
									+" "+ SecondPartResult1.ToString ();

							} else { 

								AllActions_N[CountOfActions,0] = AllPartResult1; 
								AllActions_N[CountOfActions,1] = SecondPartResult1; 


								AllPartResult1 = AllPartResult1 + SecondPartResult1;


								AllActions_N[CountOfActions,2] = AllPartResult1; 


								MinusBefore = "";
								if (SecondPartResult1 >= 0) {  
									if (sActions2.Length > 0) 
										MinusBefore = "+";
								}
								sActions2 = sActions2 + MinusBefore
									+ SecondPartResult1.ToString ();
								sActions3 = MinusBefore
									+ SecondPartResult1.ToString ();

							}


							if (AllActions[CountOfActions,0] < 5) { 
								if ((AllActions[CountOfActions,2] > -1) & (TypeOfAction1 != 5)) {
									int Pp__0 = -1; 
									int Pp_0 = 0; 



									int Pp_3 = 0; 
									int Pp__0M = -1; 
									int Pp_0M = 0; 



									int Pp_3M = 0; 

									if (AllActions[CountOfActions,1] > -1) { 
										Pp__0 = AllSymbols1 [AllActions[CountOfActions,1], 0]; 
										Pp__0M = AllSymbols1 [AllActions[CountOfActions,1], 3]; 
									}

									if (AllActions[CountOfActions,2] == 0) { 
										Pp_0 = AllNumbers1 [AllActions[CountOfActions,3], 0];	
										Pp_0M = AllNumbers1 [AllActions[CountOfActions,3], 4];	

									} else if ((AllActions[CountOfActions,2] == 1) | (AllActions[CountOfActions,2] == 3)) { 
										Pp_0 = AllVariables1 [AllActions[CountOfActions,3], 0];	
										Pp_0M = AllVariables1 [AllActions[CountOfActions,3], 6];	
										if (AllActions[CountOfActions,4] == -1) { 

										}
									} else if (AllActions[CountOfActions,2] == 2) { 
										Pp_0 = BracketStep [AllActions[CountOfActions,3], 0];
										Pp_0M = BracketStep [AllActions[CountOfActions,3], 8];

									}



									if (AllActions[CountOfActions,8] == 0) { 


										Pp_3 = AllNumbers1 [AllActions[CountOfActions,9], 1];
										Pp_3M = AllNumbers1 [AllActions[CountOfActions,9], 5];
									} else if ((AllActions[CountOfActions,8] == 1) | (AllActions[CountOfActions,8] == 3)) { 
										if ((AllActions[CountOfActions,8] == 1) | (AllVariables1 [AllActions[CountOfActions,9], 2] < 0)) { 


											Pp_3 = AllVariables1 [AllActions[CountOfActions,9], 1];
											Pp_3M = AllVariables1 [AllActions[CountOfActions,9], 7];
										} else { 


											Pp_3 = BracketStep [AllVariables1 [AllActions[CountOfActions,9], 2], 1];
											Pp_3M = BracketStep [AllVariables1 [AllActions[CountOfActions,9], 2], 9];
										}
									} else if (AllActions[CountOfActions,8] == 2) { 


										Pp_3 = BracketStep [AllActions[CountOfActions,9], 1];	
										Pp_3M = BracketStep [AllActions[CountOfActions,9], 9];	
									}							

									if (Pp__0 == -1) { 
										if (Pp_3 > Pp_0) {
											AllActions[CountOfActions,10] = Pp_0; 
											AllActions[CountOfActions,11] = Pp_3; 
											AllActions[CountOfActions,12] = -1; 
											AllActions[CountOfActions,13] = Pp_0M; 
											AllActions[CountOfActions,14] = Pp_3M; 
											AllActions[CountOfActions,15] = -1; 

											AllActions_T [CountOfActions] = AllActions_N [CountOfActions, 0].ToString ()
												+ sActions3; 



											CountOfActions = CountOfActions + 1; 

											AllActions[CountOfActions,0] = AllActions[CountOfActions-1,0]; 
											AllActions[CountOfActions,1] = AllActions[CountOfActions-1,1]; 
											AllActions[CountOfActions,2] = AllActions[CountOfActions-1,2]; 
											AllActions[CountOfActions,3] = AllActions[CountOfActions-1,3]; 

										}
									} else { 
										if (Pp_3 > Pp__0) {
											AllActions[CountOfActions,10] = Pp_0; 
											AllActions[CountOfActions,11] = Pp_3; 
											AllActions[CountOfActions,12] = Pp__0; 
											AllActions[CountOfActions,13] = Pp_0M; 
											AllActions[CountOfActions,14] = Pp_3M; 
											AllActions[CountOfActions,15] = Pp__0M; 

											AllActions_T [CountOfActions] = AllActions_N [CountOfActions, 0].ToString ()
												+ sActions3; 







											CountOfActions = CountOfActions + 1; 

											AllActions[CountOfActions,0] = AllActions[CountOfActions-1,0]; 
											AllActions[CountOfActions,1] = AllActions[CountOfActions-1,1]; 
											AllActions[CountOfActions,2] = AllActions[CountOfActions-1,2]; 
											AllActions[CountOfActions,3] = AllActions[CountOfActions-1,3]; 

										}
									}


								}
							} 





							TypeOfAction1 = -1; 
							TypeOfSymbol = -1; 






							AllActions[CountOfActions,4] = -1; 
							AllActions[CountOfActions,5] = -1; 
							AllActions[CountOfActions,6] = -1; 
							AllActions[CountOfActions,7] = -1; 
							AllActions[CountOfActions,8] = -1; 
							AllActions[CountOfActions,9] = -1; 

						}
					}
					Pp1 = Pp1 + 1;					



				}			



				AllActions[CountOfActions,0] = -1; 
				AllActions[CountOfActions,1] = -1; 
				AllActions[CountOfActions,2] = -1; 
				AllActions[CountOfActions,3] = -1; 
				AllActions[CountOfActions,4] = -1; 
				AllActions[CountOfActions,5] = -1; 
				AllActions[CountOfActions,6] = -1; 
				AllActions[CountOfActions,7] = -1; 
				AllActions[CountOfActions,8] = -1; 
				AllActions[CountOfActions,9] = -1; 
				AllActions_N[CountOfActions,0] = 0; 
				AllActions_N[CountOfActions,1] = 0; 
				AllActions_N[CountOfActions,2] = 0; 



				AllPartResultText = AllPartResult1.ToString ();

				if (BracketStep [i, 2] == 1) { 
					AllPartResult1 = Mathf.Abs (AllPartResult1);


					AllActions[CountOfActions,0] = 6; 

				}			



				VariableBefore = ""; 
				MinusBefore = ""; 
				CountOfExcessCommas = 0; 

				if (BracketStep [i, 5] > -1) { 

					AllActions[CountOfActions,0] = 10; 

					AllPartResultMass [0] = AllPartResult1;
					if ((BracketStep [i, 6] > 0) &
						(ResultVariables1 [AllVariables1 [BracketStep [i, 5], 5], 1] > 0)) { 
						AllPartResultText = "";
						AllPartResultMass = new float[BracketStep [i, 6] + 1];
						o = 0;
						for (int j = 0; j <= i; j++) {	
							if (BracketStep [j, 7] == i) {
								AllPartResultMass [o] = BracketStep_N [j];

								if (o < ResultVariables1 [AllVariables1 [BracketStep [i, 5], 5], 1]) { 
									AllPartResultText = AllPartResultText + ", " + AllPartResultMass [o].ToString ();

								} else {
									CountOfExcessCommas = CountOfExcessCommas+1; 
								}
								o = o + 1;
							}
						}
						if (AllPartResultText.Length > 1)
							AllPartResultText = AllPartResultText.Substring (2, AllPartResultText.Length - 2);
					}

					if ((AllVariables1 [BracketStep [i, 5], 4] == -3) |
						(AllVariables1 [BracketStep [i, 5], 4] == 1)) { 
						if (AllVariables1 [BracketStep [i, 5], 5] >= CountVariables) { 
							AllVariables_N [BracketStep [i, 5]] = 
								-FindVariables (AllVariables1 [BracketStep [i, 5], 5], (BracketStep [i, 6]+1), AllPartResultMass); 
						} else { 
							AllVariables_N [BracketStep [i, 5]] = 
								-FindMyVariables (AllVariables1 [BracketStep [i, 5], 5], (BracketStep [i, 6]+1), AllPartResultMass); 
						}

						MinusBefore = "-"; 


						for (int j = 0; j <= CountOfSymbols1 - 1; j++) {	
							if (AllSymbols1 [j, 0] == AllVariables1 [BracketStep [i, 5], 3]) { 
								AllActions[CountOfActions,1] = j; 
								break;
							}
						}

					} else {								
						if (AllVariables1 [BracketStep [i, 5], 5] >= CountVariables) { 
							AllVariables_N [BracketStep [i, 5]] = 
								FindVariables (AllVariables1 [BracketStep [i, 5], 5], (BracketStep [i, 6]+1), AllPartResultMass); 
						} else { 
							AllVariables_N [BracketStep [i, 5]] = 
								FindMyVariables (AllVariables1 [BracketStep [i, 5], 5], (BracketStep [i, 6]+1), AllPartResultMass); 
						}


						if (AllVariables1 [BracketStep [i, 5], 4] != -1) {
							MinusBefore = "+"; 

							for (int j = 0; j <= CountOfSymbols1 - 1; j++) {	
								if (AllSymbols1 [j, 0] == AllVariables1 [BracketStep [i, 5], 3]) { 
									AllActions[CountOfActions,1] = j; 
									break;
								}
							}

						}
					}


					AllActions[CountOfActions,2] = 3; 
					AllActions[CountOfActions,3] = BracketStep [i, 5]; 
					AllActions[CountOfActions,4] = 3; 
					AllActions[CountOfActions,5] = BracketStep [i, 5]; 
					AllActions[CountOfActions,8] = 2; 
					AllActions[CountOfActions,9] = i; 
					AllActions_N[CountOfActions,2] = AllVariables_N [BracketStep [i, 5]]; 


					BracketStep_N [i] = AllVariables_N [BracketStep [i, 5]];
					VariableBefore = NameVariables1 [AllVariables1 [BracketStep [i, 5], 5], 0]; 
				} else { 

					AllActions[CountOfActions,0] = BracketStep [i, 2]+5; 


					if ((BracketStep [i, 4] == -3) | (BracketStep [i, 4] == 1)) { 
						BracketStep_N [i] = -AllPartResult1;
						MinusBefore = "-"; 


						for (int j = 0; j <= CountOfSymbols1 - 1; j++) {	
							if (AllSymbols1 [j, 0] == BracketStep [i, 3]) { 
								AllActions[CountOfActions,1] = j; 
								break;
							}
						}

					} else {
						BracketStep_N [i] = AllPartResult1;	

						if (BracketStep [i, 4] != -1) 
						{
							MinusBefore = "+"; 

							for (int j = 0; j <= CountOfSymbols1 - 1; j++) {	
								if (AllSymbols1 [j, 0] == BracketStep [i, 3]) { 
									AllActions[CountOfActions,1] = j; 
									break;
								}
							}

						}
					}

					AllActions[CountOfActions,2] = 2; 
					AllActions[CountOfActions,3] = i; 
					AllActions[CountOfActions,4] = 2; 
					AllActions[CountOfActions,5] = i; 
					AllActions[CountOfActions,8] = 2; 
					AllActions[CountOfActions,9] = i; 
					AllActions_N[CountOfActions,2] = BracketStep_N [i]; 

				}

				if ((BracketStep [i, 2] == 4) | (i == (CountBracket-1))) { 
					TextMainBracket = "*"; 
				}
				else TextMainBracket = " "; 

				BracketStep [i, 13] = CountOfActions; 















				s__0 = MinusBefore + VariableBefore
					+ Bracket_L [BracketStep [i, 2]].ToString () + AllPartResultText
					+ Bracket_R [BracketStep [i, 2]].ToString ();


				if (CountOfExcessCommas>0) { 
					s__1 = MinusBefore + VariableBefore
						+ Bracket_L [BracketStep [i, 2]].ToString () + sActions2
						+ Bracket_R [BracketStep [i, 2]].ToString ();
					if (sActions2 != AllPartResultText) {		
						s__0 = s__1 + " = " + s__0;
					}
				}

				sActions = sActions+TextMainBracket+(i+1).ToString() + ": " + s__0 + " = "
					+ BracketStep_N [i] + System.Environment.NewLine;

				BracketStep_T[i] = s__0;

				if (AllActions[CountOfActions,0] < 5) { 
				} else { 
					int Pp__0 = -1; 
					int Pp_0 = 0; 


					int Pp_3 = 0; 
					int Pp__0M = -1; 
					int Pp_0M = 0; 


					int Pp_3M = 0; 

					if (AllActions[CountOfActions,1] > -1) { 
						Pp__0 = AllSymbols1 [AllActions[CountOfActions,1], 0]; 
						Pp__0M = AllSymbols1 [AllActions[CountOfActions,1], 3]; 
					}


					if (AllActions[CountOfActions,2] == 3) { 
						Pp_0 = AllVariables1 [AllActions[CountOfActions,3], 0];	
						Pp_0M = AllVariables1 [AllActions[CountOfActions,3], 6];	


					} else if (AllActions[CountOfActions,2] == 2) { 
						Pp_0 = BracketStep [AllActions[CountOfActions,3], 0];
						Pp_0M = BracketStep [AllActions[CountOfActions,3], 8];


					}



					Pp_3 = BracketStep [AllActions[CountOfActions,9], 1];
					Pp_3M = BracketStep [AllActions[CountOfActions,9], 9];

					if (Pp__0 == -1) { 
						if (Pp_3 > Pp_0) {
							AllActions[CountOfActions,10] = Pp_0; 
							AllActions[CountOfActions,11] = Pp_3; 
							AllActions[CountOfActions,12] = -1; 
							AllActions[CountOfActions,13] = Pp_0M; 
							AllActions[CountOfActions,14] = Pp_3M; 
							AllActions[CountOfActions,15] = -1; 
							AllActions_T[CountOfActions] = s__0; 


							CountOfActions = CountOfActions + 1; 

						}
					} else { 
						if (Pp_3 > Pp__0) {
							AllActions[CountOfActions,10] = Pp_0; 
							AllActions[CountOfActions,11] = Pp_3; 
							AllActions[CountOfActions,12] = Pp__0; 
							AllActions[CountOfActions,13] = Pp_0M; 
							AllActions[CountOfActions,14] = Pp_3M; 
							AllActions[CountOfActions,15] = Pp__0M; 
							AllActions_T[CountOfActions] = s__0; 


							CountOfActions = CountOfActions + 1; 

						}
					}


				}

			}
		}










		if ((FindResultOnly == false)  
			& (CleanSpaces == true)) { 



































			int i1 = 0;
			int k1 = 0;

			if (ChangeMainFormula == true) { 

				while (i1 <= sCleanVariable.Length - 1) {
					if (sCleanVariable [i1] == " ".ToCharArray () [0]) {
						sClean = sClean.Remove (i1, 1);
						sCleanVariable = sCleanVariable.Remove (i1, 1);	


						for (k1 = 0; k1 <= CountOfSymbols1 - 1; k1++) {
							if (i1 < AllSymbols1 [k1, 3]) { 
								AllSymbols1 [k1, 3] = AllSymbols1 [k1, 3] - 1;
							}
						}



						for (k1 = 0; k1 <= CountOfNumbers1 - 1; k1++) {
							if (i1 < AllNumbers1 [k1, 4]) { 
								AllNumbers1 [k1, 4] = AllNumbers1 [k1, 4] - 1;	
								AllNumbers1 [k1, 5] = AllNumbers1 [k1, 5] - 1;		
							}



						}



						for (k1 = 0; k1 <= CountOfVariables1 - 1; k1++) {
							if (i1 < AllVariables1 [k1, 8]) { 
								AllVariables1 [k1, 8] = AllVariables1 [k1, 8] - 1;		
							}
							if (i1 < AllVariables1 [k1, 6]) { 
								AllVariables1 [k1, 6] = AllVariables1 [k1, 6] - 1;	
								AllVariables1 [k1, 7] = AllVariables1 [k1, 7] - 1;		
							}



						}



						for (k1 = 0; k1 <= CountBracket - 1; k1++) {
							if (i1 < BracketStep [k1, 10]) { 
								BracketStep [k1, 10] = BracketStep [k1, 10] - 1;		
							}
							if (i1 < BracketStep [k1, 8]) { 
								BracketStep [k1, 8] = BracketStep [k1, 8] - 1;	
							}
							if (i1 < BracketStep [k1, 9]) { 
								BracketStep [k1, 9] = BracketStep [k1, 9] - 1;		
							}
						}





						for (k1 = 0; k1 <= CountOfActions - 1; k1++) {
							if (i1 < AllActions [k1, 15]) { 
								AllActions [k1, 15] = AllActions [k1, 15] - 1;		
							}
							if (i1 < AllActions [k1, 13]) { 
								AllActions [k1, 13] = AllActions [k1, 13] - 1;			
							}
							if (i1 < AllActions [k1, 14]) { 
								AllActions [k1, 14] = AllActions [k1, 14] - 1;		
							}
						}


						i1 = i1 - 1;
					}
					i1 = i1 + 1;
				}
			}



			i1 = 0;
			while (i1<=sVariable.Length - 1) {
				if (sVariable[i1] == " ".ToCharArray()[0]) {
					stext = stext.Remove (i1,1);
					sVariable = sVariable.Remove (i1,1);	



					for (k1 = 0; k1 <= CountOfSymbols1-1; k1++) {
						if (i1 < AllSymbols1 [k1, 0]) { 
							AllSymbols1 [k1, 0] = AllSymbols1 [k1, 0] - 1;
						}
					}




					for (k1 = 0; k1 <= CountOfNumbers1-1; k1++) {
						if (i1 < AllNumbers1 [k1, 0]) { 
							AllNumbers1 [k1, 0] = AllNumbers1 [k1, 0] - 1;	
							AllNumbers1 [k1, 1] = AllNumbers1 [k1, 1] - 1;	
						}



					}



					for (k1 = 0; k1 <= CountOfVariables1-1; k1++) {
						if (i1 < AllVariables1 [k1, 3]) { 
							AllVariables1 [k1, 3] = AllVariables1 [k1, 3] - 1;		
						}
						if (i1 < AllVariables1 [k1, 0]) { 
							AllVariables1 [k1, 0] = AllVariables1 [k1, 0] - 1;	
							AllVariables1 [k1, 1] = AllVariables1 [k1, 1] - 1;		
						}



					}



					for (k1 = 0; k1 <= CountBracket-1; k1++) {
						if (i1 < BracketStep [k1, 3]) { 
							BracketStep [k1, 3] = BracketStep [k1, 3] - 1;		
						}
						if (i1 < BracketStep [k1, 0]) { 
							BracketStep [k1, 0] = BracketStep [k1, 0] - 1;		
						}
						if (i1 < BracketStep [k1, 1]) { 
							BracketStep [k1, 1] = BracketStep [k1, 1] - 1;		
						}
					}


					for (k1 = 0; k1 <= CountOfActions-1; k1++) {
						if (i1 < AllActions [k1, 12]) { 
							AllActions [k1, 12] = AllActions [k1, 12] - 1;		
						}
						if (i1 < AllActions [k1, 10]) { 
							AllActions [k1, 10] = AllActions [k1, 10] - 1;			
						}
						if (i1 < AllActions [k1, 11]) { 
							AllActions [k1, 11] = AllActions [k1, 11] - 1;		
						}
					}

					i1 = i1-1;
				}
				i1 = i1 + 1;
			}


		}





















		sActions = BracketStep_N [CountBracket-1].ToString () 
			+ System.Environment.NewLine+sActions;

		sTextProperty = new string[2];
		sTextProperty[0] = sCleanVariable; 
		sTextProperty[1] = sVariable; 

		FindResultOnly = false; 



		return BracketStep_N [CountBracket-1];
	}

	public static bool AddVariables () { 
		NameVariables1 [CountVariables,0] = "Abs";
		NameVariables1 [CountVariables + 1,0] = "Floor";
		NameVariables1 [CountVariables + 2,0] = "Ceil";
		NameVariables1 [CountVariables + 3,0] = "Round";

		for (int i = 0; i <= (CountVariables+CountVariables2)-1; i++) {
			NameVariables1[i,1] = NameVariables1[i,0].ToUpper(); 
		}
		return true;
	}

	public static float FindVariables (int NumOfVariable, int CountOfNumber_1, float[] Number_1) { 

		if (NumOfVariable == CountVariables) { 
			return Mathf.Abs (Number_1[0]); 
		} else if (NumOfVariable == CountVariables + 1) { 
			return Mathf.Floor (Number_1[0]); 
		} else if (NumOfVariable == CountVariables + 2) { 
			return Mathf.Ceil (Number_1[0]); 
		} else if (NumOfVariable == CountVariables + 3) { 
			return Mathf.Round (Number_1[0]); 
		}
		return ResultVariables1[NumOfVariable,0];
	}

	public static float FindMyVariables (int NumOfVariable, int CountOfNumber_1, float[] Number_1) { 
		string [] WhatToCompare = new string[2];
		WhatToCompare[0] = "Gg1".ToUpper();
		WhatToCompare[1] = "K+Jf".ToUpper();

		if (NameVariables1[NumOfVariable,1] == WhatToCompare[0]) { 

			if (CountOfNumber_1 >= ResultVariables1 [NumOfVariable, 1] & 
				(Number_1.Length>=2)) { 
				return (Number_1 [0] * 2 - Number_1 [1]);
			} else  
				return (Number_1 [0]);

		} else if (NameVariables1[NumOfVariable,1] == WhatToCompare[1]) { 

			if ((CountOfNumber_1 >= ResultVariables1 [NumOfVariable, 1]) & 
				(Number_1.Length>=2)) { 
				return (Number_1 [0] + Number_1 [1]);
			} else  
				return (Number_1 [0]);
		}
		return ResultVariables1 [NumOfVariable, 0];
	}
}