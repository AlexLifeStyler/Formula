﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System; 
using UnityEngine.EventSystems; 
using System.IO; 
using System.Text.RegularExpressions; 

public class Formula1_Properties : MonoBehaviour
{


	[HideInInspector]
	public string Text_Formula = "(+AbsG(---(R+|B|^+2)-(-2*-|G[R]|)"
		+ "+-+-RoundB[+-+-K+Jf[-(10+5/2.3)+R,-(10+5/2.3)-5,-(10+5/2.3)+5]*2])+(|-B/2-R*-2|)*4+|"
		+ "-+-Gg1R[-1.5,-2]|)"; 

	[HideInInspector]
	public string Text_Formula2 = " "; 
	[HideInInspector]
	public string Text_Formula_ch = " "; 
	[HideInInspector]
	public string Text_Formula_ch2 = " "; 
	[HideInInspector]
	public string Text_Action = " "; 
	[HideInInspector]
	public string[] Text_Property; 
	[HideInInspector]
	public int[,] AllSymbols1; 
	[HideInInspector]
	public int CountOfSymbols1 = 0; 
	[HideInInspector]
	public int CountOfUnActSymbols1 = 0; 
	[HideInInspector]
	public int CountOfCommas1 = 0; 
	[HideInInspector]
	public int[,] AllNumbers1; 
	[HideInInspector]
	public int CountOfNumbers1 = 0; 
	[HideInInspector]
	public int[,] AllVariables1; 
	[HideInInspector]
	public int CountOfVariables1 = 0; 
	[HideInInspector]
	public float[] AllVariables_N; 
	[HideInInspector]
	public int[,] BracketStep; 
	[HideInInspector]
	public int CountBracket = 0; 
	[HideInInspector]
	public int CountAddBracket = 0; 
	[HideInInspector]
	public float[] BracketStep_N; 
	[HideInInspector]
	public string[] BracketStep_T; 
	[HideInInspector]
	public int[,] AllActions; 
	[HideInInspector]
	public int CountOfActions = 0; 
	[HideInInspector]
	public float[,] AllActions_N; 
	[HideInInspector]
	public string[] AllActions_T; 







	public int[,] PosOfBracketAction; 

	public ListView ListView1;
	[HideInInspector]
	public string[] NameOfActions = { "+ сложение", "- вычитание", "* умножение",
		"/ деление", "^ степень", "( круглая скобка", "| модульная скобка",
		"[ квадратная скобка", "{ фигурная скобка", "( доп. круглая скобка", 
		"переменная со скобкой" }; 


	void Start()
	{

	}

	public bool SolveFormulaProcedure() { 

		Text_Formula2 = ListView1.TextField_1 [0];

		Formula1.CleanVariables = ListView1.Show_Hide [5]; 

		Formula1.CleanSpaces = ListView1.Show_Hide [6]; 

		Formula1.ChangeMainFormula = ListView1.Show_Hide [4]; 

		if (ListView1.Show_Hide [7]==true) { 
			Formula1.CheckRegistr = 0; 
		} else {
			Formula1.CheckRegistr = 1; 
		}

		string sClean = ""; 

		Formula1.SolveFormula (Text_Formula2 
			, out sClean
			, out Text_Formula_ch, out Text_Action, out Text_Property
			, out AllSymbols1, out CountOfSymbols1
			, out CountOfUnActSymbols1, out CountOfCommas1
			, out AllNumbers1, out CountOfNumbers1
			, out AllVariables1, out CountOfVariables1
			, out AllVariables_N
			, out BracketStep, out CountBracket, out CountAddBracket
			, out BracketStep_N
			, out BracketStep_T
			, out AllActions, out CountOfActions
			, out AllActions_N
			, out AllActions_T); 

		if (ListView1.Show_Hide [4] == true) { 
			Text_Formula = sClean;
			Text_Formula2 = sClean;
			ListView1.TextField_1 [0] = sClean;
		}			

		Text_Formula = Text_Formula2; 
		Text_Formula_ch2 = Text_Formula_ch; 

		ShowPosInBracketAction (); 

		ListView1.TextField_1 [0] = Text_Formula;
		ListView1.TextField_1 [1] = Text_Formula_ch;
		ListView1.TextField_1 [2] = Text_Action;

		ListView1.ChangeRowsInTable (1, CountOfActions); 

		MakeTextWithActions (); 
		ListView1.AddActionsInTable2 (); 

		ListView1.ChangeHeightOfTF (0, Text_Formula); 
		ListView1.ChangeHeightOfTF (1, Text_Formula_ch); 
		ListView1.ChangeHeightOfTF (2, Text_Action); 

		return true;
	}


	[HideInInspector]
	public int[,] changed_AllActions; 
	[HideInInspector]
	public int[,] changed_AllVariables1; 
	[HideInInspector]
	public int[,] changed_BracketStep; 
	[HideInInspector]
	public string[] AllActionsPlus1; 
	[HideInInspector]
	public int[,] AllPosPlus1; 
	[HideInInspector]
	public int[] MaxLengthOfText; 

	public bool MakeTextWithActions ()
	{ 


		changed_AllActions = new int[CountOfActions,16];
		for (int k1 = 0; k1 < CountOfActions; k1++) {
			for (int k2 = 0; k2 < 16; k2++) {
				changed_AllActions[k1,k2] = AllActions[k1,k2]; 
			}
		}

		changed_AllVariables1 = new int[CountOfVariables1,9];
		for (int k1 = 0; k1 < CountOfVariables1; k1++) {
			for (int k2 = 0; k2 < 9; k2++) {
				changed_AllVariables1[k1,k2] = AllVariables1[k1,k2]; 
			}
		}

		changed_BracketStep = new int[CountBracket,14];
		for (int k1 = 0; k1 < CountBracket; k1++) {
			for (int k2 = 0; k2 < 14; k2++) {
				changed_BracketStep[k1,k2] = BracketStep[k1,k2]; 
			}
		}

		AllActionsPlus1 = new string[CountOfActions+1];
		AllPosPlus1 = new int[CountOfActions+1,5];
		MaxLengthOfText = new int[2]; 
		MaxLengthOfText[0] = -1; 
		MaxLengthOfText[1] = -1; 


		int[] PosInText = new int[5];


		int Length1 = 0;

		int NewLine2 = 0;
		float NewResult1 = 0;
		AllActionsPlus1 [0] = Text_Formula_ch;
		AllActionsPlus1 [1] = Text_Formula_ch;


		PosInText = ChangeShowPosInText_Action (0); 
		Length1 = PosInText [4]-PosInText [3]+1;

		NewLine2 = AllActionsPlus1 [0].Length+1;

		AllPosPlus1[0,0] = 0;
		AllPosPlus1[0,1] = 0;
		AllPosPlus1[0,2] = 0;
		AllPosPlus1[0,3] = PosInText [3];
		AllPosPlus1[0,4] = AllPosPlus1[0,3]+Length1;

		if (AllActionsPlus1 [0].Length>MaxLengthOfText[0]) {
			MaxLengthOfText[0] = AllActionsPlus1 [0].Length; 
			MaxLengthOfText[1] = 0; 
		}



		for (int k1 = 0; k1 < CountOfActions; k1++) {
			PosInText = ChangeShowPosInText_Action (k1); 


			Length1 = PosInText [4]-PosInText [3]+1;



			if (changed_AllActions [k1, 1] > -1) { 
				if (AllSymbols1 [changed_AllActions [k1, 1], 2] == 1) { 
					NewResult1 = AllActions_N [k1, 2]; 

				} else { 
					if (AllSymbols1 [changed_AllActions [k1, 1], 1] == 1) { 
						NewResult1 = Mathf.Abs (AllActions_N [k1, 2]); 

					} else { 
						NewResult1 = AllActions_N [k1, 2]; 

					}
				}
			} else {
				NewResult1 = AllActions_N [k1, 2]; 

			}

			AllPosPlus1[k1+1,0] = NewLine2;
			AllActionsPlus1 [k1+1] = AllActionsPlus1 [k1+1].Remove(PosInText [3], Length1);
			AllActionsPlus1 [k1+1] = AllActionsPlus1 [k1+1].Insert(PosInText [3], NewResult1.ToString());
			AllPosPlus1[k1+1,1] = PosInText [3];
			AllPosPlus1[k1+1,2] = PosInText [3]+(NewResult1.ToString().Length);
			AllPosPlus1[k1+1,3] = PosInText [3];
			AllPosPlus1[k1+1,4] = AllPosPlus1[k1+1,3]+Length1;
			if (k1 + 2 <= CountOfActions) {
				AllActionsPlus1 [k1 + 2] = AllActionsPlus1 [k1+1];			
			}


			NewLine2 = NewLine2+AllActionsPlus1 [k1+1].Length+1;
			if (AllActionsPlus1 [k1+1].Length>MaxLengthOfText[0]) {
				MaxLengthOfText[0] = AllActionsPlus1 [k1+1].Length; 
				MaxLengthOfText[1] = k1+1; 
			}

			Length1 = NewResult1.ToString().Length-(Length1);
			ChangePosWithActions (PosInText [3], Length1); 











		}

		return true;
	}


	public bool ChangePosWithActions (int Pos1, int Length1)
	{ 

		string[] AllActionsPlus = new string[CountOfActions];
		int[] PosInText = new int[5];



		for (int k1 = 0; k1 < CountOfActions; k1++) {
			for (int k2 = 10; k2 < 16; k2++) {	
				if (Pos1 < changed_AllActions [k1, k2]) {
					changed_AllActions [k1, k2] = changed_AllActions [k1, k2] + Length1; 
				}
			}
		}

		for (int k1 = 0; k1 < CountBracket; k1++)
		{
			for (int k2 = 0; k2 < 2; k2++) {	
				if (Pos1 < changed_BracketStep[k1, k2]) {
					changed_BracketStep[k1, k2] = changed_BracketStep[k1, k2] + Length1; 
				}
			}
		}



		return true;
	}


	public int [] ChangeShowPosInText_Action(int Numline)
	{ 

		int[] Varriables123 = new int[5];
		int StartPos = 0; 
		int EndPos = 0; 
		int StartPos2 = 0; 
		int EndPos2 = 0; 

		if ((Numline > -1) & (Numline < CountOfActions))
		{ 


			if (changed_AllActions[Numline, 15] == -1)
			{ 
				StartPos = changed_AllActions[Numline, 13] - 1; 
			}
			else
			{ 



				if (changed_AllActions [Numline, 1] > -1) { 
					if (AllSymbols1[changed_AllActions [Numline, 1],2] == 1) { 

						StartPos = changed_AllActions[Numline, 15] - 1; 

					} else { 

						StartPos = changed_AllActions[Numline, 13] - 1; 
					}	
				} else { 

					StartPos = changed_AllActions[Numline, 13] - 1; 
				}			
			}
			EndPos = changed_AllActions[Numline, 14] - 1; 


			if (changed_AllActions [Numline, 12] == -1) { 

				StartPos2 = changed_AllActions [Numline, 10]; 

			} else { 



				if (changed_AllActions [Numline, 1] > -1) { 


					if (AllSymbols1[changed_AllActions [Numline, 1],2] == 1) { 

						StartPos2 = changed_AllActions[Numline, 12]; 

					} else { 

						StartPos2 = changed_AllActions[Numline, 10]; 
					}	
				} else { 

					StartPos2 = changed_AllActions[Numline, 10]; 
				}


			}
			EndPos2 = changed_AllActions[Numline, 11]; 


			if (StartPos < 0)
				StartPos = 0;
			if (EndPos < 0)
				EndPos = 0;
			else if (EndPos >= Text_Formula.Length)
				EndPos = Text_Formula.Length - 1;
			if (StartPos2 < 0)
				StartPos2 = 0;
			if (EndPos2 < 0)
				EndPos2 = 0;
			else if (EndPos2 >= Text_Formula_ch.Length)
				EndPos2 = Text_Formula_ch.Length - 1;






			int Numline1 = 0;
			if ((changed_AllActions[Numline, 0] > 4) & (changed_AllActions[Numline, 0] < 10))
			{ 
				Numline1 = changed_AllActions[Numline, 3];

			}
			else if (changed_AllActions[Numline, 0] == 10)
			{ 
				Numline1 = changed_AllVariables1[changed_AllActions[Numline, 3], 2];

			}
			else
			{
				for (int i = 0; i < CountBracket; i++)
				{
					if ((changed_BracketStep[i, 0] < StartPos2) &
						(changed_BracketStep[i, 1] > StartPos2))
					{ 
						Numline1 = i;

						break;
					}
				}		    	
			}

			Varriables123[0] = Numline1; 
			Varriables123[1] = StartPos; 
			Varriables123[2] = EndPos; 
			Varriables123[3] = StartPos2; 
			Varriables123[4] = EndPos2; 

			return Varriables123;



		}
		else
		{
			Varriables123[0] = -1;
			Varriables123[1] = -1;
			Varriables123[2] = -1;
			Varriables123[3] = -1;
			Varriables123[4] = -1;
		}

		return Varriables123;
	}








	public int NumberBracketsInText (int TextNumber, int PosInText)
	{ 

		PosInText = PosInText+(1-TextNumber);
		int TN1 = 10+(1-TextNumber)*3;
		int TN2 = 11+(1-TextNumber)*3;
		int ACtionNumber1 = -1;

		for (int k1 = 0; k1 < CountOfActions; k1++) {
			if ((PosInText >= AllActions [k1, TN1]) & 
				(PosInText <= AllActions [k1, TN2])) {
				ACtionNumber1 = k1;
				break;
			}
		}

		return ACtionNumber1;
	}



	public int [] ShowPosInText_Action(int Numline)
	{ 

		int[] Varriables123 = new int[5];
		int StartPos = 0; 
		int EndPos = 0; 
		int StartPos2 = 0; 
		int EndPos2 = 0; 

		if ((Numline > -1) & (Numline < CountOfActions))
		{ 

			if (AllActions[Numline, 15] == -1)
			{ 
				StartPos = AllActions[Numline, 13] - 1; 
			}
			else
			{ 
				StartPos = AllActions[Numline, 15] - 1; 
			}
			EndPos = AllActions[Numline, 14] - 1; 


			if (AllActions[Numline, 12] == -1)
			{ 
				StartPos2 = AllActions[Numline, 10]; 
			}
			else
			{ 
				StartPos2 = AllActions[Numline, 12]; 
			}
			EndPos2 = AllActions[Numline, 11]; 

			if (StartPos < 0)
				StartPos = 0;
			if (EndPos < 0)
				EndPos = 0;
			else if (EndPos >= Text_Formula.Length)
				EndPos = Text_Formula.Length - 1;
			if (StartPos2 < 0)
				StartPos2 = 0;
			if (EndPos2 < 0)
				EndPos2 = 0;
			else if (EndPos2 >= Text_Formula_ch.Length)
				EndPos2 = Text_Formula_ch.Length - 1;






			int Numline1 = 0;
			if ((AllActions[Numline, 0] > 4) & (AllActions[Numline, 0] < 10))
			{ 
				Numline1 = AllActions[Numline, 3];

			}
			else if (AllActions[Numline, 0] == 10)
			{ 
				Numline1 = AllVariables1[AllActions[Numline, 3], 2];

			}
			else
			{
				for (int i = 0; i < CountBracket; i++)
				{
					if ((BracketStep[i, 0] < StartPos2) &
						(BracketStep[i, 1] > StartPos2))
					{ 
						Numline1 = i;

						break;
					}
				}		    	
			}

			Varriables123[0] = Numline1; 
			Varriables123[1] = StartPos; 
			Varriables123[2] = EndPos; 
			Varriables123[3] = StartPos2; 
			Varriables123[4] = EndPos2; 

			return Varriables123;



		}
		else
		{
			Varriables123[0] = -1;
			Varriables123[1] = -1;
			Varriables123[2] = -1;
			Varriables123[3] = -1;
			Varriables123[4] = -1;
		}

		return Varriables123;
	}



	public bool ShowPosInBracketAction () { 
		string NewText1 = "";
		string DopSkobki = "";
		int Correction1;
		#if UNITY_WEBGL
		Correction1 = 1; 
		#else
		Correction1 = 0;
		#endif

		int CountOfSymbols1 = BracketStep_N[CountBracket-1].ToString().Length+(2-Correction1);

		PosOfBracketAction = new int[CountBracket + 1, 5];

		for (int k1 = 0; k1 < CountBracket; k1++) {		
			DopSkobki = " ";
			if ((BracketStep [k1, 2] == 4) |
				(k1 == CountBracket - 1)) {
				DopSkobki = "*";			
			}


			NewText1 = DopSkobki + (k1+1).ToString () + ": "
				+ BracketStep_T [k1] + " = " + BracketStep_N [k1].ToString ();

			PosOfBracketAction [k1, 0] = CountOfSymbols1;

			PosOfBracketAction [k1, 1] = CountOfSymbols1+(k1+1).ToString ().Length+3;
			PosOfBracketAction [k1, 2] = PosOfBracketAction [k1, 1] + BracketStep_T [k1].Length-1;
			PosOfBracketAction [k1, 3] = PosOfBracketAction [k1, 2] + 4;
			PosOfBracketAction [k1, 4] = PosOfBracketAction [k1, 3] + BracketStep_N [k1].ToString ().Length-Correction1;






			CountOfSymbols1 = CountOfSymbols1 + NewText1.Length + (2-Correction1);
		}

		PosOfBracketAction [CountBracket, 0] = CountOfSymbols1;

		PosOfBracketAction [CountBracket, 1] = CountOfSymbols1+CountBracket.ToString ().Length+3;
		PosOfBracketAction [CountBracket, 2] = PosOfBracketAction [CountBracket, 1] + BracketStep_T [CountBracket-1].Length-1;
		PosOfBracketAction [CountBracket, 3] = PosOfBracketAction [CountBracket, 2] + 4;
		PosOfBracketAction [CountBracket, 4] = PosOfBracketAction [CountBracket, 3] + BracketStep_N [CountBracket-1].ToString ().Length-Correction1;


		return true;						
	}



	public Rect ShowPosInText (int Numline) { 

		int StartPos = 0; 
		int EndPos = 0; 
		int StartPos2 = 0; 
		int EndPos2 = 0; 
		if ((Numline > -1) & (Numline < CountBracket))
		{ 
			if ((BracketStep[Numline, 0] > -1) &
				(BracketStep[Numline, 1] > -1))
			{
				if (BracketStep[Numline, 5] > -1)
				{ 



					if (AllVariables1[BracketStep[Numline, 5], 4] != -1)
					{ 
						if ((AllVariables1[BracketStep[Numline, 5], 8] > -1) &
							(BracketStep[Numline, 9] > -1))
						{
							StartPos = AllVariables1[BracketStep[Numline, 5], 8] - 1; 
							EndPos = BracketStep[Numline, 9] - 1; 


						}
						if ((AllVariables1[BracketStep[Numline, 5], 3] > -1) &
							(BracketStep[Numline, 1] > -1))
						{
							StartPos2 = AllVariables1[BracketStep[Numline, 5], 3]; 
							EndPos2 = BracketStep[Numline, 1]; 


						}
					}
					else
					{ 
						if ((AllVariables1[BracketStep[Numline, 5], 6] > -1) &
							(BracketStep[Numline, 9] > -1))
						{
							StartPos = AllVariables1[BracketStep[Numline, 5], 6] - 1; 
							EndPos = BracketStep[Numline, 9] - 1; 


						}
						if ((AllVariables1[BracketStep[Numline, 5], 0] > -1) &
							(BracketStep[Numline, 1] > -1))
						{
							StartPos2 = AllVariables1[BracketStep[Numline, 5], 0]; 
							EndPos2 = BracketStep[Numline, 1]; 


						}
					}
				}
				else
				{ 


					if (BracketStep[Numline, 4] != -1)
					{ 
						if ((BracketStep[Numline, 10] > -1) &
							(BracketStep[Numline, 9] > -1))
						{
							StartPos = BracketStep[Numline, 10] - 1; 
							EndPos = BracketStep[Numline, 9] - 1; 


						}
						if ((BracketStep[Numline, 3] > -1) &
							(BracketStep[Numline, 1] > -1))
						{
							StartPos2 = BracketStep[Numline, 3]; 
							EndPos2 = BracketStep[Numline, 1]; 


						}
					}
					else
					{ 

						if ((BracketStep[Numline, 8] > -1) &
							(BracketStep[Numline, 9] > -1))
						{
							StartPos = BracketStep[Numline, 8] - 1; 
							EndPos = BracketStep[Numline, 9] - 1; 


						}
						if ((BracketStep[Numline, 0] > -1) &
							(BracketStep[Numline, 1] > -1))
						{
							StartPos2 = BracketStep[Numline, 0]; 
							EndPos2 = BracketStep[Numline, 1]; 


						}
					}
				}
				if (StartPos < 0) StartPos = 0;
				if (EndPos < 0) EndPos = 0;
				else if (EndPos >= Text_Formula.Length)
					EndPos = Text_Formula.Length - 1;
				if (StartPos2 < 0) StartPos2 = 0;
				if (EndPos2 < 0) EndPos2 = 0;
				else if (EndPos2 >= Text_Formula_ch.Length)
					EndPos2 = Text_Formula_ch.Length - 1;








				return new Rect(StartPos,EndPos,StartPos2,EndPos2);



			}
		} else {
			Text_Formula2 = Text_Formula;
			Text_Formula_ch2 = Text_Formula_ch;
		}
		return new Rect(-1,-1,-1,-1);
	}












	public int[] BracketsInText (int BracketLine1, int ActionLine1)
	{ 
		int[] AllPositions1 = new int[14];

		for (int k1 = 0; k1 < 14; k1++) {
			AllPositions1[k1] = -1;
		}

		if (BracketLine1 > -1) {
			bool Variable1B = true;

			if (ActionLine1 > -1) {
				if (AllActions [ActionLine1, 0] == 10) { 
					Variable1B = true;
				} else {
					Variable1B = false;
				}

				if (AllActions[ActionLine1, 0] < 5) { 
					int[] PosInText1 = new int[6];

					findAllPosTextAction(ActionLine1, out PosInText1);  


					AllPositions1 [8] = PosInText1[0]-1; 
					AllPositions1 [9] = PosInText1[1]; 
					AllPositions1 [10] = PosInText1[4]-1; 
					AllPositions1 [11] = PosInText1[2]; 
					AllPositions1 [12] = PosInText1[3] + 1; 
					AllPositions1 [13] = PosInText1[5]; 
				}

			}


			if ((Variable1B == true) & (BracketStep [BracketLine1, 5] > -1)) { 
				AllPositions1 [4] = AllVariables1 [BracketStep [BracketLine1, 5], 6]-1; 
				AllPositions1 [5] = AllVariables1 [BracketStep [BracketLine1, 5], 7]; 
				AllPositions1 [6] = AllVariables1 [BracketStep [BracketLine1, 5], 0]; 
				AllPositions1 [7] = AllVariables1 [BracketStep [BracketLine1, 5], 1] + 1; 
			}





			if (BracketStep [BracketLine1, 11] > -1) { 

				AllPositions1 [0] = BracketStep [BracketStep [BracketLine1, 11], 8]-1; 
				AllPositions1 [1] = BracketStep [BracketStep [BracketLine1, 11], 9]-1; 

			} else { 
				AllPositions1 [0] = BracketStep [BracketLine1, 8]-1; 
				AllPositions1 [1] = BracketStep [BracketLine1, 9]-1; 
			}

			AllPositions1[2] = BracketStep[BracketLine1, 0]; 
			AllPositions1[3] = BracketStep[BracketLine1, 1]; 

		}
		return AllPositions1;
	}



	public bool findAllPosTextAction(int StepAction1, out int[] PosInText1)
	{ 
		PosInText1 = new int[6];
		PosInText1[0] = 0; 
		PosInText1[1] = 0; 
		PosInText1[2] = 0; 
		PosInText1[3] = 0; 
		PosInText1[4] = 0; 
		PosInText1[5] = 0; 
		int Pp__0 = -1; 
		int Pp_0 = 0; 




		int Pp4 = -1; 
		int Pp__0M = -1; 
		int Pp_0M = 0; 




		int Pp4M = -1; 

		if (AllActions[StepAction1, 6] > -1)
		{ 
			Pp4 = AllSymbols1[AllActions[StepAction1, 6], 0]; 
			Pp4M = AllSymbols1[AllActions[StepAction1, 6], 3]; 
		}

		if (AllActions[StepAction1, 1] > -1)
		{ 
			Pp__0 = AllSymbols1[AllActions[StepAction1, 1], 0]; 
			Pp__0M = AllSymbols1[AllActions[StepAction1, 1], 3]; 
		}

		if (AllActions[StepAction1, 2] == 0)
		{ 
			Pp_0 = AllNumbers1[AllActions[StepAction1, 3], 0];
			Pp_0M = AllNumbers1[AllActions[StepAction1, 3], 4];

		}
		else if ((AllActions[StepAction1, 2] == 1) | (AllActions[StepAction1, 2] == 3))
		{ 
			Pp_0 = AllVariables1[AllActions[StepAction1, 3], 0];
			Pp_0M = AllVariables1[AllActions[StepAction1, 3], 6];
			if (AllActions[StepAction1, 4] == -1)
			{ 

			}
		}
		else if (AllActions[StepAction1, 2] == 2)
		{ 
			Pp_0 = BracketStep[AllActions[StepAction1, 3], 0];
			Pp_0M = BracketStep[AllActions[StepAction1, 3], 8];

		}







		if (Pp__0 == -1)
		{ 
			if (AllSymbols1[AllActions[StepAction1, 6], 0] > Pp_0)
			{
				PosInText1[0] = Pp_0M; 
				PosInText1[1] = AllSymbols1[AllActions[StepAction1, 6], 3] - 1; 

				PosInText1[2] = Pp_0; 
				PosInText1[3] = AllSymbols1[AllActions[StepAction1, 6], 0] - 1; 

				PosInText1[4] = Pp4M; 
				PosInText1[5] = Pp4; 





			}
		}
		else
		{ 
			if (AllSymbols1[AllActions[StepAction1, 6], 0] > Pp__0)
			{
				PosInText1[0] = Pp__0M; 
				PosInText1[1] = AllSymbols1[AllActions[StepAction1, 6], 3] - 1; 

				PosInText1[2] = Pp__0; 
				PosInText1[3] = AllSymbols1[AllActions[StepAction1, 6], 0] - 1; 

				PosInText1[4] = Pp4M; 
				PosInText1[5] = Pp4; 









			}
		}
		return true;
	}












	[HideInInspector]
	public string cikle_Text_Formula = "(+AbsG(---(R+|B|^+2)-(-2*-|G[R]|)"
		+ "+-+-RoundB[+-+-K+Jf[-(10+5/2.3)+R,-(10+5/2.3)-5,-(10+5/2.3)+5]*2])+(|-B/2-R*-2|)*4+|"
		+ "-+-Gg1R[-1.5,-2]|)"; 

	[HideInInspector]
	public string cikle_Text_Formula2 = " "; 
	[HideInInspector]
	public string cikle_Text_Formula_ch = " "; 
	[HideInInspector]
	public string cikle_Text_Formula_ch2 = " "; 
	[HideInInspector]
	public string cikle_Text_Action = " "; 
	[HideInInspector]
	public string[] cikle_Text_Property; 
	[HideInInspector]
	public int[,] cikle_AllSymbols1; 
	[HideInInspector]
	public int cikle_CountOfSymbols1 = 0; 
	[HideInInspector]
	public int cikle_CountOfUnActSymbols1 = 0; 
	[HideInInspector]
	public int cikle_CountOfCommas1 = 0; 
	[HideInInspector]
	public int[,] cikle_AllNumbers1; 
	[HideInInspector]
	public int cikle_CountOfNumbers1 = 0; 
	[HideInInspector]
	public int[,] cikle_AllVariables1; 
	[HideInInspector]
	public int cikle_CountOfVariables1 = 0; 
	[HideInInspector]
	public float[] cikle_AllVariables_N; 
	[HideInInspector]
	public int[,] cikle_BracketStep; 
	[HideInInspector]
	public int cikle_CountBracket = 0; 
	[HideInInspector]
	public int cikle_CountAddBracket = 0; 
	[HideInInspector]
	public float[] cikle_BracketStep_N; 
	[HideInInspector]
	public string[] cikle_BracketStep_T; 
	[HideInInspector]
	public int[,] cikle_AllActions; 
	[HideInInspector]
	public int cikle_CountOfActions = 0; 
	[HideInInspector]
	public float[,] cikle_AllActions_N; 
	[HideInInspector]
	public string[] cikle_AllActions_T; 







	public float cikle_SolveFormulaProcedure() { 

		cikle_Text_Formula2 = ListView1.TextField_1 [0];

		Formula1.CleanVariables = ListView1.Show_Hide [5]; 

		Formula1.CleanSpaces = ListView1.Show_Hide [6]; 

		Formula1.ChangeMainFormula = ListView1.Show_Hide [4]; 

		if (ListView1.Show_Hide [7]==true) { 
			Formula1.CheckRegistr = 0; 
		} else {
			Formula1.CheckRegistr = 1; 
		}

		string cikle_sClean = ""; 



		Formula1.FindResultOnly = true; 

		return Formula1.SolveFormula (cikle_Text_Formula2 
			, out cikle_sClean
			, out cikle_Text_Formula_ch, out cikle_Text_Action, out cikle_Text_Property
			, out cikle_AllSymbols1, out cikle_CountOfSymbols1
			, out cikle_CountOfUnActSymbols1, out cikle_CountOfCommas1
			, out cikle_AllNumbers1, out cikle_CountOfNumbers1
			, out cikle_AllVariables1, out cikle_CountOfVariables1
			, out cikle_AllVariables_N
			, out cikle_BracketStep, out cikle_CountBracket, out cikle_CountAddBracket
			, out cikle_BracketStep_N
			, out cikle_BracketStep_T
			, out cikle_AllActions, out cikle_CountOfActions
			, out cikle_AllActions_N
			, out cikle_AllActions_T); 
	}



}