﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Formula1 : MonoBehaviour {

	[HideInInspector]
	public static string [,] NameVariables1; // Названия своих переменных
	[HideInInspector]
	public static float [,] ResultVariables1; // Значения переменных
	[HideInInspector]
	public static int CountVariables; // Кол-во своих переменных
	[HideInInspector]
	public static int CountVariables2; // Кол-во стандартных переменных
	[HideInInspector]
	public static int CheckRegistr; // 0 - учитывать (A<>a, B=B), 1 - не учитывать (A=a, B=B) регистр символов
	[HideInInspector]
	public static bool CleanVariables; // false - оставить переменные в тексте как есть, true - убрать из текста лишние символы
	[HideInInspector]
	public static bool CleanSpaces; // false - оставить пробелы в тексте как есть, true - убрать из текста лишние пробелы
	[HideInInspector]
	public static bool ChangeMainFormula; // false - основная формула и её позиции не будут меняться, true - менять основную формулу и её позиции
	[HideInInspector]
	public static bool FindResultOnly; // false - будет изменен текст и сопутствующие позиции, true - текст и позиции не меняются
	//[HideInInspector]
	//public static string MistakeInText; // 0 - координаты текста с ошибкой ";0|0-5;1|8-12;"
	// (0-переменная, 1-число, 2-знак, 3-скобка)

	// Use this for initialization
	void Start () {	
		// Указать длину массива с переменными //////////////////////////////////////////
		CountVariables2 = 4; // Кол-во стандартных переменных
		CountVariables = 5; // Кол-во своих переменных
		NameVariables1 = new string[CountVariables+CountVariables2,4];
		ResultVariables1 = new float[CountVariables+CountVariables2,2];

		// Исключить ошибку с незаполненными переменными
		for (int i = 0; i <= (CountVariables+CountVariables2)-1; i++) {
			NameVariables1[i,0] = " ";
			NameVariables1[i,1] = " ";
			NameVariables1[i,2] = " ";
			NameVariables1[i,3] = "-";
			ResultVariables1[i,0] = 0;
			ResultVariables1[i,1] = 0;
		}

		CleanVariables = true; // false - оставить переменные в тексте как есть, true - убрать из текста лишние символы
		CleanSpaces = true; // false - оставить пробелы в тексте как есть, true - убрать из текста лишние пробелы
		ChangeMainFormula = false; // false - основная формула и её позиции не будут меняться, true - менять основную формулу и её позиции
		FindResultOnly = false; // false - будет изменен текст и сопутствующие позиции, true - текст и позиции не меняются
		CheckRegistr = 0; // 0 - учитывать (A<>a, B=B), 1 - не учитывать (A=a, B=B) регистр символов
		// Добавить свои переменные /////////////////////////////////////////////////
		NameVariables1[0,0] = "Gg1";
		NameVariables1[0,2] = "Переменная 0"; // Описание переменной
		NameVariables1[0,3] = "[ Любое число , от 0 до 255 ]"; // Действия в скобках
		ResultVariables1[0,0] = 0; // В случае если у переменной нет действий в скобках "Gg1[5]" -> FindMyVariables, будет возвращено это значение
		ResultVariables1[0,1] = 2; // Кол-во действий в скобках для переменной
		NameVariables1[1,0] = "K+Jf";
		NameVariables1[1,2] = "Переменная 1";
		NameVariables1[1,3] = "[ Любое число , Любое число ]";
		ResultVariables1[1,0] = 0;
		ResultVariables1[1,1] = 2;
		NameVariables1[2,0] = "R";
		NameVariables1[2,2] = "Переменная 2";
		NameVariables1[2,3] = "-";
		ResultVariables1[2,0] = 255;
		ResultVariables1[2,1] = 0;
		NameVariables1[3,0] = "G";
		NameVariables1[3,2] = "Переменная 3";
		NameVariables1[3,3] = "-";
		ResultVariables1[3,0] = 127;
		ResultVariables1[3,1] = 0;
		NameVariables1[4,0] = "B";
		NameVariables1[4,2] = "Переменная 4";
		NameVariables1[4,3] = "-";
		ResultVariables1[4,0] = 0;
		ResultVariables1[4,1] = 0;

		//for (int i = 0; i < CountVariables-1; i++) {
		//	NameVariables1[i,1] = NameVariables1[i,0].ToUpper(); // Название переменной в верхнем регистре
		//}

		// Добавить стандартные переменные //////////////////////////////////////////
		AddVariables ();
		/////////////////////////////////////////////////////////////////////////////
		//for (int i = 0; i <= (CountVariables+CountVariables2)-1; i++) {
		//	NameVariables1[i,1] = NameVariables1[i,0].ToUpper(); // Название переменной в верхнем регистре
		//}

		//SolveFormula ("  ( Abs|-(R  - |B|) -Gg[Wp[0.5],5]  * 2| " +
		//	"           +(  |B/2-  R*2|  )*4 + |-Jj[1.5]|)   "); // Решить формулу из текста
		//SolveFormula ("(Abs|-(R-|B|)-Gg[Wp[0.5],5]*2|+(|B/2-R*2|)*4+|-Jj[1.5]|)"); // Решить формулу из текста
		//SolveFormula ("(Abs|-(R-|B|)-Gg[Wp[0.5],5]*2|+(|B/2-R*2|)*4+|+Jj[1.5]|)"); // Решить формулу из текста
		//SolveFormula ("(+Abs|---(R-|B|^+2)-(-2^-|G[R]|)+-+-Trunc[-Floor[0.5],5]*2|+(|-B/2-R*-2|)*4+|-+-RGB[1.5]|)"); // Решить формулу из текста
		//SolveFormula ("(+AbsG(---(R+|B|^+2)-(-2*-|G[R]|)+-+-RoundB[-Floor[2.9],-5]*2)+(|-B/2-R*-2|)*4+|-+-Gg1R[1.5]|)"); // Решить формулу из текста
		//SolveFormula ("(+AbsG(---(R+|B|^+2)-(-2*-|G[R]|)"
		//+"+-+-RoundB[+-+-K+Jf[-(10+5/2.3)+R,-(10+5/2.3)-5,-(10+5/2.3)+5]*2)+(|-B/2-R*-2|)*4+|"
		//+"-+-Gg1R[-1.5,-2]|)"); // Решить формулу из текста
		//SolveFormula ("+-+-K+Jf[-(10+5/2.3)+R[1],-(10+5/2.3)/5+8,-(10+5/2.3)+5,3]"); // Решить формулу из текста
		//SolveFormula ("(|-5/2-4*2|)*4+|---(1.5)|"); // Решить формулу из текста
		//SolveFormula ("(Abs|  -(R-|B|)   -Gg[Wp[0.5],5]*2|+(|B/2-R*2|)*4+|  +Jj[1.5]|)"); // Решить формулу из текста
		//SolveFormula ("{{{{R}+{G}}}*2}"); // Решить формулу из текста
	}

	public static float SolveFormula (string s1 
		,out string sClean
		,out string stext 
		,out string sActions
		,out string[] sTextProperty
		,out int[,] AllSymbols1, out int CountOfSymbols1
		,out int CountOfUnActSymbols1, out int CountOfCommas1
		,out int[,] AllNumbers1, out int CountOfNumbers1
		,out int[,] AllVariables1, out int CountOfVariables1
		,out float[] AllVariables_N
		,out int[,] BracketStep, out int CountBracket, out int CountAddBracket
		,out float[] BracketStep_N
		,out string[] BracketStep_T
		,out int[,] AllActions, out int CountOfActions
		,out float[,] AllActions_N
		,out string[] AllActions_T
	) { // Решить формулу из текста
		//int[,] AllSymbols1;
		//int CountOfSymbols1;
		//int CountOfUnActSymbols1;
		//int CountOfCommas1;
		//int[,] AllNumbers1;
		//int CountOfNumbers1;
		//int[,] AllVariables1;
		//int CountOfVariables1;
		//float[] AllVariables_N;
		//int[,] BracketStep; 
		//int CountBracket;
		//float[] BracketStep_N;
		//string[] BracketStep_T;
		//int[,] AllActions;
		//int CountOfActions;
		//float[,] AllActions_N;
		//string[] AllActions_T;
		// Значения переменных: ///////////////////////////////////////////////////////////
		// s1 - текст с формулой
		// sClean - текст с исправленной формулой
		// stext - текст с формулой, дополнено скобками
		// sActions - текст, каждое действие с новой строки
		// sTextProperty - массив (основной, дополненный) текст, со свойствами формулы (5+RGB*2) = (№+...+№)
		// AllSymbols1 = массив со знаками. [ порядковый номер знака в тексте , 0..3 ]; // 0-Позиция знака. 1-Тип знака  0=+, 1=-, 2=*, 3=/, 4=^. 2-0=обычный знак, 1=знак меняющий результат, 3-первоначальная позиция знака
		// CountOfSymbols1 - количество знаков
		// CountOfUnActSymbols1 - количество знаков меняющих значение числа, скобки переменной
		// CountOfCommas1 - количество запятых
		// AllNumbers1 = массив с числами. [ порядковый номер числа в тексте , 0..5 ]; // 0-левая позиция, 1-правая позиция числа, 2-порядковый номер знака в массиве "AllSymbols1", если перед числом есть знак меняющий результат "+","-" (-1=если перед числом нет знака "+","-"), 3- -3=обычный знак "-" перед числом, -2=обычный знак "+" перед числом, -1=нет меняющего знака перед числом, 0=плюс перед числом, 1=минус перед числом, 4-первоначальная левая позиция, 5-первоначальная правая позиция числа
		// CountOfNumbers1 - количество чисел
		// AllVariables1 - массив с переменными. [ порядковый номер переменной в тексте , 0..8 ]; // 0-левая позиция, 1-правая позиция переменной, 2-номер скобки в массиве "BracketStep2" (-1) если нет скобок, 3-"в конце процедуры изменено значение на": позиция знака перед скобкой, 4- -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной, 5-номер переменной в массиве "NameVariables1", 6-первоначальная позиция левой переменной, 7-первоначальная позиция правой переменной, 8-первоначальная позиция знака перед переменной  
		// CountOfVariables1 - количество переменных в тексте
		// AllVariables_N - массив с результатами переменных. [ порядковый номер переменной в тексте ]; // Чему равна переменная
		// BracketStep - массив с позициями скобок. [ порядковый номер пар скобок , 0..12 ]; // 0-позиция левой скобки, 1-позиция правой скобки, 2-тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные), 3-позиция знака перед скобкой, 4- -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой, 5- номер переменной "AllVariables1" для данных скобок (-1 если нет переменной), 6-кол-во запятых внутри выбранных скобок, 7-к какой скобке относится эта часть (-1=не связано с запятыми), 8-первоначальная позиция левой скобки, 9-первоначальная позиция правой скобки, 10-первоначальная позиция знака перед собкой, 11-Если дополненная скобка, то номер первоначальной скобки в которой находится данная скобка, иначе -1, 12-номер скобки в которой находится данная скобка, 13-номер действия в массиве "AllActions"
		// CountBracket - количество пар скобок
		// CountAddBracket - количество добавленных пар скобок
		// BracketStep_N - массив с результатами в скобках. [ порядковый номер пар скобок ]; // Чему равны действия в скобках
		// BracketStep_T - массив с текстом действий в скобках. [ порядковый номер пар скобок ]; // Текст с действием в скобках
		// AllActions - массив с позициями действий в тексте. [ порядковый номер действия, 0..15 ]; // 0= Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой", 1= Порядковый номер левого знака (-1 если нет знака), 2= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 3= Порядковый номер левого числа, переменной, или скобок (образует диапазон от), 4= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 5= Порядковый номер левого числа, переменной, или скобок (образует диапазон до), 6= Порядковый номер знака, 7= Порядковый номер правого знака (-1 если нет знака), 8= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 9= Порядковый номер правого числа, переменной, или скобок, 10= левая позиция в дополненном тексте, 11= правая позиция в допоненном тексте, 12= позиция знака в дополненном тексте, 13= левая позиция в основном тексте, 14= правая позиция в основном тексте, 15= позиция знака в основном тексте
		// CountOfActions - количество всех действий
		// AllActions_N - массив с результатами действий. [ порядковый номер действия, 0..2 ]; // 0= Результат левого числа, переменной или скобки действия, 1= Результат правого числа, переменной или скобки действия, 2= Результат выполненного действия
		// AllActions_T - массив с текстом действий. [ порядковый номер действия ]; // Текст с действием
		///////////////////////////////////////////////////////////////////////////////////

		if (s1.Length<1) s1 = " ";


		char[] Bracket_L = new[] {'(','|','[','{','('}; // Открывающаяся 0-круглая скобка, 1-модуль, 2-квадратная, 3-полукруглая, 4-дополнительная
		char[] Bracket_R = new[] {')','|',']','}',')'}; // Закрывающаяся 0-круглая скобка, 1-модуль, 2-квадратная, 3-полукруглая, 4-дополнительная

		/*
		// Проверить есть ли главные боковые скобки ///////////////////////
		bool LB1 = false;
		bool RB1 = false;
		for (int j = 0; j <= 3; j++) {	
			if (s1 [0] == Bracket_L [j]) { // Если левая скобка
				LB1 = true;
				break;
			}					
		}
		for (int j = 0; j <= 3; j++) {	
			if (s1 [s1.Length-1] == Bracket_R [j]) { // Если правая скобка
				RB1 = true;
				break;
			}					
		}*/


		stext = "";
		if (CheckRegistr == 0) { // Если нужно учитывать  регистр символов (A<>a, B=B)
			//if ((LB1 == false) | (RB1 == false)) // Если нет боковых скобок
			stext = "(" + s1 + ")"; // Взять всю формулу в скобки
			//else stext = s1; // Иначе оставить как есть		
		}
		else { // Если не нужно учитывать  регистр символов (A=a, B=B)
			//if ((LB1==false) | (RB1==false)) // Если нет боковых скобок
			stext = "("+s1.ToUpper()+")"; // Взять всю формулу в скобки (Текст в верхнем регистре)
			//else stext = s1.ToUpper(); // Иначе текст в верхнем регистре
		}

		//print (stext);

		bool BoolTryParse = false;
		int Pp0 = 0;
		int Pp1 = 0;
		int Pp2 = 0;
		int Pp3 = 0;
		string sVariable = "";

		for (int i = 0; i <= stext.Length - 1; i++) 
			sVariable = sVariable+" "; // Создать пустую строку, длиной "s"

		// Пометить все переменные, "." в доп. строке //////////////
		char[] sVariable_c = new char[stext.Length];
		sVariable_c = sVariable.ToCharArray();
		char[] s_c = new char[stext.Length];
		s_c = stext.ToCharArray();


		for (int i = 0; i <= (CountVariables+CountVariables2) - 1; i++) {
			Pp1 = stext.IndexOf (NameVariables1 [i,CheckRegistr], 0);
			if (Pp1 > -1)
				while (Pp1 > -1) {
					for (int j = Pp1; j <= (Pp1 + NameVariables1 [i,CheckRegistr].Length - 1); j++) {
						sVariable_c [j] = ".".ToCharArray () [0];	
					}

					Pp1 = stext.IndexOf (NameVariables1 [i,CheckRegistr], Pp1 + 1);			
				}	
		}

		//bool AlreadyExist1 = false;
		//int CountOfVariables1 = 0; // Количество переменных
		CountOfVariables1 = 0; // Количество переменных
		string sAllVariables = ";"; // Записать позиции переменных в строку в виде ";0-10;12-15;", 0=начальная позиция, 10=конечная позиция
		int startnumber = -1;
		//int endnumber = -1;
		int numberv_1 = -1;
		int lengthv_1 = -1;
		string scopy_1;
		for (int i = 0; i <= stext.Length - 1; i++) {
			if (sVariable_c [i] == ".".ToCharArray () [0]) { // Если переменная
				if (startnumber == -1)
					startnumber = i;
				//if ((AlreadyExist1 == false) & (sVariable_c [j] == ".".ToCharArray () [0])) // Если уже стоит точка, то не увеличивать кол-во переменных
				//	AlreadyExist1 = true;
			} else {
				if (startnumber > -1) {

					scopy_1 = stext.Substring (startnumber, i - startnumber);

					lengthv_1 = -1;
					numberv_1 = -1;
					Pp1 = -1;
					Pp2 = -1;					
					// Найти подходящую переменную
					for (int j = 0; j <= (CountVariables + CountVariables2) - 1; j++) {
						if (NameVariables1 [j, CheckRegistr].Length > lengthv_1) {
							Pp0 = scopy_1.IndexOf (NameVariables1 [j, CheckRegistr], 0);
							if (Pp0 > -1) {
								lengthv_1 = NameVariables1 [j, CheckRegistr].Length;
								numberv_1 = j;
								Pp1 = Pp0;
								Pp2 = lengthv_1 + Pp0 - 1;
							}
						}
					}

					if (lengthv_1 > -1) { // Если переменная найдена
						CountOfVariables1 = CountOfVariables1 + 1;

						sAllVariables = sAllVariables
							+ numberv_1.ToString ()// Номер переменной
							+ "|" + (startnumber + Pp1).ToString ()
							+ "-" + (startnumber + Pp2).ToString () + ";";

						//print (stext.Substring (startnumber + Pp1, 
						//	(startnumber + Pp2)-(startnumber + Pp1)+1));
					}

					//print (stext.Substring (startnumber + Pp2+1, scopy_1.Length-Pp2-1));

					if (CleanVariables == true) { // false - оставить переменные в тексте как есть, true - убрать из текста лишние символы
						// Указать ошибочные символы ///////////////////////////////////
						//int leftDel = 0; // кол-во лишних символов слева
						//int RightDel = 0; // кол-во лишних символов справа
						if (numberv_1 > -1) { // Если есть хоть одно совпадение
							// Почистить слева от переменной
							if (Pp1 - 1 > -1) {
								//leftDel = Pp1-1; // кол-во лишних символов слева
								for (int j = startnumber; j <= (startnumber + Pp1 - 1); j++) {
									s_c [j] = " ".ToCharArray () [0];
									sVariable_c [j] = " ".ToCharArray () [0];
								}
							}
							// Почистить справа от переменной
							if (scopy_1.Length - (Pp2 + 1) > 0) {
								//RightDel = (startnumber + (scopy_1.Length-1))-(startnumber + (Pp2+1)); // кол-во лишних символов справа
								for (int j = (startnumber + (Pp2 + 1)); j <= (startnumber + (scopy_1.Length - 1)); j++) {
									s_c [j] = " ".ToCharArray () [0];
									sVariable_c [j] = " ".ToCharArray () [0];	
								}
							}
						} else { // Если ни одного совпадения
							//RightDel = (scopy_1.Length-1); // кол-во лишних символов справа
							for (int j = startnumber; j <= startnumber + (scopy_1.Length - 1); j++) {
								s_c [j] = " ".ToCharArray () [0];
								sVariable_c [j] = " ".ToCharArray () [0];	
							}
						}
						///////////////////////////////////////////////////////////////					
					}

					startnumber = -1;
				}
			}			
		}
		stext = new string(s_c); // "char[]" в "string"
		sClean = stext.Substring (1, stext.Length-2);
		//sClean = stext;
		//print (CountOfVariables1+" "+sAllVariables);
		//print (CountOfVariables1+" "+sVariable);

		// Занести позиции переменных из строки "sAllVariables" в массив "AllVariables1"
		BoolTryParse = false;
		Pp0 = 0;
		Pp1 = 0;
		Pp2 = 0;
		Pp3 = 0;
		//int[,] AllVariables1 = new int[CountOfVariables1,8]; // 0-левая позиция, 1-правая позиция переменной, 2-номер скобки в массиве "BracketStep2" (-1) если нет скобок, 3-порядковый номер знака в массиве "AllSymbols1", если перед переменной есть знак меняющий результат "+","-" (-1=если перед переменной нет знака "+","-"), 4- -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной, 5-номер переменной в массиве "NameVariables1", 6-первоначальная позиция левой переменной, 7-первоначальная позиция правой переменной, 8-первоначальная позиция знака перед переменной  
		AllVariables1 = new int[CountOfVariables1,9]; // 0-левая позиция, 1-правая позиция переменной, 2-номер скобки в массиве "BracketStep2" (-1) если нет скобок, 3-порядковый номер знака в массиве "AllSymbols1", если перед переменной есть знак меняющий результат "+","-" (-1=если перед переменной нет знака "+","-"), 4- -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной, 5-номер переменной в массиве "NameVariables1", 6-первоначальная позиция левой переменной, 7-первоначальная позиция правой переменной, 8-первоначальная позиция знака перед переменной  
		//float[] AllVariables_N = new float[CountOfVariables1]; // Чему равна переменная
		AllVariables_N = new float[CountOfVariables1]; // Чему равна переменная
		for (int i = 0; i <= CountOfVariables1 - 1; i++) {
			Pp0 = sAllVariables.IndexOf (";", Pp3);	
			Pp1 = sAllVariables.IndexOf ("|", Pp0);	
			Pp2 = sAllVariables.IndexOf ("-", Pp1);	
			Pp3 = sAllVariables.IndexOf (";", Pp2);	
			if ((Pp0 > -1) & (Pp1 > -1) & (Pp2 > -1) & (Pp3 > -1)) {			
				// Найти цифру
				//print (sAllVariables.Substring (Pp0+1, Pp1 - Pp0-1)
				//	+"  "+sAllVariables.Substring (Pp1+1, Pp2 - Pp1-1));
				BoolTryParse = int.TryParse (sAllVariables.Substring (Pp1 + 1, Pp2 - Pp1 - 1), out AllVariables1 [i, 0]); 
				if (BoolTryParse == false)
					AllVariables1 [i, 0] = -1;
				BoolTryParse = int.TryParse (sAllVariables.Substring (Pp2 + 1, Pp3 - Pp2 - 1), out AllVariables1 [i, 1]); 
				if (BoolTryParse == false)
					AllVariables1 [i, 1] = -1;
				AllVariables1 [i, 2] = -1;
				AllVariables1 [i, 3] = -1;
				AllVariables1 [i, 4] = -1;
				BoolTryParse = int.TryParse (sAllVariables.Substring (Pp0 + 1, Pp1 - Pp0 - 1), out AllVariables1 [i, 5]); 
				if (BoolTryParse == false)
					AllVariables1 [i, 5] = -1;
				AllVariables1 [i, 6] = AllVariables1 [i, 0]; // 6-первоначальная позиция левой скобки
				AllVariables1 [i, 7] = AllVariables1 [i, 1]; // 7-первоначальная позиция правой скобки  
				AllVariables1 [i, 8] = -1; // 8-первоначальная позиция знака перед переменной
			} else {
				AllVariables1 [i, 0] = -1;
				AllVariables1 [i, 1] = -1;
				AllVariables1 [i, 2] = -1;
				AllVariables1 [i, 3] = -1;
				AllVariables1 [i, 4] = -1;
				AllVariables1 [i, 5] = -1; // 5-номер переменной в массиве "NameVariables1"
				AllVariables1 [i, 6] = -1; // 6-первоначальная позиция левой скобки
				AllVariables1 [i, 7] = -1; // 7-первоначальная позиция правой скобки 
				AllVariables1 [i, 8] = -1; // 8-первоначальная позиция знака перед переменной
			}
		}		

		//print (CountOfVariables1+" "+stext);
		//print (CountOfVariables1+" "+new string (sVariable_c));

		/*for (int i = 0; i <= CountOfVariables1 - 1; i++) {
	if (AllVariables1 [i, 5] > -1)
		print (NameVariables1 [AllVariables1 [i, 5], CheckRegistr]);
}*/

		// Пометить все числа, " № " в доп. строке (включая десятичные числа с точкой) //////////////
		//int CountOfNumbers1 = 0; // Количество чисел
		CountOfNumbers1 = 0; // Количество чисел
		int countnumber = 0;
		int textnumber1,lastnumber1;
		BoolTryParse = false;
		startnumber = -1;
		lastnumber1 = 0;
		string sAllNumbers = ";"; // Записать позиции чисел в строку в виде ";0-10;12-15;", 0=начальная позиция, 10=конечная позиция
		for (int i = 0; i <= stext.Length - 1; i++) {
			if (sVariable_c [i] != ".".ToCharArray () [0]) {			
				// Найти цифру
				BoolTryParse = int.TryParse (stext [i].ToString (), out textnumber1); 
				if (BoolTryParse == false)
					textnumber1 = -1;
				if (textnumber1 > -1) { // Если цифра
					sVariable_c [i] = "№".ToCharArray () [0];	
					lastnumber1 = i;
					if (startnumber == -1)
						startnumber = i;
					countnumber = countnumber + 1;
				} else if ((lastnumber1 == i - 1) &
					(stext [i] == ".".ToCharArray () [0])) {					
					sVariable_c [i] = "№".ToCharArray () [0];
					if (startnumber == -1)
						startnumber = i;
					countnumber = countnumber + 1;
				} else {
					if (countnumber > 0) {
						sAllNumbers = sAllNumbers
							+ startnumber.ToString ()
							+ "-" + (startnumber + countnumber - 1).ToString () + ";";
						CountOfNumbers1 = CountOfNumbers1 + 1; // Количество чисел
					}
					countnumber = 0;
					startnumber = -1;
				}
			} else {
				if (countnumber > 0) {
					sAllNumbers = sAllNumbers
						+ startnumber.ToString ()
						+ "-" + (startnumber + countnumber - 1).ToString () + ";";
					CountOfNumbers1 = CountOfNumbers1 + 1; // Количество чисел
				}
				countnumber = 0;
				startnumber = -1;
			}
		}			

		//print (CountOfNumbers1+" "+sAllNumbers);

		// Занести позиции чисел из строки "sAllNumbers" в массив "AllNumbers1"
		BoolTryParse = false;
		Pp0 = 0;
		Pp1 = 0;
		Pp2 = 0;
		//int[,] AllNumbers1 = new int[CountOfNumbers1,6]; // 0-левая позиция, 1-правая позиция переменной, 2-порядковый номер знака в массиве "AllSymbols1", если перед числом есть знак меняющий результат "+","-" (-1=если перед числом нет знака "+","-"), 3- -3=обычный знак "-" перед числом, -2=обычный знак "+" перед числом, -1=нет меняющего знака перед числом, 0=плюс перед числом, 1=минус перед числом, 4-первоначальная левая позиция, 5-первоначальная правая позиция числа
		AllNumbers1 = new int[CountOfNumbers1,6]; // 0-левая позиция, 1-правая позиция переменной, 2-порядковый номер знака в массиве "AllSymbols1", если перед числом есть знак меняющий результат "+","-" (-1=если перед числом нет знака "+","-"), 3- -3=обычный знак "-" перед числом, -2=обычный знак "+" перед числом, -1=нет меняющего знака перед числом, 0=плюс перед числом, 1=минус перед числом, 4-первоначальная левая позиция, 5-первоначальная правая позиция числа
		float[] AllNumbers_N = new float[CountOfNumbers1]; // Чему равно число
		for (int i = 0; i <= CountOfNumbers1 - 1; i++) {
			Pp0 = sAllNumbers.IndexOf (";", Pp2);	
			Pp1 = sAllNumbers.IndexOf ("-", Pp0);	
			Pp2 = sAllNumbers.IndexOf (";", Pp1);	
			if ((Pp0 > -1) & (Pp1 > -1) & (Pp2 > -1)) {			
				// Найти цифру
				//print (sAllNumbers.Substring (Pp0+1, Pp1 - Pp0-1)
				//	+"  "+sAllNumbers.Substring (Pp1+1, Pp2 - Pp1-1));
				BoolTryParse = int.TryParse (sAllNumbers.Substring (Pp0+1, Pp1 - Pp0-1), out AllNumbers1 [i, 0]); 
				if (BoolTryParse == false)	AllNumbers1 [i, 0] = -1;
				BoolTryParse = int.TryParse (sAllNumbers.Substring (Pp1+1, Pp2 - Pp1-1), out AllNumbers1 [i, 1]); 
				if (BoolTryParse == false)	AllNumbers1 [i, 1] = -1;
				if ((AllNumbers1 [i, 0]>-1) & (AllNumbers1 [i, 1]>-1)) { // Если число найдено
					//print (stext.Substring (AllNumbers1 [i, 0], AllNumbers1 [i, 1] - AllNumbers1 [i, 0]+1));
					float.TryParse (stext.Substring (AllNumbers1 [i, 0], AllNumbers1 [i, 1] - AllNumbers1 [i, 0]+1), out AllNumbers_N [i]); 
					//print (AllNumbers_N [i]);
				}

				AllNumbers1 [i, 2] = -1;
				AllNumbers1 [i, 3] = -1;
				AllNumbers1 [i, 4] = AllNumbers1 [i, 0]; // 4-первоначальная левая позиция числа
				AllNumbers1 [i, 5] = AllNumbers1 [i, 1]; // 5-первоначальная правая позиция числа
			} else {
				AllNumbers1 [i, 0] = -1;
				AllNumbers1 [i, 1] = -1;
				AllNumbers1 [i, 2] = -1;
				AllNumbers1 [i, 3] = -1;
				AllNumbers1 [i, 4] = -1;
				AllNumbers1 [i, 5] = -1;
			}
		}

		// Найти знаки "+","-","*","/","^", поменять в доп. строке на "+" /////////////////////////////////////////
		//int[,] Symbol3 = new int[Mathf.CeilToInt(stext.Length/2),4]; // 0-позиция скобки, 1-тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные), 2-(0-левая скобка, 1-правая скобка), 3-(0-скобка не была помечена, 1-скобка помечена)
		char[] Symbols = new[] {'+','-','*','/','^',','}; // 0=+ 1=- 2=* 3=/ 4=^ 5=,
		//int CountOfSymbols1 = 0; // Количество знаков
		CountOfSymbols1 = 0; // Количество знаков
		//int CountOfCommas1 = 0; // Количество запятых
		CountOfCommas1 = 0; // Количество запятых
		int CountBracketPlus = 0; // Плюс количество пар скобок
		for (int i = 0; i <= stext.Length - 1; i++) {
			/*if ((s [i] == ",".ToCharArray () [0]) &
			    (sVariable_c [i] != ".".ToCharArray () [0])) { // Если запятая найдена, и она не является частью имени переменной
				sVariable_c [i] = ",".ToCharArray () [0];
			} else*/
			if (sVariable_c [i] != ".".ToCharArray () [0]) { // Если не переменная
				for (int j = 0; j <= Symbols.Length - 1; j++) {	
					if (stext [i] == Symbols [j]) { // Если знак найден
						if (j > 1) // Если "*","/","^",","
							CountBracketPlus = CountBracketPlus + 1; // Плюс количество пар скобок						
						if (j != 5) // Если не запятая
							sVariable_c [i] = "+".ToCharArray () [0];
						else { // Если запятая
							sVariable_c [i] = ",".ToCharArray () [0];
							CountOfCommas1 = CountOfCommas1+1; // Количество запятых
							CountBracketPlus = CountBracketPlus + 2; // Плюс количество пар скобок
						}
						CountOfSymbols1 = CountOfSymbols1 + 1;
						break;
					}				
				}
			}
		}	

		int[,] CommasInText = new int[CountOfCommas1,2]; // 0-позиция запятых, 1-первоначальная позиция запятых
		if (CountOfCommas1 > 0) {
			CountOfCommas1 = 0; // Количество запятых
			for (int i = 0; i <= stext.Length - 1; i++) {
				if (sVariable_c [i] == Symbols [5]) { // Если ","
					CommasInText [CountOfCommas1, 0] = i; // 0-позиция запятых
					CommasInText [CountOfCommas1, 1] = i; // 1-первоначальная позиция запятых
					CountOfCommas1 = CountOfCommas1 + 1; // Количество запятых
				}				
			}
		}

		//print (CountOfSymbols1);
		//print (CountOfSymbols1+" "+sVariable);


		// Найти скобки, поменять в доп. строке на "("  /////////////////////////////////////////
		int[,] Bracket3 = new int[stext.Length,5]; // 0-позиция скобки, 1-тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные), 2-(0-левая скобка, 1-правая скобка), 3-(0-скобка не была помечена, 1-скобка помечена), 4-Номер массива "BracketStep2"
		int CountBracket3 = 0;
		int[,] CountOfjBrackets = new int[4,2]; // Количество "j" скобок
		int LastModuleBracketPos = 0;

		for (int k1 = 0; k1 <= 3; k1++) {	
			for (int k2 = 0; k2 <= 1; k2++) {	
				CountOfjBrackets [k1, k2] = 0; // Количество "j" скобок
			}
		}

		for (int i = 0; i <= stext.Length - 1; i++) {
			if (sVariable_c [i] == " ".ToCharArray () [0]) { // Если не обозначенный символ
				for (int j = 0; j <= 3; j++) {	
					if (stext [i] == Bracket_L [j]) { // Если левая скобка
						Bracket3 [CountBracket3, 0] = i; // Позиция скобки
						Bracket3 [CountBracket3, 1] = j; // Тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полу круглые)

						CountOfjBrackets[j,0] = CountOfjBrackets[j,0]+1; // Количество "j" скобок
						if (j == 1) {
							LastModuleBracketPos = CountBracket3;
						}

						Bracket3 [CountBracket3, 2] = 0; // 0-левая скобка, 1-правая скобка
						sVariable_c [i] = "(".ToCharArray () [0];
						CountBracket3 = CountBracket3 + 1;
						break;
					} else if (stext [i] == Bracket_R [j]) { // Если правая скобка
						Bracket3 [CountBracket3, 0] = i; // Позиция скобки
						Bracket3 [CountBracket3, 1] = j; // Тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полу круглые)

						CountOfjBrackets[j,1] = CountOfjBrackets[j,1]+1; // Количество "j" скобок
						if (j == 1) {
							LastModuleBracketPos = CountBracket3;
						}

						Bracket3 [CountBracket3, 2] = 1; // 0-левая скобка, 1-правая скобка
						sVariable_c [i] = "(".ToCharArray () [0];
						CountBracket3 = CountBracket3 + 1;			
						break;
					}					
				}
			}
		}
		//print("0: "+stext+"  "+new string(sVariable_c));


		//print ("Всего скобок123: "+CountBracket3+"   "+stext);
		//print (new string(sVariable_c)+"   "+stext);


		// Удалять лишние скобки /////////////////////////////////////////////////////
		s_c = new char[stext.Length];
		s_c = stext.ToCharArray();

		float CountModulHalf = 0;
		int OddCountOfBrackets = 0; // 1 = если нечетное количество скобок
		int LRBrackets1 = 0;
		int CheckCountBracket3 = CountBracket3;
		int searchpos1 = 0;
		int searchpos2 = 0;

		for (int k1 = 0; k1 <= 3; k1++) {
			if (k1 != 1) { // Если не модульные скобки
				LRBrackets1 = CountOfjBrackets [k1, 0] - CountOfjBrackets [k1, 1];		

				if (LRBrackets1 > 0) { // Удалять левые скобки
					searchpos1 = stext.Length - 1;
					searchpos2 = CountBracket3 - 1;

					while (LRBrackets1 != 0) {
						while (searchpos1 >= 0) {
							if ((sVariable_c [searchpos1] == "(".ToCharArray () [0]) &
							    (s_c [searchpos1] == Bracket_L [k1])) { // Если нужная левая скобка
								s_c [searchpos1] = " ".ToCharArray () [0];
								sVariable_c [searchpos1] = " ".ToCharArray () [0];

								for (int k2 = searchpos2; k2 >= 0; k2--) { // Удалить скобку из массива "Bracket3"
									if (Bracket3 [k2, 0] == searchpos1) {
										Bracket3 [k2, 0] = -1; // Позиция скобки
										Bracket3 [k2, 1] = -1; // Тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полу круглые)
										Bracket3 [k2, 2] = -1; // 0-левая скобка, 1-правая скобка
										CheckCountBracket3 = CheckCountBracket3-1;
										searchpos2 = k2-1;
									}
								}
								LRBrackets1 = LRBrackets1 - 1;
								if (LRBrackets1 <= 0) {
									break;
								}
							}
							searchpos1 = searchpos1 - 1;
						}
					}
				} else if (LRBrackets1 < 0) { // Удалять правые скобки

					while (LRBrackets1 != 0) {
						while (searchpos1 <= stext.Length - 1) {
							if ((sVariable_c [searchpos1] == "(".ToCharArray () [0]) &
								(s_c [searchpos1] == Bracket_R [k1])) { // Если нужная левая скобка
								s_c [searchpos1] = " ".ToCharArray () [0];
								sVariable_c [searchpos1] = " ".ToCharArray () [0];

								for (int k2 = searchpos2; k2 <= CountBracket3 - 1; k2++) { // Удалить скобку из массива "Bracket3"
									if (Bracket3 [k2, 0] == searchpos1) {
										Bracket3 [k2, 0] = -1; // Позиция скобки
										Bracket3 [k2, 1] = -1; // Тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полу круглые)
										Bracket3 [k2, 2] = -1; // 0-левая скобка, 1-правая скобка
										CheckCountBracket3 = CheckCountBracket3-1;
										searchpos2 = k2+1;
									}
								}
								LRBrackets1 = LRBrackets1 + 1;
								if (LRBrackets1 >= 0) {
									break;
								}
							}
							searchpos1 = searchpos1 + 1;
						}
					}
				}	
			} else { // Если модульные скобки
				CountModulHalf = (CountOfjBrackets [k1, 0] + CountOfjBrackets [k1, 1]) / 2f;
				OddCountOfBrackets = Mathf.CeilToInt (CountModulHalf - Mathf.FloorToInt (CountModulHalf)); // 1 = если нечетное количество модульных скобок

				if (OddCountOfBrackets > 0) { // Если нечетное количество скобок	
					s_c [Bracket3 [LastModuleBracketPos, 0]] = " ".ToCharArray () [0];
					sVariable_c [Bracket3 [LastModuleBracketPos, 0]] = " ".ToCharArray () [0];

					Bracket3 [LastModuleBracketPos, 0] = -1; // Позиция скобки
					Bracket3 [LastModuleBracketPos, 1] = -1; // Тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полу круглые)
					Bracket3 [LastModuleBracketPos, 2] = -1; // 0-левая скобка, 1-правая скобка

					CheckCountBracket3 = CheckCountBracket3-1;
				}
			}				
		}
			

		// Собрать массив "Bracket3", без удаленных скобок
		if (CountBracket3 > 0) {
			bool foundnot_1 = false;
			int i1 = 0;
			while (i1 < CountBracket3) {
				if (Bracket3 [i1, 0] == -1) {
					if (i1 < CountBracket3 - 1) {
						for (int j = i1; j < CountBracket3 - 1; j++) {
							Bracket3 [j, 0] = Bracket3 [j + 1, 0]; // Позиция скобки
							Bracket3 [j, 1] = Bracket3 [j + 1, 1]; // Тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полу круглые)
							Bracket3 [j, 2] = Bracket3 [j + 1, 2]; // 0-левая скобка, 1-правая скобка	
							if (Bracket3 [j, 0] > -1) {
								foundnot_1 = true;
							}
						}
					}
					if ((foundnot_1 == true) & (Bracket3 [i1, 0] == -1)) {				
						i1 = i1 - 1;
					}
				}
				i1 = i1 + 1;
			}		
		}
			
		CountBracket3 = CheckCountBracket3;


		/*// Убрать отрицательныые числа
		if (CountBracket3 > 0) {
			int i1 = 0;
			while (i1 < CountBracket3) {
				if (Bracket3 [i1, 0] == -1) {
					Bracket3 [i1, 0] = 0; // Позиция скобки
					Bracket3 [i1, 1] = 0; // Тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полу круглые)
					Bracket3 [i1, 2] = 0; // 0-левая скобка, 1-правая скобка									
				}	
				i1 = i1 + 1;
			}
		}*/


		// Определить все ли скобки открываются и закрываются равномерно ") 2+2 (" /////////////////////////////////////////
		int CountOpenBracket = 0;
		int CountCloseBracket = 0;

		for (int k1 = 0; k1 <= 3; k1++) {
			if (k1 != 1) { // Если не модульные скобки
				CountOpenBracket = 0;
				CountCloseBracket = 0;

				// Слева на право
				for (int i2 = 0; i2 <= CountBracket3 - 1; i2++) {
					if (Bracket3 [i2, 1] == k1) { // Если нужная скобка
						
						if (Bracket3 [i2, 2] == 0) { // Если левая скобка
							CountOpenBracket = CountOpenBracket + 1;
						} else { // Если правая скобка
							CountCloseBracket = CountCloseBracket + 1;
						}
						if (CountOpenBracket < CountCloseBracket) { // Поворачивать закрывающииеся скобки, если слева не достаточно открывающихся скобок
							s_c [Bracket3 [i2, 0]] = Bracket_L [k1]; // Поменять тип скобки в тексте
							//sVariable_c [Bracket3 [i2, 0]] = "(".ToCharArray () [0];

							//Bracket3 [i2, 0] = -1; // Позиция скобки
							//Bracket3 [i2, 1] = -1; // Тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полу круглые)
							Bracket3 [i2, 2] = 0; // 0-левая скобка, 1-правая скобка

							CountOpenBracket = CountOpenBracket + 1;
							CountCloseBracket = CountCloseBracket - 1;
						}
					}
				}
					
				// Справа на лево
				for (int i2 = CountBracket3 - 1; i2 >= 0; i2--) {
					if (Bracket3 [i2, 1] == k1) { // Если нужная скобка
						
						if (Bracket3 [i2, 2] == 1) { // Если левая скобка
							CountOpenBracket = CountOpenBracket + 1;
						} else { // Если правая скобка
							CountCloseBracket = CountCloseBracket + 1;
						}
						if (CountOpenBracket > CountCloseBracket) { // Поворачивать открывающиеся скобки, если справа не достаточно закрывающихся скобок
							s_c [Bracket3 [i2, 0]] = Bracket_R [k1]; // Поменять тип скобки в тексте
							//sVariable_c [Bracket3 [i2, 0]] = "(".ToCharArray () [0];

							//Bracket3 [i2, 0] = -1; // Позиция скобки
							//Bracket3 [i2, 1] = -1; // Тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полу круглые)
							Bracket3 [i2, 2] = 1; // 0-левая скобка, 1-правая скобка

							CountOpenBracket = CountOpenBracket - 1;
							CountCloseBracket = CountCloseBracket + 1;
						}
					}
				}					
			}
		}


		//-------------------------------------------------------------------------------

		//for (int k1 = 0; k1 < CountBracket3; k1++) {	
		//	print (Bracket3 [k1, 0]+"   "+Bracket3 [k1, 1]+"   "+Bracket3 [k1, 2]);
		//}

		//print (new string(sVariable_c)+"   "+new string(s_c));

		//sVariable = new string(sVariable_c); // "char[]" в "string"

		// Если найдено несколько плюсов или минусов подряд, сложить их между собой, поменять в доп. строке, лишние знаки на " ", оставшийся знак на "+"  //////////////
		//s_c = new char[stext.Length];
		//s_c = stext.ToCharArray();
		int stepsymbols1 = 0;
		int stepstart1 = 0;
		int stepend1 = 0;
		bool PM_1,PM_Main;
		//string s_copy;
		//string sVariable_copy;
		PM_1 = false;
		PM_Main = true; // true-плюс, false-минус
		Pp0 = 0;
		while (Pp0<=sVariable_c.Length - 1) {
			if (sVariable_c [Pp0] != " ".ToCharArray () [0]) { // Если не пробел			
				if (s_c [Pp0] == Symbols [0]) { // Если знак "+"
					stepsymbols1 = stepsymbols1 + 1;
					PM_1 = true; // true-плюс, false-минус
				} else if (s_c [Pp0] == Symbols [1]) { // Если знак "-"					
					stepsymbols1 = stepsymbols1 + 1;
					PM_1 = false; // true-плюс, false-минус
				} else {
					if (stepsymbols1 > 1) { // Если было несколько повторяющихся знаков
						for (int i = stepstart1; i <= stepend1; i++) {
							s_c [i] = " ".ToCharArray () [0];
							sVariable_c [i] = " ".ToCharArray () [0];
						}

						if (PM_Main == false) { // Если знаки сложились в минус
							//s_c [stepend1] = "-".ToCharArray () [0];
							//sVariable_c [stepend1] = "+".ToCharArray () [0];
							s_c [stepstart1] = "-".ToCharArray () [0];
							sVariable_c [stepstart1] = "+".ToCharArray () [0];
						} else {
							//s_c [stepend1] = "+".ToCharArray () [0];
							//sVariable_c [stepend1] = "+".ToCharArray () [0];
							s_c [stepstart1] = "+".ToCharArray () [0];
							sVariable_c [stepstart1] = "+".ToCharArray () [0];
						}
						Pp0 = stepstart1;
						CountOfSymbols1 = CountOfSymbols1-(stepsymbols1-1);
					}
					stepsymbols1 = 0;
				}

				if (stepsymbols1 > 0) { // Если найден знак "+", "-"
					if (stepsymbols1 == 1) {
						stepstart1 = Pp0;
						PM_Main = true; // true-плюс, false-минус
					}
					stepend1 = Pp0;
					if (PM_1 == false) { // Поменять знак "PM_Main" на противоположный если минус, иначе знак остается прежним
						if (PM_Main == true)
							PM_Main = false;
						else
							PM_Main = true;
					}
				}
			}
			Pp0 = Pp0 + 1;
		}	

		//print (CountOfSymbols1);
		stext = new string(s_c); // "char[]" в "string"
		sVariable = new string(sVariable_c); // "char[]" в "string"

		//print (CountOfSymbols1+" "+sVariable);

		// Занести позиции знаков в массив "AllSymbols1"
		BoolTryParse = false;
		//int[,] AllSymbols1 = new int[CountOfSymbols1,4]; // 0-Позиция знака. 1-Тип знака  0=+, 1=-, 2=*, 3=/, 4=^. 2-0=обычный знак, 1=знак меняющий результат, 3-первоначальная позиция знака
		AllSymbols1 = new int[CountOfSymbols1,4]; // 0-Позиция знака. 1-Тип знака  0=+, 1=-, 2=*, 3=/, 4=^. 2-0=обычный знак, 1=знак меняющий результат, 3-первоначальная позиция знака

		for (int i = 0; i <= CountOfSymbols1 - 1; i++) { // Обновить массив
			AllSymbols1 [i, 0] = -1; // 0-Позиция знака
			AllSymbols1 [i, 1] = -1; // 1-Тип знака  0=+, 1=-, 2=*, 3=/, 4=^, 5=,
			AllSymbols1 [i, 2] = -1; // 2-0=обычный знак, 1=знак меняющий результат			
			AllSymbols1 [i, 3] = -1; // 3-первоначальная позиция знака
		}

		int countsymbol = 0;
		for (int i = 0; i <= sVariable_c.Length - 1; i++) {
			if (sVariable_c [i] == Symbols [0]) { // Если знак "+"		
				AllSymbols1 [countsymbol, 0] = i; // 0-Позиция знака
				AllSymbols1 [countsymbol, 3] = i; // 3-первоначальная позиция знака
				for (int j = 0; j <= Symbols.Length-1; j++) {
					if (s_c [i] == Symbols [j]) { // Если знак "+","-","*","/","^",","
						AllSymbols1 [countsymbol, 1] = j; // 1-Тип знака  0=+, 1=-, 2=*, 3=/, 4=^, 5=,
						//print (i+"   "+stext[i].ToString()+stext[i+1].ToString()
						//	+stext[i+2].ToString()
						//	+"   "+AllSymbols1 [countsymbol, 1]);
					}
				}
				AllSymbols1 [countsymbol, 2] = 0; // 2-0=обычный знак, 1=знак меняющий результат

				//print (i+"   "+stext[i].ToString()+stext[i+1].ToString()
				//		+stext[i+2].ToString()
				//		+"   "+AllSymbols1 [countsymbol, 1]);

				countsymbol = countsymbol + 1;
			}				
		}

		//sVariable_c = sVariable.ToCharArray();
		//s_c = stext.ToCharArray();
		//sVariable_c = sVariable.ToCharArray();
		//print (stext);
		//print (new string(sVariable_c));

		//string s2 = s;
		//string sVariable2 = new string(sVariable_c); // "char[]" в "string"

		// Удалить пробелы //////////////////////////////////////////////////////
		/*Pp1 = 0;
		while (Pp1 <= sVariable2.Length - 1) {
			if (sVariable2 [Pp1] == " ".ToCharArray () [0]) {
				s2 = s2.Remove(Pp1,1);
				sVariable2 = sVariable2.Remove(Pp1,1);
				Pp1 = Pp1 - 1;
			}
			Pp1 = Pp1 + 1;
		}*/

		//s2 = new string(s2_c); // "char[]" в "string"
		//sVariable2 = new string(sVariable2_c); // "char[]" в "string"

		//print (s2);
		//print (sVariable2);
		//print (CountBracketPlus);

		// Определить порядок круглых и квадратных скобок /////////////////
		int CountBracket2_2 = Mathf.CeilToInt(CountBracket3/2);
		int[,] BracketStep2 = new int[CountBracket2_2+CountBracketPlus+1,12]; // 0-позиция левой скобки, 1-позиция правой скобки, 2-тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные), 3-№ левой скобки в массиве "Bracket3", 4-№ правой скобки в массиве "Bracket3", 5-порядковый номер знака в массиве "AllSymbols1", если перед скобкой есть знак меняющий результат "+","-" (-1=если перед скобкой нет знака "+","-"), 6- -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой, 7-номер переменной "AllVariables1" для данных скобок (-1 если нет переменной), 8-кол-во запятых внутри выбранных скобок, 9-к какой скобке относится эта часть (-1=не связано с запятыми), 10-первоначальная позиция левой скобки, 11-первоначальная позиция правой скобки  
		int[,] Bracket3_r = new int[CountBracket2_2,2]; // № Массива "Bracket3" по значению "Bracket3_r[ Bracket3[ ... ,4] , 0..1 ]"
		for (int i = 0; i <= CountBracket2_2 - 1; i++) { // Обновить массив
			Bracket3_r [i,0] = -1; // Левая скобка
			Bracket3_r [i,1] = -1; // Правая скобка
		}		
		for (int i = 0; i <= (CountBracket2_2+CountBracketPlus) - 1; i++) { // Обновить массив		
			BracketStep2 [i, 5] = -1; // порядковый номер знака в массиве "AllSymbols1", если перед скобкой есть знак меняющий результат "+","-" (-1=если перед скобкой нет знака "+","-")
			BracketStep2 [i, 6] = -1; // -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой
			BracketStep2 [i, 7] = -1; // номер переменной "AllVariables1" для данных скобок (-1 если нет переменной)
			BracketStep2 [i, 8] = 0; // кол-во запятых внутри выбранных скобок
			BracketStep2 [i, 9] = -1; // к какой скобке относится эта часть (-1=не связано с запятыми)
			BracketStep2 [i, 10] = -1; // первоначальная позиция левой скобки
			BracketStep2 [i, 11] = -1; // первоначальная позиция правой скобки  
		}		
		int CountBracket2 = 0;
		for (int i = 0; i <= CountBracket3 - 1; i++) {
			if ((Bracket3 [i, 2] == 1) & (Bracket3 [i, 1] != 1)) { // Если правая скобка, не модульная
				for (int j = i; j >= 0; j--) {			
					if ((Bracket3 [j, 2] == 0) &
						(Bracket3 [j, 1] == Bracket3 [i, 1]) &
						(Bracket3 [j, 3] != 1)) { // Если левая скобка, такая же как и правая, и если скобка не помечена
						Bracket3 [j, 3] = 1; // Скобка помечена (левая)
						Bracket3 [i, 3] = 1; // Скобка помечена (правая)
						Bracket3 [j, 4] = CountBracket2; // Номер массива "BracketStep2" (для левой)
						Bracket3 [i, 4] = CountBracket2; // Номер массива "BracketStep2" (для правой)
						Bracket3_r [CountBracket2, 0] = j; // Номер массива "Bracket3" (для левой)
						Bracket3_r [CountBracket2, 1] = i; // Номер массива "Bracket3" (для правой)
						BracketStep2 [CountBracket2, 0] = Bracket3 [j, 0]; // Позиция левой скобки
						BracketStep2 [CountBracket2, 1] = Bracket3 [i, 0]; // Позиция правой скобки
						BracketStep2 [CountBracket2, 10] = Bracket3 [j, 0]; // первоначальная позиция левой скобки
						BracketStep2 [CountBracket2, 11] = Bracket3 [i, 0]; // первоначальная позиция правой скобки 
						BracketStep2 [CountBracket2, 2] = Bracket3 [j, 1]; // Тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные)
						BracketStep2 [CountBracket2, 3] = j; // № левой скобки в массиве "Bracket3"
						BracketStep2 [CountBracket2, 4] = i; // № правой скобки в массиве "Bracket3"

						//print (CountBracket2 + ":  "+BracketStep2 [CountBracket2, 1]+"  "
						//	+ stext.Substring (Bracket3 [j, 0] + 1,
						//		Bracket3 [i, 0] - Bracket3 [j, 0] - 1));

						CountBracket2 = CountBracket2 + 1;			
						break;
					}
				}
			} else {
				if (Bracket3 [i, 1] == 1) { // Если модульная скобка
					Bracket3 [i, 4] = CountBracket2; // Номер массива "BracketStep2" (для левой или правой)
				}
			}
		}


		// Очистить текст от лишних символов /////////////////////////////////////////
		//s_c = new char[stext.Length];
		//s_c = stext.ToCharArray();

		if (CleanVariables == true) { // false - оставить переменные в тексте как есть, true - убрать из текста лишние символы
			for (int i = 0; i <= stext.Length - 1; i++) {
				if ((sVariable_c [i] == " ".ToCharArray () [0]) &
					(s_c [i] != " ".ToCharArray () [0])) { // Если неопределенный символ
					s_c [i] = " ".ToCharArray () [0];
				}
			}

			stext = new string (s_c); // "char[]" в "string"
			sClean = stext.Substring (1, stext.Length - 2);
		}
		///////////////////////////////////////////////////////////////////////


		// Очистить текст от лишних чисел /////////////////////////////////////////
		//s_c = new char[stext.Length];
		//s_c = stext.ToCharArray();

		int leftOk1 = 0; // 1-скобка, 2-знак, 3-запятая
		int rightOk1 = 0; // 1-скобка, 2-закр. скобка, 3-запятая
		if (CountOfNumbers1 > 0) {
			for (int i = 0; i <= CountOfNumbers1 - 1; i++) {
				if ((AllNumbers1 [i, 0] > -1) & (AllNumbers1 [i, 1] > -1)) {
					// Проверить слева от числа, наличие откр. скобки или знака
					for (int j = AllNumbers1 [i, 0] - 1; j >= 0; j--) {
						if (sVariable_c [j] != " ".ToCharArray () [0]) {
							if (sVariable_c [j] == Bracket_L [0]) {
								for (int k = 0; k <= Bracket_L.Length - 1; k++) {
									if (s_c [j] == Bracket_L [k]) {
										leftOk1 = 1; // 1-скобка, 2-знак
										break;
									}
								}

							} else if (sVariable_c [j] == Symbols [0]) 								
							 {
								//| (sVariable_c [j] == "_".ToCharArray () [0])
								leftOk1 = 2; // 1-скобка, 2-знак, 3-запятая
							} else if (sVariable_c [j] == Symbols [5]) 								
							{
								//| (sVariable_c [j] == "_".ToCharArray () [0])
								leftOk1 = 3; // 1-скобка, 2-знак, 3-запятая
							}
							break;
						}
					}
					if (leftOk1 > 0) {
						// Проверить справа от числа, наличие закр. скобки или знака
						for (int j = AllNumbers1 [i, 1] + 1; j <= stext.Length - 1; j++) {
							if (sVariable_c [j] != " ".ToCharArray () [0]) {
								if (sVariable_c [j] == Bracket_L [0]) {
									for (int k = 0; k <= Bracket_R.Length - 1; k++) {
										if (s_c [j] == Bracket_R [k]) {
											rightOk1 = 1; // 1-скобка, 2-закр. скобка, 3-запятая
											break;
										}
									}

								} else if ((sVariable_c [j] == Symbols [0]) 
								) {
									//| (sVariable_c [j] == "_".ToCharArray () [0])
									rightOk1 = 2; // 1-скобка, 2-закр. скобка, 3-запятая
								} else if (sVariable_c [j] == Symbols [5]) {
									rightOk1 = 3; // 1-скобка, 2-закр. скобка, 3-запятая
								}
								break;
							}
						}
					}
					if ((leftOk1 == 0) | (rightOk1 == 0)) { // Если лишнее число
						for (int j = AllNumbers1 [i, 0]; j <= AllNumbers1 [i, 1]; j++) {
							sVariable_c [j] = " ".ToCharArray () [0];
							if (CleanVariables == true) { // false - оставить переменные в тексте как есть, true - убрать из текста лишние символы				
								s_c [j] = " ".ToCharArray () [0];					
							}
						}
						//print (AllNumbers1 [i, 0]+"\n"+AllNumbers1 [i, 1]);
						AllNumbers1 [i, 0] = -1;
						AllNumbers1 [i, 1] = -1;
						AllNumbers1 [i, 2] = -1;
						AllNumbers1 [i, 3] = -1;
						AllNumbers1 [i, 4] = -1;
						AllNumbers1 [i, 5] = -1;
					}
					leftOk1 = 0;
					rightOk1 = 0;	
				}
			}
		}	

		//stext = new string (s_c); // "char[]" в "string"
		//sClean = stext.Substring (1, stext.Length - 2);
		//sVariable = new string(sVariable_c);
		//print (stext+"\n"+sVariable);
		///////////////////////////////////////////////////////////////////////


		// Очистить текст от лишних переменных /////////////////////////////////////////
		//s_c = new char[stext.Length];
		//s_c = stext.ToCharArray();

		leftOk1 = 0; // 1-скобка, 2-знак, 3-запятая
		rightOk1 = 0; // 1-скобка, 2-закр. скобка, 3-знак, 4-запятая
		if (CountOfVariables1 > 0) {
			for (int i = 0; i <= CountOfVariables1 - 1; i++) {
				if ((AllVariables1 [i, 0] > -1) & (AllVariables1 [i, 1] > -1)) {
					// Проверить слева от переменной, наличие откр. скобки или знака
					for (int j = AllVariables1 [i, 0] - 1; j >= 0; j--) {
						if (sVariable_c [j] != " ".ToCharArray () [0]) {
							if (sVariable_c [j] == Bracket_L [0]) {
								for (int k = 0; k <= Bracket_L.Length - 1; k++) {
									if (s_c [j] == Bracket_L [k]) {
										leftOk1 = 1; // 1-скобка, 2-знак
										break;
									}
								}

							} else if (sVariable_c [j] == Symbols [0]) 								
							 {
								//| (sVariable_c [j] == "_".ToCharArray () [0])
								leftOk1 = 2; // 1-скобка, 2-знак, 3-запятая
							} else if (sVariable_c [j] == Symbols [5]) 								
							{
								//| (sVariable_c [j] == "_".ToCharArray () [0])
								leftOk1 = 3; // 1-скобка, 2-знак, 3-запятая
							}
							break;
						}
					}
					if (leftOk1 > 0) {
						// Проверить справа от переменной, наличие запятой или закр., откр. скобки или знака
						for (int j = AllVariables1 [i, 1] + 1; j <= stext.Length - 1; j++) {
							if (sVariable_c [j] != " ".ToCharArray () [0]) {
								if (sVariable_c [j] == Bracket_L [0]) {
									for (int k = 0; k <= Bracket_L.Length - 1; k++) {
										if (s_c [j] == Bracket_L [k]) {
											rightOk1 = 1; // 1-скобка, 2-закр. скобка, 3-знак, 4-запятая
											break;
										}
									}
									if (rightOk1 == 0) {
										for (int k = 0; k <= Bracket_R.Length - 1; k++) {
											if (s_c [j] == Bracket_R [k]) {
												rightOk1 = 2; // 1-скобка, 2-закр. скобка, 3-знак, 4-запятая
												break;
											}
										}
									}
								} else if ((sVariable_c [j] == Symbols [0]) 
								) {
									//| (sVariable_c [j] == "_".ToCharArray () [0])
									rightOk1 = 3; // 1-скобка, 2-закр. скобка, 3-знак, 4-запятая
								} else if (sVariable_c [j] == Symbols [5]) {
									//| (sVariable_c [j] == "_".ToCharArray () [0])
									rightOk1 = 4; // 1-скобка, 2-закр. скобка, 3-знак, 4-запятая
								}
								break;
							}
						}
					}
					if ((leftOk1 == 0) | (rightOk1 == 0)) { // Если лишнее число
						//print (stext.Substring( 
						//	AllVariables1 [i, 0]-5,AllVariables1 [i, 1]-AllVariables1 [i, 0]+11));
						for (int j = AllVariables1 [i, 0]; j <= AllVariables1 [i, 1]; j++) {
							sVariable_c [j] = " ".ToCharArray () [0];
							if (CleanVariables == true) { // false - оставить переменные в тексте как есть, true - убрать из текста лишние символы				
								s_c [j] = " ".ToCharArray () [0];					
							}
						}
						//print (AllVariables1 [i, 0]+"\n"+AllVariables1 [i, 1]);
						/*AllVariables1 [i, 0] = -1;
						AllVariables1 [i, 1] = -1;
						AllVariables1 [i, 2] = -1;
						AllVariables1 [i, 3] = -1;
						AllVariables1 [i, 4] = -1;
						AllVariables1 [i, 5] = -1; // 5-номер переменной в массиве "NameVariables1"
						AllVariables1 [i, 6] = -1; // 6-первоначальная позиция левой скобки
						AllVariables1 [i, 7] = -1; // 7-первоначальная позиция правой скобки 
						AllVariables1 [i, 8] = -1; // 8-первоначальная позиция знака перед переменной
						*/
					}
					leftOk1 = 0;
					rightOk1 = 0;	
				}
			}
		}
			
		stext = new string (s_c); // "char[]" в "string"
		sClean = stext.Substring (1, stext.Length - 2);
		sVariable = new string(sVariable_c);
		string sCleanVariable = sVariable.Substring (1, sVariable.Length - 2);
		//print (stext+"\n"+sVariable);
		///////////////////////////////////////////////////////////////////////


		// Определить порядок модульных скобок
		int CountBracket2_3 = CountBracket2;
		int CountBadModul_1 = 0;
		int CountBadModul_2 = 0;
		int CurrentNum_1 = 0;
		char[] Symbols2 = new[] {' ','+','-','.','№','('}; // 0= , 1=+, 2=-, 3=., 4=№, 5=(
		string sModule = new string(sVariable_c);
		char[] sModule_c = new char[sModule.Length];
		sModule_c = sModule.ToCharArray();
		//int[,] BracketStep2 = new int[Mathf.CeilToInt(CountBracket3/2),3]; // 0-позиция левой скобки, 1-позиция правой скобки, 2-тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные)
		for (int i = 0; i <= CountBracket2_2 - 1; i++) {		
			if (BracketStep2 [i, 3] != BracketStep2 [i, 4]) { // Если позиции левой и правой скобки не равны



				int CountOfBrackets1 = BracketStep2 [i, 4]-BracketStep2 [i, 3];
				int[] NumberOfModule = new int[CountOfBrackets1];

				int ModulesInRange = 0;
				if (CountOfBrackets1 > 0) {
					float CountModulHalf1 = CountOfBrackets1 / 2f;
					OddCountOfBrackets = Mathf.CeilToInt (CountModulHalf1 - Mathf.FloorToInt (CountModulHalf1)); // 1 = если нечетное количество модульных скобок

					int k2 = 0;
					for (int j = BracketStep2 [i, 3]; j <= BracketStep2 [i, 4]; j++) {

						if ((Bracket3 [j, 1] == 1) & (Bracket3 [j, 3] != 1)) { // Если не помеченная модульная скобка
							NumberOfModule[ModulesInRange] = j;
							ModulesInRange = ModulesInRange + 1;
						}				
					}
		    		//print (Bracket3 [BracketStep2 [i, 3], 0] + "   " + Bracket3 [BracketStep2 [i, 4], 0] + "   " + ModulesInRange);								
				}

				int CountOfPairs1 = Mathf.FloorToInt(ModulesInRange/2f); // Должное количество пар скобок
				int CountOfPairs2 = 0; // Полученное количество пар скобок



				CountBadModul_2 = -1;
				while (CountBadModul_1 != CountBadModul_2) { // Повторять пока все модульные скобки в выбранной области не определены
					CountBadModul_2 = CountBadModul_1;
					CountBadModul_1 = 0;
					for (int j = BracketStep2 [i, 3]; j <= BracketStep2 [i, 4]; j++) {	
						if ((Bracket3 [j, 1] == 1) & (Bracket3 [j, 3] != 1)) { // Если модульная скобка, не помечена
							//print (Bracket3 [j, 0] + "  " + Bracket3 [BracketStep2 [i, 4], 0]);
							if (Bracket3 [j, 0] + 1 <= Bracket3 [BracketStep2 [i, 4], 0]) {
								for (int k = Bracket3 [j, 0] + 1; k <= Bracket3 [BracketStep2 [i, 4], 0]; k++) {	
									if (sModule_c [k] != Symbols2 [0]) { // Если не пробел
										
										//print (j + "  " 
										//	+ BracketStep2 [i, 4] + "  "
										//	+ s [k] + "  "
										//	+ sModule_c [k] + "  ");	
										if (
											//(sModule_c [k] != Symbols2 [5]) & // "("
											(((sModule_c [k] == Symbols2 [1]) & // "+"
											((stext [k] == Symbols2 [1]) | // "+"
											(stext [k] == Symbols2 [2]))) | // "-"
											(sModule_c [k] == Symbols2 [3]) | // "."
											(sModule_c [k] == Symbols2 [4]) | // "№"
											(stext [k] == Bracket_L [0]) | // "("
											(stext [k] == Bracket_L [2]) | // "["
											(stext [k] == Bracket_L [3]) // "{"
											)) { // Если после модульной скобки стоит знак минус, переменная, число или другая открывающаяся скобка (кроме модульной)
											//print ((j + 1) + "  " + BracketStep2 [i, 4]);		
											if ((j + 1) <= BracketStep2 [i, 4]) {
												for (int k2 = j + 1; k2 <= BracketStep2 [i, 4]; k2++) { // От найденной модульной скобки, до правой круглой, квадратной или полукруглой скобки
													if ((Bracket3 [k2, 1] == 1) & (Bracket3 [k2, 3] != 1)) { // Если модульная скобка, не помечена
														Bracket3 [j, 3] = 1; // Скобка помечена (левая)
														Bracket3 [k2, 3] = 1; // Скобка помечена (правая)

														/*print (Bracket3 [j, 0]
														+ "  " + Bracket3 [k2, 0]
														+ "  " + Bracket3 [j, 4]
														+ "  " + Bracket3 [k2, 4]
														+ "  " + Bracket3 [BracketStep2 [i, 4], 4]);		
														*/
														CurrentNum_1 = Bracket3 [BracketStep2 [i, 4], 4];

														// Сместить порядок скобок следующих после модульных вправо
														for (int j2 = CountBracket2_2 - 1; j2 > CurrentNum_1; j2--) {															
															Bracket3_r [j2, 0] = Bracket3_r [j2 - 1, 0]; // Номер массива "Bracket3" (для левой)
															Bracket3_r [j2, 1] = Bracket3_r [j2 - 1, 1]; // Номер массива "Bracket3" (для правой)

															if (Bracket3_r [j2, 0] > -1) {
																Bracket3 [Bracket3_r [j2, 0], 4] = j2; // Номер массива "BracketStep2" (для левой)
																Bracket3 [Bracket3_r [j2, 1], 4] = j2; // Номер массива "BracketStep2" (для правой)
															}
															BracketStep2 [j2, 0] = BracketStep2 [j2 - 1, 0]; // Позиция левой скобки
															BracketStep2 [j2, 1] = BracketStep2 [j2 - 1, 1]; // Позиция правой скобки
															BracketStep2 [j2, 10] = BracketStep2 [j2 - 1, 0]; // первоначальная позиция левой скобки
															BracketStep2 [j2, 11] = BracketStep2 [j2 - 1, 1]; // первоначальная позиция правой скобки 
															BracketStep2 [j2, 2] = BracketStep2 [j2 - 1, 2]; // Тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные)
															BracketStep2 [j2, 3] = BracketStep2 [j2 - 1, 3]; // № левой скобки в массиве "Bracket3"
															BracketStep2 [j2, 4] = BracketStep2 [j2 - 1, 4]; // № правой скобки в массиве "Bracket3"
														}
														// Определить текущие модульные скобки
														Bracket3_r [CurrentNum_1, 0] = j;  // Номер массива "Bracket3" (для левой)
														Bracket3_r [CurrentNum_1, 1] = k2; // Номер массива "Bracket3" (для правой)
														Bracket3 [j, 4] = CurrentNum_1;   // Номер массива "BracketStep2" (для левой)
														Bracket3 [k2, 4] = CurrentNum_1;   // Номер массива "BracketStep2" (для правой)
														Bracket3 [j, 2] = 0; // 0-левая скобка, 1-правая скобка
														Bracket3 [k2, 2] = 1; // 0-левая скобка, 1-правая скобка
														BracketStep2 [CurrentNum_1, 0] = Bracket3 [j, 0]; // Позиция левой скобки
														BracketStep2 [CurrentNum_1, 1] = Bracket3 [k2, 0]; // Позиция правой скобки
														BracketStep2 [CurrentNum_1, 10] = Bracket3 [j, 0]; // первоначальная позиция левой скобки
														BracketStep2 [CurrentNum_1, 11] = Bracket3 [k2, 0]; // первоначальная позиция правой скобки 
														BracketStep2 [CurrentNum_1, 2] = 1; // Тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные)
														BracketStep2 [CurrentNum_1, 3] = j; // № левой скобки в массиве "Bracket3"
														BracketStep2 [CurrentNum_1, 4] = k2; // № правой скобки в массиве "Bracket3"

														sModule_c [Bracket3 [j, 0]] = "№".ToCharArray () [0];  // Считать скобку числом, для пропуска в дальнейшем поиске модульных скобок
														sModule_c [Bracket3 [k2, 0]] = "№".ToCharArray () [0];

														/*for (int l = 0; l <= CountBracket2_2 - 1; l++) {			
														if (Bracket3_r [l, 0] > -1) {
															//print (l + ":  " + Bracket3 [j, 4] + " | "
															//+ Bracket3_r [l, 1]);	
															print (l + ":  " + Bracket3 [k2, 4] + " | "
																+ Bracket3_r [l, 1]+ ":  " + stext.Substring (Bracket3 [Bracket3_r [l, 0], 0] + 1,
																		Bracket3 [Bracket3_r [l, 1], 0] - Bracket3 [Bracket3_r [l, 0], 0] - 1));	
															//print (l + ":  " + Bracket3 [Bracket3_r [l, 0], 0] + " | "
															//+ Bracket3 [Bracket3_r [l, 1], 0]);														
															//print (l + ":  " + stext.Substring (Bracket3 [Bracket3_r [l, 0], 0] + 1,
															//	Bracket3 [Bracket3_r [l, 1], 0] - Bracket3 [Bracket3_r [l, 0], 0] - 1));		
														}													
													}*/

														//print (new string (sModule_c));

														CountBracket2_3 = CountBracket2_3 + 1;	
														CountOfPairs2 = CountOfPairs2+1; // Полученное количество пар скобок
														break;
													}
												}
											}
										} else {
											CountBadModul_1 = CountBadModul_1 + 1;
										}
										break;
									}
								}
							}
						}
					}
				}
					

				if (CountOfBrackets1-OddCountOfBrackets > 0) {	

					if (CountOfPairs2 < CountOfPairs1) { // Если пар скобок меньше чем "CountOfPairs1"
						
						// Объеденить скобки по порядку
						int j = 0;
						while (j < (CountOfBrackets1-OddCountOfBrackets)) {

							Bracket3 [NumberOfModule [j], 3] = 1; // Скобка помечена (левая)
							Bracket3 [NumberOfModule [j + 1], 3] = 1; // Скобка помечена (правая)

							/*print (Bracket3 [j, 0]
														+ "  " + Bracket3 [NumberOfModule[j+1], 0]
														+ "  " + Bracket3 [NumberOfModule[j], 4]
														+ "  " + Bracket3 [NumberOfModule[j+1], 4]
														+ "  " + Bracket3 [BracketStep2 [i, 4], 4]);		
														*/
							CurrentNum_1 = Bracket3 [BracketStep2 [i, 4], 4];

							// Сместить порядок скобок следующих после модульных вправо
							for (int j2 = CountBracket2_2 - 1; j2 > CurrentNum_1; j2--) {															
								Bracket3_r [j2, 0] = Bracket3_r [j2 - 1, 0]; // Номер массива "Bracket3" (для левой)
								Bracket3_r [j2, 1] = Bracket3_r [j2 - 1, 1]; // Номер массива "Bracket3" (для правой)

								if (Bracket3_r [j2, 0] > -1) {
									Bracket3 [Bracket3_r [j2, 0], 4] = j2; // Номер массива "BracketStep2" (для левой)
									Bracket3 [Bracket3_r [j2, 1], 4] = j2; // Номер массива "BracketStep2" (для правой)
								}
								BracketStep2 [j2, 0] = BracketStep2 [j2 - 1, 0]; // Позиция левой скобки
								BracketStep2 [j2, 1] = BracketStep2 [j2 - 1, 1]; // Позиция правой скобки
								BracketStep2 [j2, 10] = BracketStep2 [j2 - 1, 0]; // первоначальная позиция левой скобки
								BracketStep2 [j2, 11] = BracketStep2 [j2 - 1, 1]; // первоначальная позиция правой скобки 
								BracketStep2 [j2, 2] = BracketStep2 [j2 - 1, 2]; // Тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные)
								BracketStep2 [j2, 3] = BracketStep2 [j2 - 1, 3]; // № левой скобки в массиве "Bracket3"
								BracketStep2 [j2, 4] = BracketStep2 [j2 - 1, 4]; // № правой скобки в массиве "Bracket3"
							}
							// Определить текущие модульные скобки
							Bracket3_r [CurrentNum_1, 0] = NumberOfModule [j];  // Номер массива "Bracket3" (для левой)
							Bracket3_r [CurrentNum_1, 1] = NumberOfModule [j + 1]; // Номер массива "Bracket3" (для правой)
							Bracket3 [NumberOfModule [j], 4] = CurrentNum_1;   // Номер массива "BracketStep2" (для левой)
							Bracket3 [NumberOfModule [j + 1], 4] = CurrentNum_1;   // Номер массива "BracketStep2" (для правой)
							Bracket3 [NumberOfModule [j], 2] = 0; // 0-левая скобка, 1-правая скобка
							Bracket3 [NumberOfModule [j + 1], 2] = 1; // 0-левая скобка, 1-правая скобка
							BracketStep2 [CurrentNum_1, 0] = Bracket3 [NumberOfModule [j], 0]; // Позиция левой скобки
							BracketStep2 [CurrentNum_1, 1] = Bracket3 [NumberOfModule [j + 1], 0]; // Позиция правой скобки
							BracketStep2 [CurrentNum_1, 10] = Bracket3 [NumberOfModule [j], 0]; // первоначальная позиция левой скобки
							BracketStep2 [CurrentNum_1, 11] = Bracket3 [NumberOfModule [j + 1], 0]; // первоначальная позиция правой скобки 
							BracketStep2 [CurrentNum_1, 2] = 1; // Тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные)
							BracketStep2 [CurrentNum_1, 3] = NumberOfModule [j]; // № левой скобки в массиве "Bracket3"
							BracketStep2 [CurrentNum_1, 4] = NumberOfModule [j + 1]; // № правой скобки в массиве "Bracket3"

							sModule_c [Bracket3 [NumberOfModule [j], 0]] = "№".ToCharArray () [0];  // Считать скобку числом, для пропуска в дальнейшем поиске модульных скобок
							sModule_c [Bracket3 [NumberOfModule [j + 1], 0]] = "№".ToCharArray () [0];

							/*for (int l = 0; l <= CountBracket2_2 - 1; l++) {			
														if (Bracket3_r [l, 0] > -1) {
															//print (l + ":  " + Bracket3 [NumberOfModule[j], 4] + " | "
															//+ Bracket3_r [l, 1]);	
															print (l + ":  " + Bracket3 [NumberOfModule[j+1], 4] + " | "
																+ Bracket3_r [l, 1]+ ":  " + stext.Substring (Bracket3 [Bracket3_r [l, 0], 0] + 1,
																		Bracket3 [Bracket3_r [l, 1], 0] - Bracket3 [Bracket3_r [l, 0], 0] - 1));	
															//print (l + ":  " + Bracket3 [Bracket3_r [l, 0], 0] + " | "
															//+ Bracket3 [Bracket3_r [l, 1], 0]);														
															//print (l + ":  " + stext.Substring (Bracket3 [Bracket3_r [l, 0], 0] + 1,
															//	Bracket3 [Bracket3_r [l, 1], 0] - Bracket3 [Bracket3_r [l, 0], 0] - 1));		
														}													
													}*/

							//print (new string (sModule_c));

							CountBracket2_3 = CountBracket2_3 + 1;	

							j = j + 2;
						}				
					}
					//print (Bracket3 [BracketStep2 [i, 3], 0] + "   " + Bracket3 [BracketStep2 [i, 4], 0] + "   " + ModulesInRange);								
					//print ("Должное количество пар скобок: " + CountOfPairs1 + "\n"
					//	+ "Полученное количество пар скобок: " + CountOfPairs2);
				}					


			}						
		}
			
		/*for (int i = 0; i <= CountBracket2_2+CountBracketPlus+1 - 1; i++) {	
			if ((BracketStep2 [i, 10] > 0) & (BracketStep2 [i, 11] > -1)) {
				print("21321 "+s1.Substring (BracketStep2 [i, 10]-1,
					BracketStep2 [i, 11] - BracketStep2 [i, 10]+1));		
			}
		}*/


		//print ("5: "+new string (sModule_c));
		//print (stext);
		//print (sVariable);

		// Расставить скобки в доп. строке с учетом открытия "(" и закрытия ")" /////////////////////////////////////////
		for (int i = 0; i <= CountBracket2_2 - 1; i++) {	
			//if (Bracket3_r [i, 0] > -1) {
			//print (i + "  " + Bracket3_r [i, 0] + "  " + Bracket3_r [i, 1]);
			sVariable_c [Bracket3 [Bracket3_r [i, 0], 0]] = Bracket_L [0]; // "("
			sVariable_c [Bracket3 [Bracket3_r [i, 1], 0]] = Bracket_R [0]; // ")"
			//}
		}

		//print ("5: "+new string (sModule_c));
		//print (stext);
		//print (new string (sVariable_c));

		// Найти знаки "+","-" сразу после открывающейся скобки, поменять в доп. строке на "_" /////////////////////////////////////////
		//int CountOfUnActSymbols1 = 0; // Количество знаков меняющих значение числа, скобки переменной
		CountOfUnActSymbols1 = 0; // Количество знаков меняющих значение числа, скобки переменной
		for (int i = 0; i <= CountBracket2_3 - 1; i++) {	
			Pp1 = BracketStep2 [i, 0]; // Позиция левой (открывающейся) скобки
			//print (stext.Substring(BracketStep2 [i, 0],BracketStep2 [i, 1]-BracketStep2 [i, 0]+1));
			if (Pp1 + 1 <= stext.Length - 1) {
				for (int j = Pp1 + 1; j <= stext.Length - 1; j++) {
					if (sVariable_c [j] != Symbols2 [0]) { // Если не пробел

						//print (sVariable_c [Pp1]+"  "+sVariable_c [j]);
						//print (stext.Substring((j + 1),stext.Length-(j + 1)));
						if ((sVariable_c [j] == Symbols [0]) &
							((stext [j] == Symbols [0]) |
								(stext [j] == Symbols [1]))) { // Если сразу после скобки стоит знак "+" или "-"
							if (j + 1 <= stext.Length - 1) {
								//print (stext.Substring((j + 1),stext.Length-(j + 1)));
								for (int k = j + 1; k <= stext.Length - 1; k++) {
									if (sVariable_c [k] != Symbols2 [0]) { // Если не пробел
										if (sVariable_c [k] == Bracket_L [0]) { // Если сразу после знака стоит скобка "("
											for (int k2 = 0; k2 <= 3; k2++) {
												if (stext [k] == Bracket_L [k2]) { // Если сразу после знака стоит откр. скобка любого типа
													sVariable_c [j] = "_".ToCharArray () [0];
													CountOfUnActSymbols1 = CountOfUnActSymbols1+1; // Количество знаков меняющих значение числа, скобки переменной
													// Пометить знак в массиве "AllSymbols1"
													for (int k3 = 0; k3 <= CountOfSymbols1-1; k3++) { //  Найти знак по позиции, в массиве "AllSymbols1"
														if (AllSymbols1 [k3,0] == j) {
															AllSymbols1 [k3,2] = 1; // 2-0=обычный знак, 1=знак меняющий результат
															break;
														}
													}
													break;
												}
											}
										} else if ((sVariable_c [k] == ".".ToCharArray () [0]) |
											(sVariable_c [k] == "№".ToCharArray () [0])) { // Если сразу после знака стоит переменная "." или число "№"
											sVariable_c [j] = "_".ToCharArray () [0];
											CountOfUnActSymbols1 = CountOfUnActSymbols1+1; // Количество знаков меняющих значение числа, скобки переменной
											// Пометить знак в массиве "AllSymbols1"
											for (int k3 = 0; k3 <= CountOfSymbols1-1; k3++) { //  Найти знак по позиции, в массиве "AllSymbols1"
												if (AllSymbols1 [k3,0] == j) {
													AllSymbols1 [k3,2] = 1; // 2-0=обычный знак, 1=знак меняющий результат
													break;
												}
											}
											break;
										} 
										break;
									}
								}

							}
						}
						break;
					}
				}
			}
		}

		// Найти знаки "+","-" сразу после "*","/","^" или "," , поменять в доп. строке на "_" /////////////////////////////////////////
		Pp1 = 0;
		while (Pp1 <= stext.Length - 1) {
			if (sVariable_c [Pp1] != Symbols2 [0]) { // Если не пробел
				//print (sVariable_c [Pp1]+"  "+sVariable_c [Pp1]);
				if (((sVariable_c [Pp1] == Symbols [0]) |
					(sVariable_c [Pp1] == Symbols [5])) &
					((stext [Pp1] == Symbols [2]) |
						(stext [Pp1] == Symbols [3]) |
						(stext [Pp1] == Symbols [4]) |
						(stext [Pp1] == Symbols [5]))) { // Если "*","/","^" или ","
					if (Pp1 + 1 <= stext.Length - 1) {
						for (int k = Pp1 + 1; k <= stext.Length - 1; k++) {
							if (sVariable_c [k] != Symbols2 [0]) { // Если не пробел
								if ((sVariable_c [k] == Symbols [0]) &
									((stext [k] == Symbols [0]) |
										(stext [k] == Symbols [1]))) { // Если "+" или "-"
									sVariable_c [k] = "_".ToCharArray () [0];
									CountOfUnActSymbols1 = CountOfUnActSymbols1+1; // Количество знаков меняющих значение числа, скобки переменной
									// Пометить знак в массиве "AllSymbols1"
									for (int k3 = 0; k3 <= CountOfSymbols1 - 1; k3++) { //  Найти знак по позиции, в массиве "AllSymbols1"
										if (AllSymbols1 [k3, 0] == k) {
											AllSymbols1 [k3, 2] = 1; // 2-0=обычный знак, 1=знак меняющий результат
											break;
										}
									}

									Pp1 = k;
									break;		
								}
								break;
							}
						}
					}
				}
			}
			Pp1 = Pp1 + 1;
		}


		//print (new string(sVariable_c));

		// Объеденить переменные со скобками /////////////////////////////////////////
		bool NextStep1 = false;
		Pp1 = 0;
		for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
			Pp1 = AllVariables1 [i, 1] + 1; // Следующий символ после переменной
			while (Pp1 <= stext.Length - 1) {
				if (sVariable_c [Pp1] != Symbols2 [0]) { // Если не пробел
					//print (sVariable_c [Pp1]+"  "+sVariable_c [Pp1]);
					if (sVariable_c [Pp1] == Symbols2 [3]) { // Если "." переменная
						sVariable_c [Pp1] = Symbols2 [0]; // Убрать переменную (заменить на " " в доп. строке)
						NextStep1 = true;
					}
					else
						if (sVariable_c [Pp1] == Bracket_L [0]) { // Если "(" любая открывающаяся скобка
							for (int k = 0; k <= CountBracket2_3 - 1; k++) {
								if (BracketStep2 [k, 0] == Pp1) { // Найти левую скобку в массиве "BracketStep2" по позиции
									AllVariables1 [i, 2] = k; // Сохранить номер скобок "k" для переменной "i"
									BracketStep2 [k, 7] = i; // номер переменной "AllVariables1" для данных скобок (-1 если нет переменной)
									break;
								}
							}
						}

					if (NextStep1 == true) {
						NextStep1 = false;							     	
					}
					else {
						break;
					}
				}
				Pp1 = Pp1 + 1;
			}		
		}			

		/*for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
			if  (
			//  (AllVariables1 [i, 0]>-1) & 
			//	(AllVariables1 [i, 1]>-1) &
				(AllVariables1 [i, 1]>-1))
				print (i+": "+AllVariables1 [i, 5]+" | "
				+stext.Substring(AllVariables1 [i, 0],
				AllVariables1 [i, 1]-AllVariables1 [i, 0]+1));
		}*/

		/*for (int i = 0; i <= CountOfNumbers1 - 1; i++) {	
		//if (
		//  (AllNumbers1 [i, 0]>-1) & 
		//	(AllNumbers1 [i, 1]>-1) &
		// (AllNumbers1 [i, 2] > -1))
		print (i + "№: " + AllNumbers1 [i, 0] + " | "
			+ (AllNumbers1 [i, 1] - AllNumbers1 [i, 0] + 1) + " | "
			+ stext.Substring (AllNumbers1 [i, 0],
				AllNumbers1 [i, 1] - AllNumbers1 [i, 0] + 1));	
	}*/
	/*for (int i = 0; i <= CountOfSymbols1 - 1; i++) {	
	print (i + ": " + AllSymbols1 [i, 1] + " | "
		+ AllSymbols1 [i, 2] + " | "
		+ s [AllSymbols1 [i, 0]]);	
}*/

// Определить переменные, числа или скобки перед которыми стоит знак "+" или "-", и сохранить в массив переменных, чисел или скобок порядковый номер знака в массиве "AllSymbols1", иначе оставить "-1" /////////////////////////////////////////
for (int i = 0; i <= CountOfSymbols1 - 1; i++) {
	if ((AllSymbols1 [i, 1] == 0) | (AllSymbols1 [i, 1] == 1)) { // Если "+" или "-"
		//if (AllSymbols1 [i, 2] == 1) { // Если знак меняющий результат
		//AllSymbols1 [countsymbol, 1] = j; // 1-Тип знака  0=+, 1=-, 2=*, 3=/, 4=^
		for (int j = AllSymbols1 [i, 0]+1; j <= sVariable_c.Length - 1; j++) {
			if (sVariable_c [j] != Symbols2 [0]) { // Если не пробел
				//print("123: "+s_c [j]+"  "+sVariable_c [j]);
				for (int k = 3; k <= 5; k++) { // Определить какой символ
					if (sVariable_c [j] == Symbols2 [k]) { // Если (".", "№", "(") переменная, число или любая открывающаяся скобка
						if (k == 3) { // Если переменная
							for (int k2 = 0; k2 <= CountOfVariables1 - 1; k2++) {						
								if (AllVariables1 [k2, 0] == j) { // Если позиции совпадают
									AllVariables1 [k2, 3] = i; // Порядковый номер знака в массиве "AllSymbols1"
									if (AllSymbols1 [i, 2] == 1)  // Если знак меняющий результат
										AllVariables1 [k2, 4] = AllSymbols1 [i, 1]; // -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной
									else AllVariables1 [k2, 4] = -(AllSymbols1 [i, 1]+2); // -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной
									break;
								}
							}
						} else if (k == 4) { // Если число
							for (int k2 = 0; k2 <= CountOfNumbers1 - 1; k2++) {						
								if (AllNumbers1 [k2, 0] == j) { // Если позиции совпадают
									AllNumbers1 [k2, 2] = i; // Порядковый номер знака в массиве "AllSymbols1"
									if (AllSymbols1 [i, 2] == 1)  // Если знак меняющий результат
										AllNumbers1 [k2, 3] = AllSymbols1 [i, 1]; //  -3=обычный знак "-" перед числом, -2=обычный знак "+" перед числом, -1=нет меняющего знака перед числом, 0=плюс перед числом, 1=минус перед числом
									else AllNumbers1 [k2, 3] = -(AllSymbols1 [i, 1]+2); // -3=обычный знак "-" перед числом, -2=обычный знак "+" перед числом, -1=нет меняющего знака перед числом, 0=плюс перед числом, 1=минус перед числом
									break;
								}
							}
						} else if (k == 5) { // Если скобка
							for (int k2 = 0; k2 <= CountBracket2_3 - 1; k2++) {						
								if (BracketStep2 [k2, 0] == j) { // Если позиции совпадают
									BracketStep2 [k2, 5] = i; // Порядковый номер знака в массиве "AllSymbols1"
									if (AllSymbols1 [i, 2] == 1)  // Если знак меняющий результат
										BracketStep2 [k2, 6] = AllSymbols1 [i, 1]; //  -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой
									else {
										BracketStep2 [k2, 6] = -(AllSymbols1 [i, 1]+2); // -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой
									}
									//print(AllSymbols1 [i, 2]
									//	+"  "+AllSymbols1 [i, 1]
									//	+"  "+BracketStep2 [k2, 6]);
									break;
								}
							}
						}
						break;
					}					
				}
				break;
			}
		}
	}								
}


/*for (int i = 0; i <= CountBracket2_3 - 1; i++) {	
	if ((BracketStep2 [i, 6] != -1) & (BracketStep2 [i, 5] > -1)) {
		//print (i + "C2: " + BracketStep2 [i, 5] + " | "
		//	+ AllSymbols1 [BracketStep2 [i, 5], 0]+ " | "
		//	+ BracketStep2 [i, 1]+ " | "
		//	+ (BracketStep2 [i, 1] - AllSymbols1 [BracketStep2 [i, 5], 0]+1));	
		print (i + "1: "
			+ stext.Substring (AllSymbols1 [BracketStep2 [i, 5], 0],
				BracketStep2 [i, 1] - AllSymbols1 [BracketStep2 [i, 5], 0] + 1));		
	} else {
		print (i + "2: "
			+ stext.Substring (BracketStep2 [i, 0],
				BracketStep2 [i, 1] - BracketStep2 [i, 0]+1));	
	}
}*/

/*// Проверить знаки меняющие результат /////////////////////////////////////////
for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
	if (AllVariables1 [i, 3] > -1)
		print (i + "A: " + AllVariables1 [i, 2] + " | "
			+ stext.Substring (AllSymbols1 [AllVariables1 [i, 3], 0],
				AllVariables1 [i, 1] - AllSymbols1 [AllVariables1 [i, 3], 0]+1));		
}
for (int i = 0; i <= CountOfNumbers1 - 1; i++) {	
	if (AllNumbers1 [i, 2] > -1) {
		print (i + "B: " + AllNumbers1 [i, 2] + " | "
			+ stext.Substring (AllSymbols1 [AllNumbers1 [i, 2], 0],
				AllNumbers1 [i, 1] - AllSymbols1 [AllNumbers1 [i, 2], 0]+1));		
	}
}
for (int i = 0; i <= CountBracket2_3 - 1; i++) {	
	if (BracketStep2 [i, 5] > -1) {
		print (i + "C: " + BracketStep2 [i, 2] + " | "
			+ stext.Substring (AllSymbols1 [BracketStep2 [i, 5], 0],
				BracketStep2 [i, 1] - AllSymbols1 [BracketStep2 [i, 5], 0]+1));		
	}
}*/

//stext = new string(s_c);
sVariable = new string(sVariable_c);
//s_c = stext.ToCharArray();
//sVariable_c = sVariable.ToCharArray();
int Pp1_2 = 0;

// Расставить дополнительные скобки, слева и справа от знака "^" (возведение в степень), поменять в доп. строке на "[","]" /////////////////////////////////////////
int CountBracket2_4 = CountBracket2_3+1;
CountAddBracket = 0; // кол-во добавленных пар скобок
Pp1 = 0;
Pp2 = 0;
Pp3 = -1;
NextStep1 = false;
bool MakeBracketR = false;
bool MakeBracketL = false;
int TheSame_L = -1;
bool TheSameR = false;
int TheSameN_L = -1;
int TheSameV_L = -1;
int TheSameS_L = -1;
int TheSame_R = -1;
int TheSameN_R = -1;
int TheSameV_R = -1;
//while (Pp1 <= stext.Length - 1) {
Pp1 = stext.Length - 1;
while (Pp1 >= 0) {	
	if (sVariable [Pp1] != Symbols2 [0]) { // Если не пробел
		//print (s [Pp1]+"  "+sVariable [Pp1]);
		if ((sVariable [Pp1] == Symbols [0]) &
			(stext [Pp1] == Symbols [4]) & ((MakeBracketL == false) | 
				(MakeBracketR == false))) { // Если "^"
			//print (stext [Pp1] + " ! " + sVariable [Pp1]);
			//print ("0: " + Pp1 + "  " + stext [Pp1]);


			// Искать вправо ↓↓↓ ///////////////////////////////////////////////////////////////
			if (Pp1 + 1 <= stext.Length - 1) {
				Pp2 = Pp1 + 1;
				while (Pp2 <= stext.Length - 1) {
					//print (s [Pp2] + " = " + sVariable [Pp2] + " = " + Pp2);
					if (sVariable [Pp2] != Symbols2 [0]) { // Если не пробел
						//print (s [Pp2] + " + " + sVariable [Pp2]);
						//print ("6: " + Pp2 + "  " + stext [Pp2]);
						if ((sVariable [Pp2] == Bracket_L [0]) |
							(sVariable [Pp2] == Bracket_L [2])) { // Если любая открывающаяся скобка
							//NextStep1 = true;
							MakeBracketR = true;
							for (int k = 0; k <= CountBracket2_4 - 1; k++) {
								if (BracketStep2 [k, 0] == Pp2) { // Найти левую скобку в массиве "BracketStep2" по позиции
									TheSameN_R = -1; // >-1 Если скобка после числа
									TheSameV_R = -1; // >-1 Если скобка после переменной
									TheSame_R = k; // >-1 -такая правая скобка уже есть
									Pp3 = BracketStep2 [k, 1]; // Указать позицию вероятной новой скобки
									//print ("2: " + Pp3 + "  " + stext [Pp3]);
									Pp2 = Pp3;
									//MakeBracketR = true;
									break;
								}
							}
						} else if ((sVariable [Pp2] == "_".ToCharArray () [0]) &
							((stext [Pp2] == Symbols [0]) |
								(stext [Pp2] == Symbols [1]))) { // Если "+" или "-" (знак меняющий результат, перед скобкой, переменной или числом)														
							NextStep1 = true;	
							//MakeBracketR = false;
							//} else if ((sVariable [Pp2] == "+".ToCharArray () [0]) &
							//	(stext [Pp2] == Symbols [4])) { // Если "^"
							//	NextStep1 = true;	
							//MakeBracketR = false;
						} else if (sVariable [Pp2] == Symbols2 [3]) { // Если "." переменная																		
							//NextStep1 = true;
							MakeBracketR = true;
							for (int k = 0; k <= CountOfVariables1 - 1; k++) { // Найти переменную по позиции в массиве "AllVariables1"
								if (AllVariables1 [k, 0] == Pp2) {
									if (AllVariables1 [k, 2] > -1) { // Если у переменной есть скобки												
										TheSameN_R = -1; // >-1 Если скобка после числа
										TheSameV_R = -1; // >-1 Если скобка после переменной
										TheSame_R = AllVariables1 [k, 2]; // >-1 -такая правая скобка уже есть
										Pp3 = BracketStep2 [AllVariables1 [k, 2], 1]; // Указать позицию вероятной новой скобки
										//print ("3: " + Pp3 + "  " + stext [Pp3]);
										Pp2 = Pp3;
									} else { // Если у переменной нет скобок
										TheSameN_R = -1; // >-1 Если скобка после числа
										TheSameV_R = k; // >-1 Если скобка после переменной
										TheSame_R = -1; // >-1 -такая правая скобка уже есть
										Pp3 = AllVariables1 [k, 1]; // Указать позицию вероятной новой скобки
										//print ("4: " + Pp3 + "  " + stext [Pp3]);
										Pp2 = Pp3;
									}
									//MakeBracketR = true;
									break;
								}
							}
						} else if (sVariable [Pp2] == Symbols2 [4]) { // Если "№" число														
							//NextStep1 = true;
							MakeBracketR = true;
							for (int k = 0; k <= CountOfNumbers1 - 1; k++) { // Найти число по позиции в массиве "AllNumbers1"
								if (AllNumbers1 [k, 0] == Pp2) {
									TheSameN_R = k; // >-1 Если скобка после числа
									TheSameV_R = -1; // >-1 Если скобка после переменной
									TheSame_R = -1; // >-1 -такая правая скобка уже есть
									//print (s [Pp2] + " -+- " + sVariable [Pp2]);
									Pp3 = AllNumbers1 [k, 1]; // Указать позицию вероятной новой скобки
									//print ("5: " + Pp3 + "  " + stext [Pp3]);
									Pp2 = Pp3;
									//MakeBracketR = true;
									break;
								}
							}
						}

						if (NextStep1 == true) {
							NextStep1 = false;
							//print (s [Pp2] + " = " + sVariable [Pp2]);
						} else {
							break;
						}
					}
					Pp2 = Pp2 + 1;
				}
			}
			// Искать вправо ↑↑↑ ///////////////////////////////////////////////////////////////


			// Искать влево ↓↓↓ ///////////////////////////////////////////////////////////////
			if (MakeBracketL == false) {
				if (Pp1 - 1 >= 0) {
					Pp2 = Pp1 - 1;
					Pp1_2 = Pp1;
					while (Pp2 >= 0) {
						//print ("222: " + s [Pp2] + " = " + sVariable [Pp2] + " = " + Pp2);
						if (sVariable [Pp2] != Symbols2 [0]) { // Если не пробел
							Pp1 = Pp2+1; // Указать позицию вероятной новой скобки
							//print ("222: " + s [Pp2] + " + " + sVariable [Pp2]);
							if ((sVariable [Pp2] == Bracket_R [0]) |
								(sVariable [Pp2] == Bracket_R [2])) { // Если любая закрывающаяся скобка
								NextStep1 = true;
								MakeBracketL = true;
								for (int k = 0; k <= CountBracket2_4 - 1; k++) {
									if (BracketStep2 [k, 1] == Pp2) { // Найти правую скобку в массиве "BracketStep2" по позиции
										TheSameN_L = -1; // >-1 Если скобка перед числом
										TheSameV_L = -1; // >-1 Если скобка перед переменной
										TheSame_L = k; // >-1 -такая левая скобка уже есть
										TheSameS_L = -1; // >-1 Если скобка перед знаком
										Pp1 = BracketStep2 [k, 0]; // Указать позицию вероятной новой скобки
										Pp2 = Pp1;
										break;
									}
								}
							} else if ((sVariable [Pp2] == "_".ToCharArray () [0]) &
								((stext [Pp2] == Symbols [0]) |
									(stext [Pp2] == Symbols [1]))) { // Если "+" или "-" (знак меняющий результат, перед скобкой, переменной или числом)														
								for (int k = 0; k <= CountOfSymbols1 - 1; k++) {	
									if (AllSymbols1 [k, 0] == Pp2) {
										TheSameS_L = k; // >-1 Если скобка перед знаком
										break;
									}
								}
								NextStep1 = true;
								MakeBracketL = true;
								Pp1 = Pp2; // Указать позицию вероятной новой скобки
								//} else if ((sVariable [Pp2] == "+".ToCharArray () [0]) &
								//	(stext [Pp2] == Symbols [4])) { // Если "^"
								//	NextStep1 = true;	
								//MakeBracketR = false;
							} else if (sVariable [Pp2] == Symbols2 [3]) { // Если "." переменная																		
								NextStep1 = true;
								MakeBracketL = true;
								for (int k = 0; k <= CountOfVariables1 - 1; k++) { // Найти переменную по позиции в массиве "AllVariables1"
									if (AllVariables1 [k, 1] == Pp2) {
										TheSameN_L = -1; // >-1 Если скобка перед числом
										TheSameV_L = k; // >-1 Если скобка перед переменной
										TheSame_L = -1; // >-1 -такая левая скобка уже есть
										TheSameS_L = -1; // >-1 Если скобка перед знаком
										Pp1 = AllVariables1 [k, 0]; // Указать позицию вероятной новой скобки
										Pp2 = Pp1;
										break;
									}
								}
							} else if (sVariable [Pp2] == Symbols2 [4]) { // Если "№" число														
								NextStep1 = true;
								MakeBracketL = true;
								for (int k = 0; k <= CountOfNumbers1 - 1; k++) { // Найти число по позиции в массиве "AllNumbers1"
									if (AllNumbers1 [k, 1] == Pp2) {
										//print ("222: "+s [Pp2] + " -+- " + sVariable [Pp2]);
										TheSameN_L = k; // >-1 Если скобка перед числом
										TheSameV_L = -1; // >-1 Если скобка перед переменной
										TheSame_L = -1; // >-1 -такая левая скобка уже есть
										TheSameS_L = -1; // >-1 Если скобка перед знаком
										Pp1 = AllNumbers1 [k, 0]; // Указать позицию вероятной новой скобки
										//print ("1: " + Pp1 + "  " + stext [Pp1]);
										Pp2 = Pp1;
										break;
									}
								}
							}

							if (NextStep1 == true) {
								NextStep1 = false;
								//print ("222: "+s [Pp2] + " = " + sVariable [Pp2]);
							} else {
								break;
							}
						}
						Pp2 = Pp2 - 1;
					}
				}


			}
			// Искать влево ↑↑↑ ///////////////////////////////////////////////////////////////

		} else {
			if ((MakeBracketL == true) & (MakeBracketR == true)) { 

				TheSameR = false; // true-такая правая скобка уже есть
				/*if (TheSame_L > -1) { // Если перед скобкой
					// Проверить существование таких же скобок
					//for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
					// Если левая скобка заменяет другую левую скобку "i"
					//	if (BracketStep2 [i, 0] == Pp1) {
					//		TheSame_L = i; // >-1 -такая левая скобка уже есть
					// Если правая скобка заменяет другую правую скобку "i"
					if (BracketStep2 [TheSame_L, 1] == Pp3) {
						TheSameR = true; // true-такая правая скобка уже есть
					}
					//		break;
					//	}				
					//}	
				} else */
				{ // Определить левую скобку по правой
					Pp1 = Pp1 + 1;
					Pp3 = Pp3 + 1;

					if ((sVariable [Pp3] == Bracket_R [0]) |
						(sVariable [Pp3] == Bracket_R [2]) |
						(sVariable [Pp3] == Bracket_R [3])) { // Если любая закрывающаяся скобка
						for (int k = 0; k <= CountBracket2_4 - 1; k++) {
							if (BracketStep2 [k, 1] == Pp3) { // Найти правую скобку в массиве "BracketStep2" по позиции
								if (BracketStep2 [k, 0] == Pp1-1) { // Если совпадает с леой скобкой
									TheSameN_L = -1; // >-1 Если скобка перед числом
									TheSameV_L = -1; // >-1 Если скобка перед переменной
									TheSame_L = k; // >-1 -такая левая скобка уже есть
									TheSameR = true; // true-такая правая скобка уже есть
									//print ("456: " + Pp1 + "  " + stext [Pp1]);
									break;
								}
							}
						}
					}
				}

				//print ("!!!: " + (Pp3-1) + "  " + stext [Pp3-1]
				//	+" 525: " + Pp1 + "  " + stext [Pp1]);

				if ((TheSame_L == -1) | (TheSameR == false)) { // Если таких скобок нет
					//if (MakeBracketL == true) // Левая новая скобка
					{
						stext = stext.Insert (Pp1, "(");
						sVariable = sVariable.Insert (Pp1, "[");
						//print ("321: " + Pp1 + "  " + s [Pp1]);

						// +1 к позициям в массивах (для позиций >= чем "Pp1") ↓↓↓ ///////////////////////////////////////////////////////////////
						if (CountOfCommas1 > 0) {
							for (int i = 0; i <= CountOfCommas1 - 1; i++) {
								if (CommasInText [i, 0] >= Pp1)
									CommasInText [i, 0] = CommasInText [i, 0]+1; // 0-позиция запятых
							}
						}
						if (CountOfSymbols1 > 0) {
							for (int i = 0; i <= CountOfSymbols1 - 1; i++) {	
								if (AllSymbols1 [i, 0] >= Pp1)
									AllSymbols1 [i, 0] = AllSymbols1 [i, 0] + 1;
							}
						}
						if (CountOfVariables1 > 0) {
							for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
								if (AllVariables1 [i, 0] >= Pp1) {
									AllVariables1 [i, 0] = AllVariables1 [i, 0] + 1;
									//if (AllVariables1 [i, 1] >= Pp1)
									AllVariables1 [i, 1] = AllVariables1 [i, 1] + 1;					
								}
							}
						}
						if (CountOfNumbers1 > 0) {
							for (int i = 0; i <= CountOfNumbers1 - 1; i++) {	
								if (AllNumbers1 [i, 0] >= Pp1) {
									AllNumbers1 [i, 0] = AllNumbers1 [i, 0] + 1;
									//	if (AllNumbers1 [i, 1] >= Pp1)
									AllNumbers1 [i, 1] = AllNumbers1 [i, 1] + 1;					
									//print ("555: " +i+"  "+ AllNumbers1 [i, 0] 
									//	+ "  " + AllNumbers1 [i, 1]);
								}
							}
						}
						if (CountBracket2_4 > 0) {
							for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
								if (BracketStep2 [i, 0] >= Pp1)
									BracketStep2 [i, 0] = BracketStep2 [i, 0] + 1;
								if (BracketStep2 [i, 1] >= Pp1)
									BracketStep2 [i, 1] = BracketStep2 [i, 1] + 1;					
							}		
						}
						// +1 к позициям в массивах (для позиций больше чем "Pp1") ↑↑↑ ///////////////////////////////////////////////////////////////

						BracketStep2 [CountBracket2_4 - 1, 0] = Pp1; // Позиция левой скобки

						//MakeBracketL = false;
					}

					//if (MakeBracketR == true) // Правая новая скобка
					{
						Pp3 = Pp3 + 1;
						Pp1 = Pp3;
						stext = stext.Insert (Pp3, ")");
						sVariable = sVariable.Insert (Pp3, "]");
						//print ("123: " + Pp3 + "  " + s [Pp3]);

						// +1 к позициям в массивах (для позиций >= чем "Pp3") ↓↓↓ ///////////////////////////////////////////////////////////////
						if (CountOfCommas1 > 0) {
							for (int i = 0; i <= CountOfCommas1 - 1; i++) {
								if (CommasInText [i, 0] >= Pp3)
									CommasInText [i, 0] = CommasInText [i, 0]+1; // 0-позиция запятых
							}
						}
						if (CountOfSymbols1 > 0) {
							for (int i = 0; i <= CountOfSymbols1 - 1; i++) {	
								if (AllSymbols1 [i, 0] >= Pp3)
									AllSymbols1 [i, 0] = AllSymbols1 [i, 0] + 1;
							}
						}
						if (CountOfVariables1 > 0) {
							for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
								if (AllVariables1 [i, 0] >= Pp3) {
									AllVariables1 [i, 0] = AllVariables1 [i, 0] + 1;
									//if (AllVariables1 [i, 1] >= Pp3)
									AllVariables1 [i, 1] = AllVariables1 [i, 1] + 1;					
								}
							}
						}
						if (CountOfNumbers1 > 0) {
							for (int i = 0; i <= CountOfNumbers1 - 1; i++) {	
								if (AllNumbers1 [i, 0] >= Pp3) {
									AllNumbers1 [i, 0] = AllNumbers1 [i, 0] + 1;
									//	if (AllNumbers1 [i, 1] >= Pp3)
									AllNumbers1 [i, 1] = AllNumbers1 [i, 1] + 1;					
									//print ("555: " +i+"  "+ AllNumbers1 [i, 0] 
									//	+ "  " + AllNumbers1 [i, 1]);
								}
							}
						}
						if (CountBracket2_4 > 0) {
							for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
								if (BracketStep2 [i, 0] >= Pp3)
									BracketStep2 [i, 0] = BracketStep2 [i, 0] + 1;
								if (BracketStep2 [i, 1] >= Pp3)
									BracketStep2 [i, 1] = BracketStep2 [i, 1] + 1;					
							}		
						}
						// +1 к позициям в массивах (для позиций больше чем "Pp3") ↑↑↑ ///////////////////////////////////////////////////////////////

						BracketStep2 [CountBracket2_4 - 1, 1] = Pp3; // Позиция правой скобки
						BracketStep2 [CountBracket2_4 - 1, 2] = 4; // Тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные)
						BracketStep2 [CountBracket2_4 - 1, 5] = -1; // Порядковый номер знака в массиве "AllSymbols1"
						BracketStep2 [CountBracket2_4 - 1, 6] = -1; // -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой													
					}

					if (TheSame_L > -1) { // Если перед скобкой
						BracketStep2 [CountBracket2_4 - 1, 10] = BracketStep2 [TheSame_L, 10]; // 10-первоначальная левая позиция скобки

						//print (BracketStep2 [TheSame_L, 5] + " ! " + BracketStep2 [TheSame_L, 6]);
						//print (stext.Substring (BracketStep2 [TheSame_L, 0],
						//	BracketStep2 [TheSame_L, 1] - BracketStep2 [TheSame_L, 0] + 5));
						// Установить знак предыдущей скобки к новой
						BracketStep2 [CountBracket2_4 - 1, 5] = BracketStep2 [TheSame_L, 5]; // Порядковый номер знака в массиве "AllSymbols1"
						BracketStep2 [CountBracket2_4 - 1, 6] = BracketStep2 [TheSame_L, 6]; // -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой
						// Убрать знак предыдущей скобки
						BracketStep2 [TheSame_L, 5] = -1; // Порядковый номер знака в массиве "AllSymbols1"
						BracketStep2 [TheSame_L, 6] = -1; // -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой					
					} else if (TheSameN_L > -1) { // Если перед числом
						BracketStep2 [CountBracket2_4 - 1, 10] = AllNumbers1 [TheSameN_L, 4]; // 4-первоначальная левая позиция числа

						if (AllNumbers1 [TheSameN_L, 3] < -1) { // Если обычный знак "+","-"
							// Установить знак предыдущего числа к новой скобке	
							BracketStep2 [CountBracket2_4 - 1, 5] = AllNumbers1 [TheSameN_L, 2]; // Порядковый номер знака в массиве "AllSymbols1"
							BracketStep2 [CountBracket2_4 - 1, 6] = AllNumbers1 [TheSameN_L, 3]; //  -3=обычный знак "-" перед числом, -2=обычный знак "+" перед числом, -1=нет меняющего знака перед числом, 0=плюс перед числом, 1=минус перед числом
							// Убрать знак предыдущего числа
							AllNumbers1 [TheSameN_L, 2] = -1; // Порядковый номер знака в массиве "AllSymbols1"
							AllNumbers1 [TheSameN_L, 3] = -1; //  -3=обычный знак "-" перед числом, -2=обычный знак "+" перед числом, -1=нет меняющего знака перед числом, 0=плюс перед числом, 1=минус перед числом						
						}
					} else if (TheSameV_L > -1) { // Если перед переменной
						BracketStep2 [CountBracket2_4 - 1, 10] = AllVariables1 [TheSameV_L, 6]; // 6-первоначальная позиция левой переменной

						if (AllVariables1 [TheSameV_L, 4] < -1) { // Если обычный знак "+","-"							
							// Установить знак предыдущей переменной к новой скобке	
							BracketStep2 [CountBracket2_4 - 1, 5] = AllVariables1 [TheSameV_L, 3]; // Порядковый номер знака в массиве "AllSymbols1"
							BracketStep2 [CountBracket2_4 - 1, 6] = AllVariables1 [TheSameV_L, 4]; //  -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной
							// Убрать знак предыдущей переменной
							AllVariables1 [TheSameV_L, 3] = -1; // Порядковый номер знака в массиве "AllSymbols1"
							AllVariables1 [TheSameV_L, 4] = -1; //  -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной
						}
					}
					if (TheSameS_L > -1) { // Если перед знаком
						BracketStep2 [CountBracket2_4 - 1, 10] = AllSymbols1 [TheSameS_L, 3]; // 3-первоначальная позиция знака
					}

					if (TheSame_R > -1) { // Если после скобки
						BracketStep2 [CountBracket2_4 - 1, 11] = BracketStep2 [TheSame_R, 11]; // 11-первоначальная правая позиция скобки
					} else if (TheSameN_R > -1) { // Если после числа
						BracketStep2 [CountBracket2_4 - 1, 11] = AllNumbers1 [TheSameN_R, 5]; // 5-первоначальная правая позиция числа
					} else if (TheSameV_R > -1) { // Если после переменной
						BracketStep2 [CountBracket2_4 - 1, 11] = AllVariables1 [TheSameV_R, 7]; // 7-первоначальная позиция правой переменной
					}

					//if ((BracketStep2 [CountBracket2_4 - 1, 10] > -1) &
					//	(BracketStep2 [CountBracket2_4 - 1, 11] > -1)) {
					//	print ("1???: " + s1.Substring (BracketStep2 [CountBracket2_4 - 1, 10] - 1, 
					//		BracketStep2 [CountBracket2_4 - 1, 11] 
					//		- BracketStep2 [CountBracket2_4 - 1, 10] + 1));
					//}

					CountBracket2_4 = CountBracket2_4 + 1;	
					CountAddBracket = CountAddBracket + 1; // кол-во добавленных пар скобок
				}
				TheSameN_L = -1; // >-1 Если скобка перед числом
				TheSameV_L = -1; // >-1 Если скобка перед переменной
				TheSame_L = -1; // >-1 -такая левая скобка уже есть
				TheSameS_L = -1; // >-1 Если скобка перед знаком
				TheSameN_R = -1; // >-1 Если скобка после числа
				TheSameV_R = -1; // >-1 Если скобка после переменной
				TheSame_R = -1; // >-1 -такая правая скобка уже есть

				MakeBracketL = false;
				MakeBracketR = false;
				Pp1 = Pp1_2;
			}
		}

	}
	Pp1 = Pp1 - 1;		
}


// Расставить дополнительные скобки, слева и справа от знаков "*","/", поменять в доп. строке на "[","]" /////////////////////////////////////////
Pp1_2 = 0;
Pp1 = 0;
Pp2 = 0;
Pp3 = -1;
NextStep1 = false;
MakeBracketR = false;
MakeBracketL = false;
TheSame_L = -1;
TheSameN_L = -1;
TheSameV_L = -1;
TheSameS_L = -1;
TheSame_R = -1;
TheSameN_R = -1;
TheSameV_R = -1;
while (Pp1 <= stext.Length - 1) {
	if (sVariable [Pp1] != Symbols2 [0]) { // Если не пробел
		//print (s [Pp1]+"  "+sVariable [Pp1]);
		if ((sVariable [Pp1] == Symbols [0]) &
			((stext [Pp1] == Symbols [2]) |
				(stext [Pp1] == Symbols [3]))) { // Если "*","/"
			//print (s [Pp1] + " ! " + sVariable [Pp1]);

			// Искать влево ↓↓↓ ///////////////////////////////////////////////////////////////
			if (MakeBracketL == false) {
				if (Pp1 - 1 >= 0) {
					Pp2 = Pp1 - 1;
					while (Pp2 >= 0) {
						//print ("222: " + s [Pp2] + " = " + sVariable [Pp2] + " = " + Pp2);
						if (sVariable [Pp2] != Symbols2 [0]) { // Если не пробел
							Pp3 = Pp2+1; // Указать позицию вероятной новой скобки
							//print ("222: " + s [Pp2] + " + " + sVariable [Pp2]);
							if ((sVariable [Pp2] == Bracket_R [0]) |
								(sVariable [Pp2] == Bracket_R [2])) { // Если любая закрывающаяся скобка
								NextStep1 = true;
								MakeBracketL = true;
								for (int k = 0; k <= CountBracket2_4 - 1; k++) {
									if (BracketStep2 [k, 1] == Pp2) { // Найти правую скобку в массиве "BracketStep2" по позиции
										TheSameN_L = -1; // >-1 Если скобка перед числом
										TheSameV_L = -1; // >-1 Если скобка перед переменной
										TheSame_L = k; // >-1 -такая левая скобка уже есть
										TheSameS_L = -1; // >-1 Если скобка перед знаком
										Pp3 = BracketStep2 [k, 0]; // Указать позицию вероятной новой скобки
										Pp2 = Pp3;
										break;
									}
								}
							} else if ((sVariable [Pp2] == "_".ToCharArray () [0]) &
								((stext [Pp2] == Symbols [0]) |
									(stext [Pp2] == Symbols [1]))) { // Если "+" или "-" (знак меняющий результат, перед скобкой, переменной или числом)														
								for (int k = 0; k <= CountOfSymbols1 - 1; k++) {	
									if (AllSymbols1 [k, 0] == Pp2) {
										TheSameS_L = k; // >-1 Если скобка перед знаком
										break;
									}
								}
								NextStep1 = true;
								MakeBracketL = true;
								Pp3 = Pp2; // Указать позицию вероятной новой скобки
							} else if ((sVariable [Pp2] == "+".ToCharArray () [0]) &
								((stext [Pp2] == Symbols [2]) |
									(stext [Pp2] == Symbols [3]))) { // Если "*" или "/" 
								NextStep1 = true;
								//print (Pp1+" %C "+stext [Pp2] + " + " + sVariable [Pp2]);
								//MakeBracketR = false;
							} else if (sVariable [Pp2] == Symbols2 [3]) { // Если "." переменная																		
								NextStep1 = true;
								MakeBracketL = true;
								for (int k = 0; k <= CountOfVariables1 - 1; k++) { // Найти переменную по позиции в массиве "AllVariables1"
									if (AllVariables1 [k, 1] == Pp2) {
										TheSameN_L = -1; // >-1 Если скобка перед числом
										TheSameV_L = k; // >-1 Если скобка перед переменной
										TheSame_L = -1; // >-1 -такая левая скобка уже есть
										TheSameS_L = -1; // >-1 Если скобка перед знаком
										Pp3 = AllVariables1 [k, 0]; // Указать позицию вероятной новой скобки
										Pp2 = Pp3;
										break;
									}
								}
							} else if (sVariable [Pp2] == Symbols2 [4]) { // Если "№" число														
								NextStep1 = true;
								MakeBracketL = true;
								for (int k = 0; k <= CountOfNumbers1 - 1; k++) { // Найти число по позиции в массиве "AllNumbers1"
									if (AllNumbers1 [k, 1] == Pp2) {
										//print ("222: "+Pp2+"   "+stext [Pp2] + " -+- " + sVariable [Pp2]);
										TheSameN_L = k; // >-1 Если скобка перед числом
										TheSameV_L = -1; // >-1 Если скобка перед переменной
										TheSame_L = -1; // >-1 -такая левая скобка уже есть
										TheSameS_L = -1; // >-1 Если скобка перед знаком
										Pp3 = AllNumbers1 [k, 0]; // Указать позицию вероятной новой скобки
										Pp2 = Pp3;
										break;
									}
								}
							}

							if (NextStep1 == true) {
								NextStep1 = false;
								//print ("222: "+s [Pp2] + " = " + sVariable [Pp2]);
							} else {
								break;
							}
						}
						Pp2 = Pp2 - 1;
					}
				}


			}
			// Искать влево ↑↑↑ ///////////////////////////////////////////////////////////////

			// Искать вправо ↓↓↓ ///////////////////////////////////////////////////////////////
			if (Pp1 + 1 <= stext.Length - 1) {
				Pp2 = Pp1 + 1;
				Pp1_2 = Pp1;
				while (Pp2 <= stext.Length - 1) {
					//print (s [Pp2] + " = " + sVariable [Pp2] + " = " + Pp2);
					if (sVariable [Pp2] != Symbols2 [0]) { // Если не пробел
						//print (s [Pp2] + " + " + sVariable [Pp2]);
						if ((sVariable [Pp2] == Bracket_L [0]) |
							(sVariable [Pp2] == Bracket_L [2])) { // Если любая открывающаяся скобка
							NextStep1 = true;
							MakeBracketR = true;
							for (int k = 0; k <= CountBracket2_4 - 1; k++) {
								if (BracketStep2 [k, 0] == Pp2) { // Найти левую скобку в массиве "BracketStep2" по позиции
									TheSameN_R = -1; // >-1 Если скобка после числа
									TheSameV_R = -1; // >-1 Если скобка после переменной
									TheSame_R = k; // >-1 -такая правая скобка уже есть
									Pp1 = BracketStep2 [k, 1]; // Указать позицию вероятной новой скобки
									Pp2 = Pp1;
									//Pp1_2 =  = BracketStep2 [k, 1]; // Указать позицию вероятной новой скобки
									//print (Pp1+" % "+stext [Pp2] + " + " + sVariable [Pp2]);
									//MakeBracketR = true;
									break;
								}
							}
						} else if ((sVariable [Pp2] == "_".ToCharArray () [0]) &
							((stext [Pp2] == Symbols [0]) |
								(stext [Pp2] == Symbols [1]))) { // Если "+" или "-" (знак меняющий результат, перед скобкой, переменной или числом)														
							NextStep1 = true;
							//print (Pp1+" %C "+stext [Pp2] + " + " + sVariable [Pp2]);
							//MakeBracketR = false;
						} else if ((sVariable [Pp2] == "+".ToCharArray () [0]) &
							((stext [Pp2] == Symbols [2]) |
								(stext [Pp2] == Symbols [3]))) { // Если "*" или "/" 
							NextStep1 = true;
							//print (Pp1+" %C "+stext [Pp2] + " + " + sVariable [Pp2]);
							//MakeBracketR = false;
						} else if (sVariable [Pp2] == Symbols2 [3]) { // Если "." переменная																		
							NextStep1 = true;
							MakeBracketR = true;
							for (int k = 0; k <= CountOfVariables1 - 1; k++) { // Найти переменную по позиции в массиве "AllVariables1"
								if (AllVariables1 [k, 0] == Pp2) {
									if (AllVariables1 [k, 2] > -1) { // Если у переменной есть скобки												
										TheSameN_R = -1; // >-1 Если скобка после числа
										TheSameV_R = -1; // >-1 Если скобка после переменной
										TheSame_R = AllVariables1 [k, 2]; // >-1 -такая правая скобка уже есть
										Pp1 = BracketStep2 [AllVariables1 [k, 2], 1]; // Указать позицию вероятной новой скобки
										Pp2 = Pp1;
										//Pp1_2 = BracketStep2 [AllVariables1 [k, 2], 1]; // Указать позицию вероятной новой скобки
									} else { // Если у переменной нет скобок
										TheSameN_R = -1; // >-1 Если скобка после числа
										TheSameV_R = k; // >-1 Если скобка после переменной
										TheSame_R = -1; // >-1 -такая правая скобка уже есть
										Pp1 = AllVariables1 [k, 1]; // Указать позицию вероятной новой скобки
										Pp2 = Pp1;
										//Pp1_2 = AllVariables1 [k, 1]; // Указать позицию вероятной новой скобки
									}
									//print (Pp1+" %A "+stext [Pp2] + " + " + sVariable [Pp2]);
									//MakeBracketR = true;
									break;
								}
							}
						} else if (sVariable [Pp2] == Symbols2 [4]) { // Если "№" число														
							NextStep1 = true;
							MakeBracketR = true;
							for (int k = 0; k <= CountOfNumbers1 - 1; k++) { // Найти число по позиции в массиве "AllNumbers1"
								if (AllNumbers1 [k, 0] == Pp2) {
									TheSameN_R = k; // >-1 Если скобка после числа
									TheSameV_R = -1; // >-1 Если скобка после переменной
									TheSame_R = -1; // >-1 -такая правая скобка уже есть
									//print (s [Pp2] + " -+- " + sVariable [Pp2]);
									Pp1 = AllNumbers1 [k, 1]; // Указать позицию вероятной новой скобки
									Pp2 = Pp1;
									//Pp1_2 = AllNumbers1 [k, 1]; // Указать позицию вероятной новой скобки
									//print (Pp1+" %B "+stext [Pp2] + " + " + sVariable [Pp2]);
									//MakeBracketR = true;
									break;
								}
							}
						}

						if (NextStep1 == true) {
							NextStep1 = false;
							//print (s [Pp2] + " = " + sVariable [Pp2]);
						} else {
							break;
						}
					}
					Pp2 = Pp2 + 1;
				}
			}
			// Искать вправо ↑↑↑ ///////////////////////////////////////////////////////////////

		} else {

			//print (Pp1+" D ");

			if ((MakeBracketL == true) & (MakeBracketR == true)) 
			{ 

				TheSameR = false; // true-такая правая скобка уже есть
				/*if (TheSame_L > -1) { // Если перед скобкой
					// Проверить существование таких же скобок
					//for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
					// Если левая скобка заменяет другую левую скобку "i"
					//	if (BracketStep2 [i, 0] == Pp3) {
					//		TheSame_L = i; // >-1 -такая левая скобка уже есть
					// Если правая скобка заменяет другую правую скобку "i"
					if (BracketStep2 [TheSame_L, 1] == Pp1) {
						TheSameR = true; // true-такая правая скобка уже есть
					}
					//		break;
					//	}				
					//}	
				} else */
				{ // Определить левую скобку по правой
					if ((sVariable [Pp1] == Bracket_R [0]) |
						(sVariable [Pp1] == Bracket_R [2]) |
						(sVariable [Pp1] == Bracket_R [3])) { // Если любая закрывающаяся скобка
						for (int k = 0; k <= CountBracket2_4 - 1; k++) {
							if (BracketStep2 [k, 1] == Pp1) { // Найти правую скобку в массиве "BracketStep2" по позиции
								if (BracketStep2 [k, 0] == Pp3-1) { // Если совпадает с леой скобкой
									TheSameN_L = -1; // >-1 Если скобка перед числом
									TheSameV_L = -1; // >-1 Если скобка перед переменной
									TheSame_L = k; // >-1 -такая левая скобка уже есть
									TheSameR = true; // true-такая правая скобка уже есть
									//TheSame_L = -1; // >-1 -такая левая скобка уже есть
									//TheSameR = false; // true-такая правая скобка уже есть
									//print ("456: " + Pp3 + "  " + stext [Pp3]);
									break;
								}
							}
						}
					}
				}

				//print ("!!!: " + (Pp3-1) + "  " + stext [Pp3-1]
				//	+" 525: " + Pp1 + "  " + stext [Pp1]);

				//print ("!!!: " + stext.Substring (Pp3-1,Pp1-Pp3+1));

				if ((TheSame_L == -1) | (TheSameR == false)) 
				{ // Если таких скобок нет
					//if (MakeBracketL == true) // Левая новая скобка
					{
						//print ("321: " + Pp3 + "  " + stext [Pp3]
						//	+" 525: " + Pp1 + "  " + stext [Pp1]);

						stext = stext.Insert (Pp3, "(");
						sVariable = sVariable.Insert (Pp3, "[");

						// +1 к позициям в массивах (для позиций >= чем "Pp3") ↓↓↓ ///////////////////////////////////////////////////////////////
						if (CountOfCommas1 > 0) {
							for (int i = 0; i <= CountOfCommas1 - 1; i++) {
								if (CommasInText [i, 0] >= Pp3)
									CommasInText [i, 0] = CommasInText [i, 0]+1; // 0-позиция запятых
							}
						}
						if (CountOfSymbols1 > 0) {
							for (int i = 0; i <= CountOfSymbols1 - 1; i++) {	
								if (AllSymbols1 [i, 0] >= Pp3)
									AllSymbols1 [i, 0] = AllSymbols1 [i, 0] + 1;
							}
						}
						if (CountOfVariables1 > 0) {
							for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
								if (AllVariables1 [i, 0] >= Pp3) {
									AllVariables1 [i, 0] = AllVariables1 [i, 0] + 1;
									//if (AllVariables1 [i, 1] >= Pp3)
									AllVariables1 [i, 1] = AllVariables1 [i, 1] + 1;					
								}
							}
						}
						if (CountOfNumbers1 > 0) {
							for (int i = 0; i <= CountOfNumbers1 - 1; i++) {	
								if (AllNumbers1 [i, 0] >= Pp3) {
									AllNumbers1 [i, 0] = AllNumbers1 [i, 0] + 1;
									//	if (AllNumbers1 [i, 1] >= Pp3)
									AllNumbers1 [i, 1] = AllNumbers1 [i, 1] + 1;					
									//print ("555: " +i+"  "+ AllNumbers1 [i, 0] 
									//	+ "  " + AllNumbers1 [i, 1]);
								}
							}
						}
						if (CountBracket2_4 > 0) {
							for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
								if (BracketStep2 [i, 0] >= Pp3)
									BracketStep2 [i, 0] = BracketStep2 [i, 0] + 1;
								if (BracketStep2 [i, 1] >= Pp3)
									BracketStep2 [i, 1] = BracketStep2 [i, 1] + 1;					
							}		
						}			
						// +1 к позициям в массивах (для позиций больше чем "Pp3") ↑↑↑ ///////////////////////////////////////////////////////////////

						BracketStep2 [CountBracket2_4 - 1, 0] = Pp3; // Позиция левой скобки

						//MakeBracketL = false;
					}

					//if (MakeBracketR == true) // Правая новая скобка
					{
						Pp1 = Pp1 + 1;
						Pp3 = Pp1;
						stext = stext.Insert (Pp1, ")");
						sVariable = sVariable.Insert (Pp1, "]");
						//print ("123: " + Pp1 + "  " + s [Pp1]);

						// +1 к позициям в массивах (для позиций >= чем "Pp1") ↓↓↓ ///////////////////////////////////////////////////////////////
						if (CountOfCommas1 > 0) {
							for (int i = 0; i <= CountOfCommas1 - 1; i++) {
								if (CommasInText [i, 0] >= Pp1)
									CommasInText [i, 0] = CommasInText [i, 0]+1; // 0-позиция запятых
							}
						}
						if (CountOfSymbols1 > 0) {
							for (int i = 0; i <= CountOfSymbols1 - 1; i++) {	
								if (AllSymbols1 [i, 0] >= Pp1)
									AllSymbols1 [i, 0] = AllSymbols1 [i, 0] + 1;
							}
						}
						if (CountOfVariables1 > 0) {
							for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
								if (AllVariables1 [i, 0] >= Pp1) {
									AllVariables1 [i, 0] = AllVariables1 [i, 0] + 1;
									//if (AllVariables1 [i, 1] >= Pp1)
									AllVariables1 [i, 1] = AllVariables1 [i, 1] + 1;					
								}
							}
						}
						if (CountOfNumbers1 > 0) {
							for (int i = 0; i <= CountOfNumbers1 - 1; i++) {	
								if (AllNumbers1 [i, 0] >= Pp1) {
									AllNumbers1 [i, 0] = AllNumbers1 [i, 0] + 1;
									//	if (AllNumbers1 [i, 1] >= Pp1)
									AllNumbers1 [i, 1] = AllNumbers1 [i, 1] + 1;					
									//print ("555: " +i+"  "+ AllNumbers1 [i, 0] 
									//	+ "  " + AllNumbers1 [i, 1]);
								}
							}
						}
						if (CountBracket2_4 > 0) {
							for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
								if (BracketStep2 [i, 0] >= Pp1)
									BracketStep2 [i, 0] = BracketStep2 [i, 0] + 1;
								if (BracketStep2 [i, 1] >= Pp1)
									BracketStep2 [i, 1] = BracketStep2 [i, 1] + 1;					
							}		
						}
						// +1 к позициям в массивах (для позиций больше чем "Pp1") ↑↑↑ ///////////////////////////////////////////////////////////////

						BracketStep2 [CountBracket2_4 - 1, 1] = Pp1; // Позиция правой скобки
						BracketStep2 [CountBracket2_4 - 1, 2] = 4; // Тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные)
						BracketStep2 [CountBracket2_4 - 1, 5] = -1; // Порядковый номер знака в массиве "AllSymbols1"
						BracketStep2 [CountBracket2_4 - 1, 6] = -1; // -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой													
					}

					if (TheSame_L > -1) { // Если перед скобкой
						BracketStep2 [CountBracket2_4 - 1, 10] = BracketStep2 [TheSame_L, 10]; // 10-первоначальная левая позиция скобки

						//print (BracketStep2 [TheSame_L, 5] + " ! " + BracketStep2 [TheSame_L, 6]);
						//print (stext.Substring (BracketStep2 [TheSame_L, 0],
						//	BracketStep2 [TheSame_L, 1] - BracketStep2 [TheSame_L, 0] + 5));
						// Установить знак предыдущей скобки к новой
						BracketStep2 [CountBracket2_4 - 1, 5] = BracketStep2 [TheSame_L, 5]; // Порядковый номер знака в массиве "AllSymbols1"
						BracketStep2 [CountBracket2_4 - 1, 6] = BracketStep2 [TheSame_L, 6]; // -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой
						// Убрать знак предыдущей скобки
						BracketStep2 [TheSame_L, 5] = -1; // Порядковый номер знака в массиве "AllSymbols1"
						BracketStep2 [TheSame_L, 6] = -1; // -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой					
					} else if (TheSameN_L > -1) { // Если перед числом
						BracketStep2 [CountBracket2_4 - 1, 10] = AllNumbers1 [TheSameN_L, 4]; // 4-первоначальная левая позиция числа

						if (AllNumbers1 [TheSameN_L, 3] < -1) { // Если обычный знак "+","-"
							// Установить знак предыдущего числа к новой скобке	
							BracketStep2 [CountBracket2_4 - 1, 5] = AllNumbers1 [TheSameN_L, 2]; // Порядковый номер знака в массиве "AllSymbols1"
							BracketStep2 [CountBracket2_4 - 1, 6] = AllNumbers1 [TheSameN_L, 3]; //  -3=обычный знак "-" перед числом, -2=обычный знак "+" перед числом, -1=нет меняющего знака перед числом, 0=плюс перед числом, 1=минус перед числом
							// Убрать знак предыдущего числа
							AllNumbers1 [TheSameN_L, 2] = -1; // Порядковый номер знака в массиве "AllSymbols1"
							AllNumbers1 [TheSameN_L, 3] = -1; //  -3=обычный знак "-" перед числом, -2=обычный знак "+" перед числом, -1=нет меняющего знака перед числом, 0=плюс перед числом, 1=минус перед числом						
						}
					} else if (TheSameV_L > -1) { // Если перед переменной
						BracketStep2 [CountBracket2_4 - 1, 10] = AllVariables1 [TheSameV_L, 6]; // 6-первоначальная позиция левой переменной

						if (AllVariables1 [TheSameV_L, 4] < -1) { // Если обычный знак "+","-"							
							// Установить знак предыдущей переменной к новой скобке	
							BracketStep2 [CountBracket2_4 - 1, 5] = AllVariables1 [TheSameV_L, 3]; // Порядковый номер знака в массиве "AllSymbols1"
							BracketStep2 [CountBracket2_4 - 1, 6] = AllVariables1 [TheSameV_L, 4]; //  -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной
							// Убрать знак предыдущей переменной
							AllVariables1 [TheSameV_L, 3] = -1; // Порядковый номер знака в массиве "AllSymbols1"
							AllVariables1 [TheSameV_L, 4] = -1; //  -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной
						}
					}
					if (TheSameS_L > -1) { // Если перед знаком
						BracketStep2 [CountBracket2_4 - 1, 10] = AllSymbols1 [TheSameS_L, 3]; // 3-первоначальная позиция знака
					}

					if (TheSame_R > -1) { // Если после скобки
						BracketStep2 [CountBracket2_4 - 1, 11] = BracketStep2 [TheSame_R, 11]; // 11-первоначальная правая позиция скобки
					} else if (TheSameN_R > -1) { // Если после числа
						BracketStep2 [CountBracket2_4 - 1, 11] = AllNumbers1 [TheSameN_R, 5]; // 5-первоначальная правая позиция числа
					} else if (TheSameV_R > -1) { // Если после переменной
						BracketStep2 [CountBracket2_4 - 1, 11] = AllVariables1 [TheSameV_R, 7]; // 7-первоначальная позиция правой переменной
					}

					//if ((BracketStep2 [CountBracket2_4 - 1, 10] > -1) &
					//	(BracketStep2 [CountBracket2_4 - 1, 11] > -1)) {
					//	print ("2???: " + s1.Substring (BracketStep2 [CountBracket2_4 - 1, 10] - 1, 
					//		BracketStep2 [CountBracket2_4 - 1, 11] 
					//		- BracketStep2 [CountBracket2_4 - 1, 10] + 1));
					//}

					CountBracket2_4 = CountBracket2_4 + 1;	
					CountAddBracket = CountAddBracket + 1; // кол-во добавленных пар скобок
				}
				TheSameN_L = -1; // >-1 Если скобка перед числом
				TheSameV_L = -1; // >-1 Если скобка перед переменной
				TheSame_L = -1; // >-1 -такая левая скобка уже есть
				TheSameS_L = -1; // >-1 Если скобка перед знаком
				TheSameN_R = -1; // >-1 Если скобка после числа
				TheSameV_R = -1; // >-1 Если скобка после переменной
				TheSame_R = -1; // >-1 -такая правая скобка уже есть

				MakeBracketL = false;
				MakeBracketR = false;
				Pp1 = Pp1_2;
			}
		}

	}
	Pp1 = Pp1 + 1;		
	//print (Pp1+" ABC ");
}

//s_c = stext.ToCharArray();
//sVariable_c = sVariable.ToCharArray();

//print (stext);
//print (sVariable);

// Расставить дополнительные скобки, слева и справа от знака ",", поменять в доп. строке на "[","]" /////////////////////////////////////////
Pp0 = 0;
Pp1 = 0;
Pp2 = 0;
Pp3 = -1;
NextStep1 = false;
MakeBracketR = false;
MakeBracketL = false;
int TheSame_Main = -1; // в каких скобках
int TheSame_L2 = -1;
int TheSame_R2 = -1;
int TheSame_C = 0;
TheSame_L = -1;
TheSameN_L = -1;
TheSameV_L = -1;
TheSameS_L = -1;
TheSame_R = -1;
TheSameN_R = -1;
TheSameV_R = -1;
//bool MakeBracketR2 = false;
bool MakeBracketL2 = false;
while (Pp1 <= stext.Length - 1) {
	if (sVariable [Pp1] != Symbols2 [0]) { // Если не пробел
		//print (s [Pp1]+"  "+sVariable [Pp1]);
		if ((sVariable [Pp1] == Symbols [5])) { // Если ","
			//print (s [Pp1] + " ! " + sVariable [Pp1]);
			for (int i = TheSame_C; i <= CountOfCommas1 - 1; i++) {
				if (CommasInText [i, 0] == Pp1) {
					TheSame_C = i; // Номер запятой от которой ведется отсчет
					break;
				}
			}

			Pp0 = Pp1;
			// Искать влево ↓↓↓ ///////////////////////////////////////////////////////////////
			if (MakeBracketL2 == false) {
				if (Pp1 - 1 >= 0) {
					Pp2 = Pp1 - 1;
					while (Pp2 >= 0) {
						//print ("222: " + s [Pp2] + " = " + sVariable [Pp2] + " = " + Pp2);
						if (sVariable [Pp2] != Symbols2 [0]) { // Если не пробел
							//print ("222: " + s [Pp2] + " + " + sVariable [Pp2]);
							if ((sVariable [Pp2] == Bracket_R [0]) |
								(sVariable [Pp2] == Bracket_R [2])) { // Если любая закрывающаяся скобка
								NextStep1 = true;
								//MakeBracketL = true;
								for (int k = 0; k <= CountBracket2_4 - 1; k++) {
									if (BracketStep2 [k, 1] == Pp2) { // Найти правую скобку в массиве "BracketStep2" по позиции
										if (TheSame_L2 == k) { // Если левая позиция уже была найдена
											NextStep1 = false;
											break;
										}
										TheSameN_L = -1; // >-1 Если скобка перед числом
										TheSameV_L = -1; // >-1 Если скобка перед переменной
										TheSame_L = k; // >-1 -такая левая скобка уже есть
										TheSameS_L = -1; // >-1 Если скобка перед знаком
										TheSame_L2 = k; // >-1 -такая левая скобка уже есть
										Pp3 = BracketStep2 [k, 0]; // Указать позицию вероятной новой скобки
										Pp2 = Pp3;
										break;
									}
								}
							} else if ((sVariable [Pp2] == "_".ToCharArray () [0]) |
								(sVariable [Pp2] == Symbols [0])) { // Если "+" или "-" (обычный знак или меняющий результат, перед скобкой, переменной или числом)														
								for (int k = 0; k <= CountOfSymbols1 - 1; k++) {	
									if (AllSymbols1 [k, 0] == Pp2) {
										TheSameS_L = k; // >-1 Если скобка перед знаком
										break;
									}
								}
								NextStep1 = true;
								//MakeBracketL = true;
								//Pp3 = Pp2; // Указать позицию вероятной новой скобки
							} else if (sVariable [Pp2] == Symbols2 [3]) { // Если "." переменная																		
								NextStep1 = true;
								//MakeBracketL = true;
								for (int k = 0; k <= CountOfVariables1 - 1; k++) { // Найти переменную по позиции в массиве "AllVariables1"
									if (AllVariables1 [k, 1] == Pp2) {
										TheSameN_L = -1; // >-1 Если скобка перед числом
										TheSameV_L = k; // >-1 Если скобка перед переменной
										TheSame_L = -1; // >-1 -такая левая скобка уже есть
										TheSameS_L = -1; // >-1 Если скобка перед знаком
										Pp3 = AllVariables1 [k, 0]; // Указать позицию вероятной новой скобки
										Pp2 = Pp3;
										break;
									}
								}
							} else if (sVariable [Pp2] == Symbols2 [4]) { // Если "№" число														
								NextStep1 = true;
								//MakeBracketL = true;
								for (int k = 0; k <= CountOfNumbers1 - 1; k++) { // Найти число по позиции в массиве "AllNumbers1"
									if (AllNumbers1 [k, 1] == Pp2) {
										TheSameN_L = k; // >-1 Если скобка перед числом
										TheSameV_L = -1; // >-1 Если скобка перед переменной
										TheSame_L = -1; // >-1 -такая левая скобка уже есть
										TheSameS_L = -1; // >-1 Если скобка перед знаком
										//print ("222: "+s [Pp2] + " -+- " + sVariable [Pp2]);
										Pp3 = AllNumbers1 [k, 0]; // Указать позицию вероятной новой скобки
										Pp2 = Pp3;
										break;
									}
								}
							}
							else if ((sVariable [Pp2] == Bracket_L [0]) |
								(sVariable [Pp2] == Bracket_L [2])) { // Если любая открывающаяся скобка
								//NextStep1 = true;
								MakeBracketL = true;
								MakeBracketL2 = true;
								for (int k = 0; k <= CountBracket2_4 - 1; k++) {
									if (BracketStep2 [k, 0] == Pp2) { // Найти левую скобку в массиве "BracketStep2" по позиции
										//TheSameN_L = -1; // >-1 Если скобка перед числом
										//TheSameV_L = -1; // >-1 Если скобка перед переменной
										TheSame_Main = k; // >-1 -такая левая скобка уже есть
										Pp3 = Pp2+1; // Указать позицию вероятной новой скобки
										Pp2 = Pp3;
										//print (stext [Pp2] + " 1= " + sVariable [Pp2]);
										break;
									}
								}
							}
							//else if (sVariable [Pp2] == Symbols [5]) { // Если "," запятая														
							//NextStep1 = true;
							//MakeBracketL = true;
							//Pp3 = Pp2+1; // Указать позицию вероятной новой скобки
							//for (int k = 0; k <= CountOfNumbers1 - 1; k++) { // Найти символ по позиции в массиве "AllSymbols1"
							//if (AllSymbols1 [k, 0] == Pp2) {
							//print ("222: "+s [Pp2] + " -+- " + sVariable [Pp2]);
							//TheSameN_L = k; // >-1 Если скобка перед числом
							//TheSameV_L = -1; // >-1 Если скобка перед переменной
							//TheSame_L = -1; // >-1 -такая левая скобка уже есть
							//Pp3 = AllSymbols1 [k, 0]; // Указать позицию вероятной новой скобки
							//Pp2 = Pp3;
							//break;
							//}
							//}
							//}

							if (NextStep1 == true) {
								NextStep1 = false;
								//print ("222: "+s [Pp2] + " = " + sVariable [Pp2]);
							} else {
								break;
							}
						}
						Pp2 = Pp2 - 1;
					}
				}					
			}
			// Искать влево ↑↑↑ ///////////////////////////////////////////////////////////////

			// Искать вправо ↓↓↓ ///////////////////////////////////////////////////////////////
			if (Pp1 + 1 <= stext.Length - 1) {
				Pp2 = Pp1 + 1;
				while (Pp2 <= stext.Length - 1) {
					//print (s [Pp2] + " = " + sVariable [Pp2] + " = " + Pp2);
					if (sVariable [Pp2] != Symbols2 [0]) { // Если не пробел
						//print (s [Pp2] + " + " + sVariable [Pp2]);
						if ((sVariable [Pp2] == Bracket_L [0]) |
							(sVariable [Pp2] == Bracket_L [2])) { // Если любая открывающаяся скобка
							NextStep1 = true;	
							//MakeBracketR = true;
							for (int k = 0; k <= CountBracket2_4 - 1; k++) {
								if (BracketStep2 [k, 0] == Pp2) { // Найти левую скобку в массиве "BracketStep2" по позиции
									TheSameN_R = -1; // >-1 Если скобка после числа
									TheSameV_R = -1; // >-1 Если скобка после переменной
									TheSame_R = k; // >-1 -такая правая скобка уже есть
									TheSame_R2 = k; // >-1 -такая правая скобка уже есть
									Pp1 = BracketStep2 [k, 1]; // Указать позицию вероятной новой скобки
									Pp2 = Pp1; // Сместить поиск вправо
									//print (stext [Pp1] + " !2= " + sVariable [Pp1]);
									//MakeBracketR = true;
									break;
								}
							}
						} else if ((sVariable [Pp2] == "_".ToCharArray () [0]) |
							(sVariable [Pp2] == Symbols [0])) { // Если "+" или "-" (обычный знак или меняющий результат, перед скобкой, переменной или числом)															
							NextStep1 = true;	
							//MakeBracketR = false;
						} else if (sVariable [Pp2] == Symbols2 [3]) { // Если "." переменная																		
							NextStep1 = true;	
							//MakeBracketR = true;
							for (int k = 0; k <= CountOfVariables1 - 1; k++) { // Найти переменную по позиции в массиве "AllVariables1"
								if (AllVariables1 [k, 0] == Pp2) {
									if (AllVariables1 [k, 2] > -1) { // Если у переменной есть скобки												
										TheSameN_R = -1; // >-1 Если скобка после числа
										TheSameV_R = -1; // >-1 Если скобка после переменной
										TheSame_R = AllVariables1 [k, 2]; // >-1 -такая правая скобка уже есть
										Pp1 = BracketStep2 [AllVariables1 [k, 2], 1]; // Указать позицию вероятной новой скобки
									} else { // Если у переменной нет скобок
										TheSameN_R = -1; // >-1 Если скобка после числа
										TheSameV_R = k; // >-1 Если скобка после переменной
										TheSame_R = -1; // >-1 -такая правая скобка уже есть
										Pp1 = AllVariables1 [k, 1]; // Указать позицию вероятной новой скобки
									}
									Pp2 = Pp1; // Сместить поиск вправо
									//MakeBracketR = true;
									break;
								}
							}
						} else if (sVariable [Pp2] == Symbols2 [4]) { // Если "№" число	
							NextStep1 = true;	
							//MakeBracketR = true;
							for (int k = 0; k <= CountOfNumbers1 - 1; k++) { // Найти число по позиции в массиве "AllNumbers1"
								if (AllNumbers1 [k, 0] == Pp2) {
									TheSameN_R = k; // >-1 Если скобка после числа
									TheSameV_R = -1; // >-1 Если скобка после переменной
									TheSame_R = -1; // >-1 -такая правая скобка уже есть
									//print (s [Pp2] + " -+- " + sVariable [Pp2]);
									Pp1 = AllNumbers1 [k, 1]; // Указать позицию вероятной новой скобки
									Pp2 = Pp1; // Сместить поиск вправо
									//MakeBracketR = true;
									break;
								}
							}
						}
						else if ((sVariable [Pp2] == Bracket_R [0]) |
							(sVariable [Pp2] == Bracket_R [2])) { // Если любая закрывающаяся скобка
							//NextStep1 = true;
							MakeBracketR = true;
							for (int k = 0; k <= CountBracket2_4 - 1; k++) {
								if (BracketStep2 [k, 1] == Pp2) { // Найти правую скобку в массиве "BracketStep2" по позиции
									//TheSameN_L = -1; // >-1 Если скобка перед числом
									//TheSameV_L = -1; // >-1 Если скобка перед переменной
									MakeBracketL2 = false;
									Pp1 = Pp2-1; // Указать позицию вероятной новой скобки
									//print (stext [Pp1] + " 2= " + sVariable [Pp1]);
									//Pp2 = Pp3;
									break;
								}
							}
						} else if (sVariable [Pp2] == Symbols [5]) { // Если "," запятая	
							//NextStep1 = true;	
							MakeBracketR = true;
							Pp1 = Pp2-1;
							//print (stext [Pp1] + " 7872= " + sVariable [Pp1]);
							//for (int k = 0; k <= CountOfNumbers1 - 1; k++) { // Найти символ по позиции в массиве "AllSymbols1"
							//if (AllSymbols1 [k, 0] == Pp2) {
							//print (s [Pp2] + " -+- " + sVariable [Pp2]);
							//TheSameN_L = k; // >-1 Если скобка перед числом
							//TheSameV_L = -1; // >-1 Если скобка перед переменной
							//TheSame_L = -1; // >-1 -такая левая скобка уже есть
							//Pp1 = AllSymbols1 [k, 0]; // Указать позицию вероятной новой скобки
							//MakeBracketR = true;
							//break;
							//}
							//}
						}

						//NextStep1 = true;	
						//MakeBracketR = true;

						if (NextStep1 == true) {
							NextStep1 = false;
							//print (stext [Pp1] + " = " + sVariable [Pp1]);
						} else {
							break;
						}
					}
					Pp2 = Pp2 + 1;
				}
			}
			// Искать вправо ↑↑↑ ///////////////////////////////////////////////////////////////

			if (MakeBracketL == true) { 

				TheSameR = false; // true-такая правая скобка уже есть
				if (TheSame_L2 > -1) { // Если перед скобкой
					// Проверить существование таких же скобок
					//for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
					// Если левая скобка заменяет другую левую скобку "i"
					//	if (BracketStep2 [i, 0] == Pp3) {
					//		TheSame_L = i; // >-1 -такая левая скобка уже есть
					// Если правая скобка заменяет другую правую скобку "i"
					if ((BracketStep2 [TheSame_L2, 0] == Pp3) & 
						(BracketStep2 [TheSame_L2, 1] == Pp0-1)) {
						TheSameR = true; // true-такая правая скобка уже есть
					}
					//		break;
					//	}				
					//}	
				}

				//print (stext [Pp3] + " 3= " + stext [Pp0-1]);

				if ((TheSame_L2 == -1) | (TheSameR == false)) { // Если таких скобок нет
					//print (stext [Pp3] + " 4= " + stext [Pp0-1]);

					//print ("321: " + stext.Substring(Pp3,Pp0-Pp3));

					//if (MakeBracketL == true) // Левая новая скобка
					{
						stext = stext.Insert (Pp3, "(");
						sVariable = sVariable.Insert (Pp3, "[");
						//print ("321: " + Pp3 + "  " + s [Pp3]);
						Pp1 = Pp1 + 1; // т.к. запятая смещена еще на один символ вправо

						// +1 к позициям в массивах (для позиций >= чем "Pp3") ↓↓↓ ///////////////////////////////////////////////////////////////
						if (CountOfCommas1 > 0) {
							for (int i = 0; i <= CountOfCommas1 - 1; i++) {
								if (CommasInText [i, 0] >= Pp3)
									CommasInText [i, 0] = CommasInText [i, 0]+1; // 0-позиция запятых
							}
						}
						if (CountOfSymbols1 > 0) {
							for (int i = 0; i <= CountOfSymbols1 - 1; i++) {	
								if (AllSymbols1 [i, 0] >= Pp3)
									AllSymbols1 [i, 0] = AllSymbols1 [i, 0] + 1;
							}
						}
						if (CountOfVariables1 > 0) {
							for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
								if (AllVariables1 [i, 0] >= Pp3) {
									AllVariables1 [i, 0] = AllVariables1 [i, 0] + 1;
									//if (AllVariables1 [i, 1] >= Pp3)
									AllVariables1 [i, 1] = AllVariables1 [i, 1] + 1;					
								}
							}
						}
						if (CountOfNumbers1 > 0) {
							for (int i = 0; i <= CountOfNumbers1 - 1; i++) {	
								if (AllNumbers1 [i, 0] >= Pp3) {
									AllNumbers1 [i, 0] = AllNumbers1 [i, 0] + 1;
									//	if (AllNumbers1 [i, 1] >= Pp3)
									AllNumbers1 [i, 1] = AllNumbers1 [i, 1] + 1;					
									//print ("555: " +i+"  "+ AllNumbers1 [i, 0] 
									//	+ "  " + AllNumbers1 [i, 1]);
								}
							}
						}
						if (CountBracket2_4 > 0) {
							for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
								if (BracketStep2 [i, 0] >= Pp3)
									BracketStep2 [i, 0] = BracketStep2 [i, 0] + 1;
								if (BracketStep2 [i, 1] >= Pp3)
									BracketStep2 [i, 1] = BracketStep2 [i, 1] + 1;					
							}		
						}	
						// +1 к позициям в массивах (для позиций больше чем "Pp3") ↑↑↑ ///////////////////////////////////////////////////////////////

						BracketStep2 [CountBracket2_4 - 1, 0] = Pp3; // Позиция левой скобки

						//MakeBracketL = false;
					}						

					//if (MakeBracketR == true) // Правая новая скобка
					{
						Pp0 = Pp0 + 1;
						Pp3 = Pp0;
						stext = stext.Insert (Pp3, ")");
						sVariable = sVariable.Insert (Pp3, "]");
						//print ("123: " + Pp3 + "  " + s [Pp3]);
						Pp0 = Pp0 + 1; // т.к. запятая смещена еще на один символ вправо
						Pp1 = Pp1 + 1; // т.к. запятая смещена еще на один символ вправо

						// +1 к позициям в массивах (для позиций >= чем "Pp3") ↓↓↓ ///////////////////////////////////////////////////////////////
						if (CountOfCommas1 > 0) {
							for (int i = 0; i <= CountOfCommas1 - 1; i++) {
								if (CommasInText [i, 0] >= Pp3)
									CommasInText [i, 0] = CommasInText [i, 0]+1; // 0-позиция запятых
							}
						}
						if (CountOfSymbols1 > 0) {
							for (int i = 0; i <= CountOfSymbols1 - 1; i++) {	
								if (AllSymbols1 [i, 0] >= Pp3)
									AllSymbols1 [i, 0] = AllSymbols1 [i, 0] + 1;
							}
						}
						if (CountOfVariables1 > 0) {
							for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
								if (AllVariables1 [i, 0] >= Pp3) {
									AllVariables1 [i, 0] = AllVariables1 [i, 0] + 1;
									//if (AllVariables1 [i, 1] >= Pp3)
									AllVariables1 [i, 1] = AllVariables1 [i, 1] + 1;					
								}
							}
						}
						if (CountOfNumbers1 > 0) {
							for (int i = 0; i <= CountOfNumbers1 - 1; i++) {	
								if (AllNumbers1 [i, 0] >= Pp3) {
									AllNumbers1 [i, 0] = AllNumbers1 [i, 0] + 1;
									//	if (AllNumbers1 [i, 1] >= Pp3)
									AllNumbers1 [i, 1] = AllNumbers1 [i, 1] + 1;					
									//print ("555: " +i+"  "+ AllNumbers1 [i, 0] 
									//	+ "  " + AllNumbers1 [i, 1]);
								}
							}
						}
						if (CountBracket2_4 > 0) {
							for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
								if (BracketStep2 [i, 0] >= Pp3)
									BracketStep2 [i, 0] = BracketStep2 [i, 0] + 1;
								if (BracketStep2 [i, 1] >= Pp3)
									BracketStep2 [i, 1] = BracketStep2 [i, 1] + 1;					
							}		
						}
						// +1 к позициям в массивах (для позиций больше чем "Pp3") ↑↑↑ ///////////////////////////////////////////////////////////////

						BracketStep2 [CountBracket2_4 - 1, 1] = Pp3; // Позиция правой скобки
						BracketStep2 [CountBracket2_4 - 1, 2] = 4; // Тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные)
						BracketStep2 [CountBracket2_4 - 1, 5] = -1; // Порядковый номер знака в массиве "AllSymbols1"
						BracketStep2 [CountBracket2_4 - 1, 6] = -1; // -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой													
						BracketStep2 [CountBracket2_4 - 1, 9] = TheSame_Main; // к какой скобке относится эта часть (-1=не связано с запятыми)
					}

					/*if (TheSame_L > -1) { // Если перед скобкой
						print (BracketStep2 [TheSame_L, 5] + " ! " + BracketStep2 [TheSame_L, 6]);
						print (stext.Substring (BracketStep2 [TheSame_L, 0],
							BracketStep2 [TheSame_L, 1] - BracketStep2 [TheSame_L, 0] + 5));
						// Установить знак предыдущей скобки к новой
						BracketStep2 [CountBracket2_4 - 1, 5] = BracketStep2 [TheSame_L, 5]; // Порядковый номер знака в массиве "AllSymbols1"
						BracketStep2 [CountBracket2_4 - 1, 6] = BracketStep2 [TheSame_L, 6]; // -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой
						// Убрать знак предыдущей скобки
						BracketStep2 [TheSame_L, 5] = -1; // Порядковый номер знака в массиве "AllSymbols1"
						BracketStep2 [TheSame_L, 6] = -1; // -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой					
					} else if (TheSameN_L > -1) { // Если перед числом
						if (AllNumbers1 [TheSameN_L, 3] < -1) { // Если обычный знак "+","-"
							// Установить знак предыдущего числа к новой скобке	
							BracketStep2 [CountBracket2_4 - 1, 5] = AllNumbers1 [TheSameN_L, 2]; // Порядковый номер знака в массиве "AllSymbols1"
							BracketStep2 [CountBracket2_4 - 1, 6] = AllNumbers1 [TheSameN_L, 3]; //  -3=обычный знак "-" перед числом, -2=обычный знак "+" перед числом, -1=нет меняющего знака перед числом, 0=плюс перед числом, 1=минус перед числом
							// Убрать знак предыдущего числа
							AllNumbers1 [TheSameN_L, 2] = -1; // Порядковый номер знака в массиве "AllSymbols1"
							AllNumbers1 [TheSameN_L, 3] = -1; //  -3=обычный знак "-" перед числом, -2=обычный знак "+" перед числом, -1=нет меняющего знака перед числом, 0=плюс перед числом, 1=минус перед числом						
						}
					} else if (TheSameV_L > -1) { // Если перед переменной
						if (AllVariables1 [TheSameV_L, 4] < -1) { // Если обычный знак "+","-"
							// Установить знак предыдущей переменной к новой скобке	
							BracketStep2 [CountBracket2_4 - 1, 5] = AllVariables1 [TheSameV_L, 3]; // Порядковый номер знака в массиве "AllSymbols1"
							BracketStep2 [CountBracket2_4 - 1, 6] = AllVariables1 [TheSameV_L, 4]; //  -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной
							// Убрать знак предыдущей переменной
							AllVariables1 [TheSameV_L, 3] = -1; // Порядковый номер знака в массиве "AllSymbols1"
							AllVariables1 [TheSameV_L, 4] = -1; //  -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной
						}
					}*/

					if (TheSame_L > -1) { // Если перед скобкой
						BracketStep2 [CountBracket2_4 - 1, 10] = BracketStep2 [TheSame_L, 10]; // 10-первоначальная левая позиция скобки
					} else if (TheSameN_L > -1) { // Если перед числом
						BracketStep2 [CountBracket2_4 - 1, 10] = AllNumbers1 [TheSameN_L, 4]; // 4-первоначальная левая позиция переменной
					} else if (TheSameV_L > -1) { // Если перед переменной
						BracketStep2 [CountBracket2_4 - 1, 10] = AllVariables1 [TheSameV_L, 6]; // 6-первоначальная позиция левой переменной
					}
					if (TheSameS_L > -1) { // Если перед знаком
						BracketStep2 [CountBracket2_4 - 1, 10] = AllSymbols1 [TheSameS_L, 3]; // 3-первоначальная позиция знака
					}
					if (TheSame_C > -1) { // Если найден номер запятой
						BracketStep2 [CountBracket2_4 - 1, 11] = CommasInText [TheSame_C, 1]-1; // 1-первоначальная позиция запятой
					}

					//if ((BracketStep2 [CountBracket2_4 - 1, 10] > -1) &
					//	(BracketStep2 [CountBracket2_4 - 1, 11] > -1)) {
					//	print ("3???: " + s1.Substring (BracketStep2 [CountBracket2_4 - 1, 10] - 1, 
					//		BracketStep2 [CountBracket2_4 - 1, 11]
					//		- BracketStep2 [CountBracket2_4 - 1, 10] + 1));
					//}

					CountBracket2_4 = CountBracket2_4 + 1;	
					CountAddBracket = CountAddBracket + 1; // кол-во добавленных пар скобок
				}
				//TheSame_L3 = TheSame_L2;
				TheSameN_L = -1; // >-1 Если скобка перед числом
				TheSameV_L = -1; // >-1 Если скобка перед переменной
				TheSame_L = -1; // >-1 -такая левая скобка уже есть
				TheSameS_L = -1; // >-1 Если скобка перед знаком
				TheSame_L2 = -1; // >-1 -такая левая скобка уже есть
				MakeBracketL = false;
				//MakeBracketR = false;
				//MakeBracketL2 = false;
				//MakeBracketR2 = false;
			}

			if (MakeBracketR == true) { 
				//Pp3 = Pp1;

				BracketStep2 [TheSame_Main, 8] = BracketStep2 [TheSame_Main, 8]+1; // кол-во запятых внутри выбранных скобок

				TheSameR = false; // true-такая правая скобка уже есть
				if (TheSame_R2 > -1) { // Если перед скобкой
					// Проверить существование таких же скобок
					//for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
					// Если левая скобка заменяет другую левую скобку "i"
					//	if (BracketStep2 [i, 0] == Pp3) {
					//		TheSame_R = i; // >-1 -такая левая скобка уже есть
					// Если правая скобка заменяет другую правую скобку "i"
					if ((BracketStep2 [TheSame_R2, 0] == Pp0+1) & 
						(BracketStep2 [TheSame_R2, 1] == Pp1)) {
						TheSameR = true; // true-такая правая скобка уже есть
					}
					//		break;
					//	}				
					//}	
				}

				//print (stext [Pp0+1] + " 5= " + stext [Pp1]);

				if ((TheSame_R2 == -1) | (TheSameR == false)) { // Если таких скобок нет
					//print (stext [Pp0+1] + " 6= " + stext [Pp1]);

					//print ("123: " + stext.Substring(Pp0+1,Pp1-Pp0));

					//if (MakeBracketL == true) // Левая новая скобка
					{
						Pp1 = Pp1 + 1; // т.к. запятая смещена еще на один символ вправо
						Pp3 = Pp0+1;
						stext = stext.Insert (Pp3, "(");
						sVariable = sVariable.Insert (Pp3, "[");
						//print ("321: " + Pp3 + "  " + s [Pp3]);

						// +1 к позициям в массивах (для позиций >= чем "Pp3") ↓↓↓ ///////////////////////////////////////////////////////////////
						if (CountOfCommas1 > 0) {
							for (int i = 0; i <= CountOfCommas1 - 1; i++) {
								if (CommasInText [i, 0] >= Pp3)
									CommasInText [i, 0] = CommasInText [i, 0]+1; // 0-позиция запятых
							}
						}
						if (CountOfSymbols1 > 0) {
							for (int i = 0; i <= CountOfSymbols1 - 1; i++) {	
								if (AllSymbols1 [i, 0] >= Pp3)
									AllSymbols1 [i, 0] = AllSymbols1 [i, 0] + 1;
							}
						}
						if (CountOfVariables1 > 0) {
							for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
								if (AllVariables1 [i, 0] >= Pp3) {
									AllVariables1 [i, 0] = AllVariables1 [i, 0] + 1;
									//if (AllVariables1 [i, 1] >= Pp3)
									AllVariables1 [i, 1] = AllVariables1 [i, 1] + 1;					
								}
							}
						}
						if (CountOfNumbers1 > 0) {
							for (int i = 0; i <= CountOfNumbers1 - 1; i++) {	
								if (AllNumbers1 [i, 0] >= Pp3) {
									AllNumbers1 [i, 0] = AllNumbers1 [i, 0] + 1;
									//	if (AllNumbers1 [i, 1] >= Pp3)
									AllNumbers1 [i, 1] = AllNumbers1 [i, 1] + 1;					
									//print ("555: " +i+"  "+ AllNumbers1 [i, 0] 
									//	+ "  " + AllNumbers1 [i, 1]);
								}
							}
						}
						if (CountBracket2_4 > 0) {
							for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
								if (BracketStep2 [i, 0] >= Pp3)
									BracketStep2 [i, 0] = BracketStep2 [i, 0] + 1;
								if (BracketStep2 [i, 1] >= Pp3)
									BracketStep2 [i, 1] = BracketStep2 [i, 1] + 1;					
							}		
						}			
						// +1 к позициям в массивах (для позиций больше чем "Pp3") ↑↑↑ ///////////////////////////////////////////////////////////////

						BracketStep2 [CountBracket2_4 - 1, 0] = Pp3; // Позиция левой скобки

						//MakeBracketL = false;
					}

					//if (MakeBracketR == true) // Правая новая скобка
					{
						Pp1 = Pp1+1;
						Pp3 = Pp1;
						stext = stext.Insert (Pp3, ")");
						sVariable = sVariable.Insert (Pp3, "]");
						//print ("456: " + Pp3 + "  " + stext [Pp3]);

						// +1 к позициям в массивах (для позиций >= чем "Pp3") ↓↓↓ ///////////////////////////////////////////////////////////////
						if (CountOfCommas1 > 0) {
							for (int i = 0; i <= CountOfCommas1 - 1; i++) {
								if (CommasInText [i, 0] >= Pp3)
									CommasInText [i, 0] = CommasInText [i, 0]+1; // 0-позиция запятых
							}
						}
						if (CountOfSymbols1 > 0) {
							for (int i = 0; i <= CountOfSymbols1 - 1; i++) {	
								if (AllSymbols1 [i, 0] >= Pp3)
									AllSymbols1 [i, 0] = AllSymbols1 [i, 0] + 1;
							}
						}
						if (CountOfVariables1 > 0) {
							for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
								if (AllVariables1 [i, 0] >= Pp3) {
									AllVariables1 [i, 0] = AllVariables1 [i, 0] + 1;
									//if (AllVariables1 [i, 1] >= Pp3)
									AllVariables1 [i, 1] = AllVariables1 [i, 1] + 1;					
								}
							}
						}
						if (CountOfNumbers1 > 0) {
							for (int i = 0; i <= CountOfNumbers1 - 1; i++) {	
								if (AllNumbers1 [i, 0] >= Pp3) {
									AllNumbers1 [i, 0] = AllNumbers1 [i, 0] + 1;
									//	if (AllNumbers1 [i, 1] >= Pp3)
									AllNumbers1 [i, 1] = AllNumbers1 [i, 1] + 1;					
									//print ("555: " +i+"  "+ AllNumbers1 [i, 0] 
									//	+ "  " + AllNumbers1 [i, 1]);
								}
							}
						}
						if (CountBracket2_4 > 0) {
							for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
								if (BracketStep2 [i, 0] >= Pp3)
									BracketStep2 [i, 0] = BracketStep2 [i, 0] + 1;
								if (BracketStep2 [i, 1] >= Pp3)
									BracketStep2 [i, 1] = BracketStep2 [i, 1] + 1;					
							}		
						}
						// +1 к позициям в массивах (для позиций больше чем "Pp3") ↑↑↑ ///////////////////////////////////////////////////////////////

						BracketStep2 [CountBracket2_4 - 1, 1] = Pp3; // Позиция правой скобки
						BracketStep2 [CountBracket2_4 - 1, 2] = 4; // Тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные)
						BracketStep2 [CountBracket2_4 - 1, 5] = -1; // Порядковый номер знака в массиве "AllSymbols1"
						BracketStep2 [CountBracket2_4 - 1, 6] = -1; // -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой													
						BracketStep2 [CountBracket2_4 - 1, 9] = TheSame_Main; // к какой скобке относится эта часть (-1=не связано с запятыми)
					}

					if (TheSame_C > -1) { // Если найден номер запятой
						BracketStep2 [CountBracket2_4 - 1, 10] = CommasInText [TheSame_C, 1]+1; // 1-первоначальная позиция запятой
					}
					if (TheSame_R > -1) { // Если после скобки
						BracketStep2 [CountBracket2_4 - 1, 11] = BracketStep2 [TheSame_R, 11]; // 11-первоначальная правая позиция скобки
					} else if (TheSameN_R > -1) { // Если после числа
						BracketStep2 [CountBracket2_4 - 1, 11] = AllNumbers1 [TheSameN_R, 5]; // 5-первоначальная правая позиция переменной
					} else if (TheSameV_R > -1) { // Если после переменной
						BracketStep2 [CountBracket2_4 - 1, 11] = AllVariables1 [TheSameV_R, 7]; // 7-первоначальная правая позиция переменной
					}

					//if ((BracketStep2 [CountBracket2_4 - 1, 10] > -1) &
					//	(BracketStep2 [CountBracket2_4 - 1, 11] > -1)) {
					//	print ("3|2???: " + s1.Substring (BracketStep2 [CountBracket2_4 - 1, 10] - 1, 
					//		BracketStep2 [CountBracket2_4 - 1, 11]
					//		- BracketStep2 [CountBracket2_4 - 1, 10] + 1));
					//}

					CountBracket2_4 = CountBracket2_4 + 1;	
					CountAddBracket = CountAddBracket + 1; // кол-во добавленных пар скобок
				}
				//TheSame_L3 = TheSame_L2;
				TheSameN_R = -1; // >-1 Если скобка после числа
				TheSameV_R = -1; // >-1 Если скобка после переменной
				TheSame_R = -1; // >-1 -такая правая скобка уже есть
				TheSame_R2 = -1; // >-1 -такая левая скобка уже есть
				//MakeBracketL = false;
				MakeBracketR = false;
				//MakeBracketL2 = false;
				//MakeBracketR2 = false;
			}

		}

	}
	Pp1 = Pp1 + 1;		
}

// Поменять 3 массив, вместо номера "AllSymbols", напрямую записать позицию знака /////////////////////////////////////////
for (int i = 0; i <= CountOfVariables1 - 1; i++) {
	if (AllVariables1 [i, 3] > -1) {
		AllVariables1 [i, 8] = AllSymbols1 [AllVariables1 [i, 3], 3]; // Первоначальная позиция
		AllVariables1 [i, 3] = AllSymbols1 [AllVariables1 [i, 3], 0]; // Позиция в измененном тексте
	}
	//if (AllVariables1 [i, 3] > -1)
	//	print (i + "A: " + AllVariables1 [i, 2] + " | "
	//		+ stext.Substring (AllVariables1 [i, 3],
	//			AllVariables1 [i, 1] - AllVariables1 [i, 3]+1));		
}

// Проверить знаки меняющие результат /////////////////////////////////////////
/*for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
			if (AllVariables1 [i, 4] > -1)
				print (i + "A: " + AllVariables1 [i, 2] + " | "
					+ stext.Substring (AllSymbols1 [AllVariables1 [i, 3], 0],
						AllVariables1 [i, 1] - AllSymbols1 [AllVariables1 [i, 3], 0]+1));		
		}*/
/*		for (int i = 0; i <= CountOfNumbers1 - 1; i++) {	
if (AllNumbers1 [i, 3] > -1) {
	print (i + "B: " + AllNumbers1 [i, 2] + " | "
		+ stext.Substring (AllSymbols1 [AllNumbers1 [i, 2], 0],
			AllNumbers1 [i, 1] - AllSymbols1 [AllNumbers1 [i, 2], 0]+1));		
}
}
for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
	if ((BracketStep2 [i, 6] > -1) & (BracketStep2 [i, 5] > -1)) {
		print (i + "C2: " + BracketStep2 [i, 5] + " | "
			+ AllSymbols1 [BracketStep2 [i, 5], 0]+ " | "
			+ BracketStep2 [i, 1]+ " | "
			+ (BracketStep2 [i, 1] - AllSymbols1 [BracketStep2 [i, 5], 0]+1));	
		print (i + "C: " + BracketStep2 [i, 1] + " | "
			+ stext.Substring (AllSymbols1 [BracketStep2 [i, 5], 0],
				BracketStep2 [i, 1] - AllSymbols1 [BracketStep2 [i, 5], 0]+1));		
	}
}*/

/*for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
if ((BracketStep2 [i, 6] > -1) & (BracketStep2 [i, 5] > -1)) {
	//print (i + "C2: " + BracketStep2 [i, 5] + " | "
	//	+ AllSymbols1 [BracketStep2 [i, 5], 0]+ " | "
	//	+ BracketStep2 [i, 1]+ " | "
	//	+ (BracketStep2 [i, 1] - AllSymbols1 [BracketStep2 [i, 5], 0]+1));	
	print (i + "1: "
		+ stext.Substring (AllSymbols1 [BracketStep2 [i, 5], 0],
			BracketStep2 [i, 1] - AllSymbols1 [BracketStep2 [i, 5], 0] + 1));		
} else {
	print (i + "2: "
		+ stext.Substring (BracketStep2 [i, 0],
			BracketStep2 [i, 1] - BracketStep2 [i, 0]+1));	
}
}*/


/*
for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
	//if (BracketStep2 [i, 5] > -1) {
	print (i + "C: " + BracketStep2 [i, 1] + " | "
		+ stext.Substring (BracketStep2 [i, 0],
			BracketStep2 [i, 1] - BracketStep2 [i, 0]+1));		
	//}
}*/

// Сохранить позиции правых скобок в строку  ///////////////////////////////////////////////////////////////
//int CountBracket = 0;
CountBracket = 0;
string sBracketStep = ";";
Pp1 = 0;
while (Pp1 <= sVariable.Length - 1) {
	//print (s [Pp1] + " = " + sVariable [Pp1] + " = " + Pp1);
	if (sVariable [Pp1] != Symbols2 [0]) { // Если не пробел
		//print (s [Pp1] + " + " + sVariable [Pp1]);
		if ((sVariable [Pp1] == Bracket_R [0]) |
			(sVariable [Pp1] == Bracket_R [2])) { // Если любая закрывающаяся скобка
			sBracketStep = sBracketStep + Pp1.ToString () + ";";
			CountBracket = CountBracket + 1;
		}
	}
	Pp1 = Pp1 + 1;			
}

// Расставить все скобки по порядку в массив "BracketStep" из строки "sBracketStep"
BoolTryParse = false;
//int[,] BracketStep = new int[CountBracket,11]; // 0-позиция левой скобки, 1-позиция правой скобки, 2-тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные), 3-позиция знака перед скобкой, 4- -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой, 5- номер переменной "AllVariables1" для данных скобок (-1 если нет переменной), 6-кол-во запятых внутри выбранных скобок, 7-к какой скобке относится эта часть (-1=не связано с запятыми), 8-первоначальная позиция левой скобки, 9-первоначальная позиция правой скобки, 10-первоначальная позиция знака перед собкой, 11-Если дополненная скобка, то номер первоначальной скобки в которой находится данная скобка, иначе -1, 12-номер скобки в которой находится данная скобка, 13-номер действия в массиве "AllActions"
BracketStep = new int[CountBracket,14]; // 0-позиция левой скобки, 1-позиция правой скобки, 2-тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные), 3-позиция знака перед скобкой, 4- -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой, 5- номер переменной "AllVariables1" для данных скобок (-1 если нет переменной), 6-кол-во запятых внутри выбранных скобок, 7-к какой скобке относится эта часть (-1=не связано с запятыми), 8-первоначальная позиция левой скобки, 9-первоначальная позиция правой скобки, 10-первоначальная позиция знака перед собкой, 11-Если дополненная скобка, то номер первоначальной скобки в которой находится данная скобка, иначе -1, 12-номер скобки в которой находится данная скобка, 13-номер действия в массиве "AllActions"
int[] BracketStep_by2 = new int[CountBracket]; // Позиции "BracketStep2" в "BracketStep"
//float[] BracketStep_N = new float[CountBracket]; // Чему равны действия в скобках
BracketStep_N = new float[CountBracket]; // Чему равны действия в скобках
BracketStep_T = new string[CountBracket]; // Текст с действием в скобках
/*for (int i = 0; i <= CountBracket - 1; i++) { // Обновить массив
	BracketStep [i, 0] = -1; // 0-позиция левой скобки
	BracketStep [i, 1] = -1; // 1-позиция правой скобки
	BracketStep [i, 2] = -1; // 2-тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные)
	BracketStep [i, 3] = -1; // 3-позиция знака перед скобкой
	BracketStep [i, 4] = -1; // 4- -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой
		}*/

//bool justfound1;
Pp0 = 0;	
Pp1 = 0;	
for (int i = 0; i <= CountBracket - 1; i++) {
	Pp0 = Pp1;	
	Pp1 = sBracketStep.IndexOf (";", Pp0 + 1);	

	if ((Pp0 > -1) & (Pp1 > -1)) {			
		// Найти цифру
		//print (i+" | "+sBracketStep.Substring (Pp0+1, Pp1 - Pp0-1));
		BoolTryParse = int.TryParse (sBracketStep.Substring (Pp0 + 1, Pp1 - Pp0 - 1), out BracketStep [i, 1]); 
		if (BoolTryParse == true) {	
			for (int j = 0; j <= CountBracket2_4 - 1; j++) {	
				if (BracketStep2 [j, 1] == BracketStep [i, 1]) {
					BracketStep_by2 [j] = i; // Позиции "BracketStep2" в "BracketStep"
					BracketStep [i, 0] = BracketStep2 [j, 0]; // 0-позиция левой скобки
					BracketStep [i, 2] = BracketStep2 [j, 2]; // 2-тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные)
					if (BracketStep2 [j, 5] > -1) {
						BracketStep [i, 3] = AllSymbols1 [BracketStep2 [j, 5], 0]; // 3-позиция знака перед скобкой
						BracketStep [i, 10] = AllSymbols1 [BracketStep2 [j, 5], 3]; // 10-первоначальная позиция знака перед собкой
					} else {
						BracketStep [i, 3] = -1;
						BracketStep [i, 10] = -1;
					}
					//if (BracketStep2 [j, 6] > -1) {
					BracketStep [i, 4] = BracketStep2 [j, 6]; // 4- -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой
					BracketStep [i, 5] = BracketStep2 [j, 7]; // 5- номер переменной "AllVariables1" для данных скобок (-1 если нет переменной)
					if (BracketStep [i, 5]>-1) // Если у скобок есть переменная
						AllVariables1[BracketStep [i, 5],2] = i; // 2-номер скобки в массиве "BracketStep" (-1 если нет скобок)
					BracketStep [i, 6] = BracketStep2 [j, 8]; // 6-кол-во запятых внутри выбранных скобок												
					BracketStep [i, 7] = BracketStep2 [j, 9]; // 7-к какой скобке относится эта часть (-1=не связано с запятыми)
					BracketStep [i, 8] = BracketStep2 [j, 10]; // 8-первоначальная позиция левой скобки
					BracketStep [i, 9] = BracketStep2 [j, 11]; // 9-первоначальная позиция правой скобки  

					/*if ((BracketStep [i, 0] > -1) &
						(BracketStep [i, 1] > -1)) {
						//if (BracketStep [i, 4] > -1) { // Если перед скобкой есть знак "+", "-"
						//if ((BracketStep [i, 4]==-3) | (BracketStep [i, 4]==1)) { // 4- -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной
						if (BracketStep [i, 4]!=-1) { // 4- -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной
							print (i + " | "+ j + " D1: " + BracketStep [i, 4] + " | "
								+ stext.Substring (BracketStep [i, 3],
									BracketStep [i, 1] - BracketStep [i, 3] + 1));	
						} else 
						{
							print (i + " | "+ j + " D2: " + BracketStep [i, 4] + " | "
								+ stext.Substring (BracketStep [i, 0],
									BracketStep [i, 1] - BracketStep [i, 0] + 1));
						}
					}*/				

					//if (BracketStep [i, 8] > 0) {
					//	print ("4???: " + s1.Substring (BracketStep [i, 8] - 1, 
					//		BracketStep [i, 9] - BracketStep [i, 8] + 1));
					//}
					//BracketStep [i, 4] = AllSymbols1 [BracketStep2 [j, 5], 1]; // 4- -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой
					//if (s [AllSymbols1 [BracketStep2 [j, 5], 0]] == Symbols [0]) { // Если "+"
					//	BracketStep [i, 4] = 0; // 4- -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой
					//} else { // Если "-"
					//	BracketStep [i, 4] = 1; // 4- -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой
					//}
					//}
					break;
				}
			}
		}
	}		
}


// Обозначить скобки внутри собок
/*for (int i = 0; i <= CountBracket - 1; i++) {
			if (BracketStep [i, 2] == 4) { // Если дополненная скобка		
				for (int j = i; j <= CountBracket - 1; j++) {
					if (BracketStep [j, 2] < 4) { // Если первоначальная скобка	
						if ((BracketStep [i, 0] > BracketStep [j, 0]) &
						    (BracketStep [i, 1] < BracketStep [j, 1])) { // Если находится внутри найденных скобок
							BracketStep [i, 8] = BracketStep [j, 8]; // 8-первоначальная позиция левой скобки
							BracketStep [i, 9] = BracketStep [j, 9]; // 9-первоначальная позиция правой скобки  
							BracketStep [i, 10] = BracketStep [j, 10]; // 10-первоначальная позиция знака перед собкой
							BracketStep [i, 11] = j; // 11-если дополненная скобка, то номер первоначальной скобки в которой находится данная скобка, иначе -1
							break;
						}
					}
				}
			} else {
				BracketStep [i, 11] = -1; // 11-если дополненная скобка, то номер первоначальной скобки в которой находится данная скобка, иначе -1
			}

			for (int j = i; j <= CountBracket - 1; j++) {
				if ((BracketStep [i, 0] > BracketStep [j, 0]) &
				     (BracketStep [i, 1] < BracketStep [j, 1])) { // Если находится внутри найденных скобок
					BracketStep [i, 12] = j; // 12-номер скобки в которой находится данная скобка
					break;
				}
			}
		}*/


// Обозначить скобки внутри собок
for (int i = 0; i <= CountBracket - 1; i++) {
			if (BracketStep [i, 2] == 4) { // Если дополненная скобка		
				for (int j = i; j <= CountBracket - 1; j++) {
					if (BracketStep [j, 2] < 4) { // Если первоначальная скобка	
						if ((BracketStep [i, 0] > BracketStep [j, 0]) &
						    (BracketStep [i, 1] < BracketStep [j, 1])) { // Если находится внутри найденных скобок
							//BracketStep [i, 8] = BracketStep [j, 8]; // 8-первоначальная позиция левой скобки
							//BracketStep [i, 9] = BracketStep [j, 9]; // 9-первоначальная позиция правой скобки  
							//BracketStep [i, 10] = BracketStep [j, 10]; // 10-первоначальная позиция знака перед собкой
							BracketStep [i, 11] = j; // 11-если дополненная скобка, то номер первоначальной скобки в которой находится данная скобка, иначе -1
							break;
						}
					}
				}
			} else {
				BracketStep [i, 11] = -1; // 11-если дополненная скобка, то номер первоначальной скобки в которой находится данная скобка, иначе -1
			}

			for (int j = i; j <= CountBracket - 1; j++) {
				if ((BracketStep [i, 0] > BracketStep [j, 0]) &
				     (BracketStep [i, 1] < BracketStep [j, 1])) { // Если находится внутри найденных скобок
					BracketStep [i, 12] = j; // 12-номер скобки в которой находится данная скобка
					break;
				}
			}
		}

// Расставить позиции скобок с запятыми "BracketStep" в правильном порядке
for (int i = 0; i <= CountBracket - 1; i++) {	
	if (BracketStep [i, 7] > -1) {
		BracketStep [i, 7] = BracketStep_by2 [BracketStep [i, 7]]; // 7-к какой скобке относится эта часть (-1=не связано с запятыми)
	}
}

//s_c = stext.ToCharArray();
//sVariable_c = sVariable.ToCharArray();


//print (stext);
//print (new string(sVariable_c));


//print (CountBracket2_2);
//print (CountBracket2_3);	

/*for (int i = 0; i <= CountBracket - 1; i++) {	
	if ((BracketStep [i, 0] > -1) &
		(BracketStep [i, 1] > -1)) {
		//if (BracketStep [i, 4] > -1) { // Если перед скобкой есть знак "+", "-"
		//if ((BracketStep [i, 4]==-3) | (BracketStep [i, 4]==1)) { // 4- -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной
		if (BracketStep [i, 4]!=-1) { // 4- -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной
			print (i + "D1: " + BracketStep [i, 4] + " | "
				+ stext.Substring (BracketStep [i, 3],
					BracketStep [i, 1] - BracketStep [i, 3] + 1));	
		} else 
		{
			print (i + "D2: " + BracketStep [i, 4] + " | "
				+ stext.Substring (BracketStep [i, 0],
					BracketStep [i, 1] - BracketStep [i, 0] + 1));
		}
	}
}*/

// Скобки с запятыми
/*for (int i = 0; i <= CountBracket - 1; i++) {	
	if ((BracketStep [i, 0] > -1) &
		(BracketStep [i, 1] > -1) 
		& (BracketStep [i, 6] > 0)
	) {
		//if (BracketStep [i, 4] > -1) { // Если перед скобкой есть знак "+", "-"
		if ((BracketStep [i, 4]==-3) | (BracketStep [i, 4]==1)) { // 4- -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной
			print (i + "Z1: " + BracketStep [i, 6] + " | "
				+ stext.Substring (AllSymbols1 [BracketStep [i, 3], 0],
					BracketStep [i, 1] - AllSymbols1 [BracketStep [i, 3], 0] + 1));	
		} else 
		{
			print (i + "Z2: " + BracketStep [i, 6] + " | "
				+ stext.Substring (BracketStep [i, 0],
					BracketStep [i, 1] - BracketStep [i, 0] + 1));
		}
	}
}*/

// Расставить значения переменных, у которых нет действий в скобках, в массив "AllVariables_N"
for (int i = 0; i <= CountOfVariables1 - 1; i++) {	
	if (AllVariables1 [i, 5] > -1) {
		AllVariables_N [i] = ResultVariables1 [AllVariables1 [i, 5], 0];
		// Если минус перед переменной
		if ((AllVariables1 [i, 4] == -3) | (AllVariables1 [i, 4] == 1)) { // 4- -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной
			AllVariables_N [i] = -AllVariables_N [i];
		}
	} else
		AllVariables_N [i] = 0;	
}

// Расставить знаки к числам, в массив "AllNumbers_N"
for (int i = 0; i <= CountOfNumbers1 - 1; i++) {	
	// Если минус перед числом
	if ((AllNumbers1 [i, 3]==-3) | (AllNumbers1 [i, 3]==1)) { // 4- -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной
		AllNumbers_N [i] = -AllNumbers_N [i];
	}
}

//bool MinusNumber1=false;
sActions = "";
string sActions2 = "";
string sActions3 = "";
int TypeOfAction1 = 0; // Текущее дествие 0=+, 1=-, 2=*, 3=/, 4=^
int TypeOfSymbol = 0; // 0-число, 1-переменная, 2-скобки

//string sAllActions = "|";
//bool AllActionSave1 = false; // true - сохранить действия в строку "sAllActions"
//int CountOfActions = CountBracket+CountOfSymbols1
//	-CountOfCommas1-CountOfUnActSymbols1; // Количество всех действий
CountOfActions = CountBracket+CountOfSymbols1
	-CountOfCommas1-CountOfUnActSymbols1; // Количество всех действий
//int[,] AllActions = new int[CountOfActions,10]; // 0= Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой", 1= Порядковый номер левого знака (-1 если нет знака), 2= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 3= Порядковый номер левого числа, переменной, или скобок (образует диапазон от), 4= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 5= Порядковый номер левого числа, переменной, или скобок (образует диапазон до), 6= Порядковый номер знака, 7= Порядковый номер правого знака (-1 если нет знака), 8= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 9= Порядковый номер правого числа, переменной, или скобок, 10= левая позиция в дополненном тексте, 11= правая позиция в допоненном тексте, 12= позиция знака в дополненном тексте, 13= левая позиция в основном тексте, 14= правая позиция в основном тексте, 15= позиция знака в основном тексте
AllActions = new int[CountOfActions+1,16]; // 0= Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой", 1= Порядковый номер левого знака (-1 если нет знака), 2= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 3= Порядковый номер левого числа, переменной, или скобок (образует диапазон от), 4= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 5= Порядковый номер левого числа, переменной, или скобок (образует диапазон до), 6= Порядковый номер знака, 7= Порядковый номер правого знака (-1 если нет знака), 8= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 9= Порядковый номер правого числа, переменной, или скобок, 10= левая позиция в дополненном тексте, 11= правая позиция в допоненном тексте, 12= позиция знака в дополненном тексте, 13= левая позиция в основном тексте, 14= правая позиция в основном тексте, 15= позиция знака в основном тексте
//float[,] AllActions_N = new float[CountOfActions,3]; // 0= Результат левого числа, переменной или скобки действия, 1= Результат правого числа, переменной или скобки действия, 2= Результат выполненного действия
AllActions_N = new float[CountOfActions+1,3]; // 0= Результат левого числа, переменной или скобки действия, 1= Результат правого числа, переменной или скобки действия, 2= Результат выполненного действия
//string[] AllActions_T = new string[CountOfActions]; // Текст с действием
AllActions_T = new string[CountOfActions+1]; // Текст с действием
CountOfActions = 0; // Количество всех действий
int CountOfExcessCommas = 0; // Количество лишних запятых

float AllPartResult1 = 0; // Результат действия в скобках
string AllPartResultText = ""; // Дополнительно, результат действия в скобках, без учета модульных скобок и действий в переменных
float SecondPartResult1 = 0; // Число к которому производится дейсвтие
string MinusBefore = "+"; // "-" - если минус перед скобкой, числом или переменной
string VariableBefore = ""; // название переменной если перед скобкой стоит переменная
string TextMainBracket = ""; // " "-не добавленная скобка, "*"-добавленная (дополнительная) скобка
int o = 0;
string s__0 = "";
string s__1 = "";
float[] AllPartResultMass = new float[1];
for (int i = 0; i <= CountBracket - 1; i++) {	
	if ((BracketStep [i, 0] > -1) &
		(BracketStep [i, 1] > -1)) {
		//if ((BracketStep [i, 4] == 1) |
		//    (BracketStep [i, 4] == -3)) // Если перед скобкой минус
		//MinusNumber1 = true;
		//else
		//MinusNumber1 = false;


		// Произвести действия в скобках
		//for (int j = BracketStep [i, 0]+1; j <= BracketStep [i, 1]-1; j++)
		Pp1 = BracketStep [i, 0] + 1;
		TypeOfAction1 = -1; // Текущее дествие 0=+, 1=-, 2=*, 3=/, 4=^
		TypeOfSymbol = -1; // 0-число, 1-переменная, 2-скобки
		AllPartResult1 = 0; // Результат действия в скобках
		sActions2 = "";
		sActions3 = "";
		// Для массива "AllActions" ///////////////////////////////////////////////
		AllActions[CountOfActions,0] = -1; // Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой"
		AllActions[CountOfActions,1] = -1; // Порядковый номер левого знака (-1 если нет знака)
		AllActions[CountOfActions,2] = -1; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
		AllActions[CountOfActions,3] = -1; // Порядковый номер левого числа, переменной, или скобок (образует диапазон от)
		AllActions[CountOfActions,4] = -1; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
		AllActions[CountOfActions,5] = -1; // Порядковый номер левого числа, переменной, или скобок (образует диапазон до)
		AllActions[CountOfActions,6] = -1; // Порядковый номер знака
		AllActions[CountOfActions,7] = -1; // Порядковый номер правого знака (-1 если нет знака)
		AllActions[CountOfActions,8] = -1; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
		AllActions[CountOfActions,9] = -1; // Порядковый номер правого числа, переменной, или скобок
		AllActions[CountOfActions,10] = -1; // 10= левая позиция в дополненном тексте
		AllActions[CountOfActions,11] = -1; // 11= правая позиция в допоненном тексте
		AllActions[CountOfActions,12] = -1; // 12= позиция знака в дополненном тексте
		AllActions[CountOfActions,13] = -1; // 13= левая позиция в основном тексте
		AllActions[CountOfActions,14] = -1; // 14= правая позиция в основном тексте
		AllActions[CountOfActions,15] = -1; // 15= позиция знака в основном тексте
		AllActions_N[CountOfActions,0] = 0; // Результат левого числа, переменной или скобки действия
		AllActions_N[CountOfActions,1] = 0; // Результат правого числа, переменной или скобки действия
		AllActions_N[CountOfActions,2] = 0; // Результат выполненного действия
		///////////////////////////////////////////////////////////////////////////

		while (Pp1 <= BracketStep [i, 1] - 1) {
			//sActions2 = sActions2 + stext [Pp1].ToString ();
			if (sVariable [Pp1] != Symbols2 [0]) { // Если не пробел
				/*if ((sVariable [Pp1] == Symbols [2]) | // "*" - умножить
					(sVariable [Pp1] == Symbols [3]) | // "/" - поделить
					(sVariable [Pp1] == Symbols [4]) | // "^" - степень
					(sVariable [Pp1] == Symbols2 [3]) | // "." - переменная
					(sVariable [Pp1] == Symbols2 [4]) | // "№" - число
					(sVariable [Pp1] == Bracket_L [0]) | // "("
					(sVariable [Pp1] == Bracket_L [2]))  // "["
				{

				}*/

				if (sVariable [Pp1] == "_".ToCharArray () [0]) { // Если знак меняющий результат
					// Для массива "AllActions" ///////////////////////////////////////////////
					for (int j = 0; j <= CountOfSymbols1 - 1; j++) {	
						if (AllSymbols1 [j, 0] == Pp1) { // Найти знак по позиции
							if (sActions2.Length == 0) // Если действие пока не найдено
								AllActions[CountOfActions,1] = j; // Порядковый номер левого знака (-1 если нет знака)
							else AllActions[CountOfActions,7] = j; // Порядковый номер правого знака (-1 если нет знака)
							break;
						}
					}
					///////////////////////////////////////////////////////////////////////////
				} else if (sVariable [Pp1] == Symbols [0]) { // Если действие
					if (stext [Pp1] == Symbols [2]) { // "*" - Если умножить	
						TypeOfAction1 = 2; // Текущее дествие 0=+, 1=-, 2=*, 3=/, 4=^, 5=,
					} else if (stext [Pp1] == Symbols [3]) { // "/" - Если поделить
						TypeOfAction1 = 3; // Текущее дествие 0=+, 1=-, 2=*, 3=/, 4=^, 5=,
					} else if (stext [Pp1] == Symbols [4]) { // "^" - Если степень
						TypeOfAction1 = 4; // Текущее дествие 0=+, 1=-, 2=*, 3=/, 4=^, 5=,
					} 
					// Для массива "AllActions" ///////////////////////////////////////////////
					for (int j = 0; j <= CountOfSymbols1 - 1; j++) {	
						if (AllSymbols1 [j, 0] == Pp1) { // Найти знак по позиции
							AllActions[CountOfActions,0] = AllSymbols1 [j, 1]; // Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой"
							AllActions[CountOfActions,6] = j; // Порядковый номер знака							
							break;
						}
					}
					///////////////////////////////////////////////////////////////////////////
				} else if (sVariable [Pp1] == Symbols [5]) { // Если ","
					TypeOfAction1 = 5; // Текущее дествие 0=+, 1=-, 2=*, 3=/, 4=^, 5=,
				} else if (sVariable [Pp1] == Symbols2 [4]) { // "№" - Если число
					TypeOfSymbol = 0; // 0-число, 1-переменная, 2-скобки
					for (int j = 0; j <= CountOfNumbers1 - 1; j++) {	
						if (AllNumbers1 [j, 0] == Pp1) { // Найти число по позиции
							// Для массива "AllActions" ///////////////////////////////////////////////
							if (AllActions[CountOfActions,2] == -1) { // Если первое действие после скобки
								AllActions[CountOfActions,2] = 0; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
								AllActions[CountOfActions,3] = j; // Порядковый номер левого числа, переменной, или скобок (образует диапазон от)
							} else { // Если второе или > действие после скобки
								AllActions[CountOfActions,4] = AllActions[CountOfActions,8]; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
								AllActions[CountOfActions,5] = AllActions[CountOfActions,9]; // Порядковый номер левого числа, переменной, или скобок (образует диапазон до)
								AllActions[CountOfActions,8] = 0; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
								AllActions[CountOfActions,9] = j; // Порядковый номер правого числа, переменной, или скобок
							}							
							///////////////////////////////////////////////////////////////////////////

							Pp1 = AllNumbers1 [j, 1]; // Продолжить поиск с конца числа
							SecondPartResult1 = AllNumbers_N [j]; // Число к которому производится дейсвтие
							//print (i + "D1: " + SecondPartResult1);									
							break;
						}
					}
				} else if (sVariable [Pp1] == Symbols2 [3]) { // "." - Если переменная
					TypeOfSymbol = 1; // 0-число, 1-переменная, 2-скобки
					for (int j = 0; j <= CountOfVariables1 - 1; j++) {	
						if (AllVariables1 [j, 0] == Pp1) { // Найти переменную по позиции											
							if (AllVariables1 [j, 2] > -1) { // Если у переменной есть скобка																
								// Для массива "AllActions" ///////////////////////////////////////////////
								if (AllActions[CountOfActions,2] == -1) { // Если первое действие после скобки
									AllActions[CountOfActions,2] = 3; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
									AllActions[CountOfActions,3] = j; // Порядковый номер левого числа, переменной, или скобок (образует диапазон от)
								} else { // Если второе или > действие после скобки
									AllActions[CountOfActions,4] = AllActions[CountOfActions,8]; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
									AllActions[CountOfActions,5] = AllActions[CountOfActions,9]; // Порядковый номер левого числа, переменной, или скобок (образует диапазон до)
									AllActions[CountOfActions,8] = 3; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
									AllActions[CountOfActions,9] = j; // Порядковый номер правого числа, переменной, или скобок
								}							
								///////////////////////////////////////////////////////////////////////////

								Pp1 = BracketStep [AllVariables1 [j, 2], 1]; // Продолжить поиск с закрывающейся скобки
							} else { // Если нет скобок
								// Для массива "AllActions" ///////////////////////////////////////////////
								if (AllActions[CountOfActions,2] == -1) { // Если первое действие после скобки
									AllActions[CountOfActions,2] = 1; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
									AllActions[CountOfActions,3] = j; // Порядковый номер левого числа, переменной, или скобок (образует диапазон от)
								} else { // Если второе или > действие после скобки
									AllActions[CountOfActions,4] = AllActions[CountOfActions,8]; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
									AllActions[CountOfActions,5] = AllActions[CountOfActions,9]; // Порядковый номер левого числа, переменной, или скобок (образует диапазон до)
									AllActions[CountOfActions,8] = 1; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
									AllActions[CountOfActions,9] = j; // Порядковый номер правого числа, переменной, или скобок
								}							
								///////////////////////////////////////////////////////////////////////////

								Pp1 = AllVariables1 [j, 1]; // Продолжить поиск с конца названия переменной							
							}
							SecondPartResult1 = AllVariables_N [j]; // Число к которому производится дейсвтие
							//print (i + "D1: " + SecondPartResult1);
							break;
						}
					}
				} else if ((sVariable [Pp1] == Bracket_L [0]) | // "("
					(sVariable [Pp1] == Bracket_L [2])) {  // "[" - Если скобка
					TypeOfSymbol = 2; // 0-число, 1-переменная, 2-скобки
					for (int j = 0; j <= CountBracket - 1; j++) {	
						if (BracketStep [j, 0] == Pp1) { // Найти скобку по позиции
							// Для массива "AllActions" ///////////////////////////////////////////////
							if (AllActions[CountOfActions,2] == -1) { // Если первое действие после скобки
								AllActions[CountOfActions,2] = 2; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
								AllActions[CountOfActions,3] = j; // Порядковый номер левого числа, переменной, или скобок (образует диапазон от)
							} else { // Если второе или > действие после скобки
								AllActions[CountOfActions,4] = AllActions[CountOfActions,8]; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
								AllActions[CountOfActions,5] = AllActions[CountOfActions,9]; // Порядковый номер левого числа, переменной, или скобок (образует диапазон до)
								AllActions[CountOfActions,8] = 2; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
								AllActions[CountOfActions,9] = j; // Порядковый номер правого числа, переменной, или скобок
							}							
							///////////////////////////////////////////////////////////////////////////

							Pp1 = BracketStep [j, 1]; // Продолжить поиск с закрывающейся скобки
							SecondPartResult1 = BracketStep_N [j]; // Число к которому производится дейсвтие
							//print (i + "D1: " + SecondPartResult1);
							break;
						}
					}
				}

				// Выполнить действие
				if (TypeOfSymbol > -1) {

					if (TypeOfAction1 == 2) { // "*" - Если умножить
						// Для массива "AllActions" ///////////////////////////////////////////////
						AllActions_N[CountOfActions,0] = AllPartResult1; // Результат левого числа, переменной или скобки действия
						AllActions_N[CountOfActions,1] = SecondPartResult1; // Результат правого числа, переменной или скобки действия
						///////////////////////////////////////////////////////////////////////////

						AllPartResult1 = AllPartResult1 * SecondPartResult1;

						// Для массива "AllActions" ///////////////////////////////////////////////
						AllActions_N[CountOfActions,2] = AllPartResult1; // Результат выполненного действия
						///////////////////////////////////////////////////////////////////////////

						sActions2 = sActions2
							+ Symbols [TypeOfAction1].ToString ()
							+ SecondPartResult1.ToString ();	
						sActions3 = Symbols [TypeOfAction1].ToString ()
							+ SecondPartResult1.ToString ();
						//CountOfActions = CountOfActions+1; // Количество всех действий															
					} else if (TypeOfAction1 == 3) { // "/" - Если поделить
						// Для массива "AllActions" ///////////////////////////////////////////////
						AllActions_N[CountOfActions,0] = AllPartResult1; // Результат левого числа, переменной или скобки действия
						AllActions_N[CountOfActions,1] = SecondPartResult1; // Результат правого числа, переменной или скобки действия
						///////////////////////////////////////////////////////////////////////////

						AllPartResult1 = AllPartResult1 / SecondPartResult1;

						// Для массива "AllActions" ///////////////////////////////////////////////
						AllActions_N[CountOfActions,2] = AllPartResult1; // Результат выполненного действия
						///////////////////////////////////////////////////////////////////////////

						sActions2 = sActions2
							+ Symbols [TypeOfAction1].ToString ()
							+ SecondPartResult1.ToString ();
						sActions3 = Symbols [TypeOfAction1].ToString ()
							+ SecondPartResult1.ToString ();
						//CountOfActions = CountOfActions+1; // Количество всех действий
					} else if (TypeOfAction1 == 4) { // "^" - Если степень
						// Для массива "AllActions" ///////////////////////////////////////////////
						AllActions_N[CountOfActions,0] = AllPartResult1; // Результат левого числа, переменной или скобки действия
						AllActions_N[CountOfActions,1] = SecondPartResult1; // Результат правого числа, переменной или скобки действия
						///////////////////////////////////////////////////////////////////////////

						AllPartResult1 = Mathf.Pow (AllPartResult1, SecondPartResult1);

						// Для массива "AllActions" ///////////////////////////////////////////////
						AllActions_N[CountOfActions,2] = AllPartResult1; // Результат выполненного действия
						///////////////////////////////////////////////////////////////////////////

						sActions2 = sActions2
							+ Symbols [TypeOfAction1].ToString ()
							+ SecondPartResult1.ToString ();
						sActions3 = Symbols [TypeOfAction1].ToString ()
							+ SecondPartResult1.ToString ();
						//CountOfActions = CountOfActions+1; // Количество всех действий
					} else if (TypeOfAction1 == 5) { // "," - Если запятая
						//AllPartResult1 = Mathf.Pow (AllPartResult1, SecondPartResult1);
						sActions2 = sActions2
							+ Symbols [TypeOfAction1].ToString ()
							+" "+ SecondPartResult1.ToString ();
						//CountOfActions = CountOfActions+1; // Количество всех действий
					} else { // Сложение, т.к. знаки перед числами и переменными уже расставлены
						// Для массива "AllActions" ///////////////////////////////////////////////
						AllActions_N[CountOfActions,0] = AllPartResult1; // Результат левого числа, переменной или скобки действия
						AllActions_N[CountOfActions,1] = SecondPartResult1; // Результат правого числа, переменной или скобки действия
						///////////////////////////////////////////////////////////////////////////

						AllPartResult1 = AllPartResult1 + SecondPartResult1;

						// Для массива "AllActions" ///////////////////////////////////////////////
						AllActions_N[CountOfActions,2] = AllPartResult1; // Результат выполненного действия
						///////////////////////////////////////////////////////////////////////////

						MinusBefore = "";
						if (SecondPartResult1 >= 0) {  // Если число положительное									
							if (sActions2.Length > 0) // Если это знак не для самого первого числа, переменной
								MinusBefore = "+";
						}
						sActions2 = sActions2 + MinusBefore
							+ SecondPartResult1.ToString ();
						sActions3 = MinusBefore
							+ SecondPartResult1.ToString ();
						//CountOfActions = CountOfActions+1; // Количество всех действий
					}

					// "1 часть" Для массива "AllActions" ///////////////////////////////////////////////
					if (AllActions[CountOfActions,0] < 5) { // Если обычное действие // Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой"
						if ((AllActions[CountOfActions,2] > -1) & (TypeOfAction1 != 5)) {
							int Pp__0 = -1; // Знак левого числа, переменной или скобок
							int Pp_0 = 0; // Левое число, переменная, скобка, скобка с переменной (левая позиция) "в дополненном тексте"
							//int Pp_1 = 0; // Левое число, переменная, скобка, скобка с переменной (правая позиция) "в дополненном тексте"
							//int Pp__2 = -1; // Знак правого числа, переменной или скобок "в дополненном тексте"
							//int Pp_2 = 0; // Правое число, переменная, скобка, скобка с переменной (левая позиция) "в дополненном тексте"
							int Pp_3 = 0; // Правое число, переменная, скобка, скобка с переменной (правая позиция) "в дополненном тексте"
							int Pp__0M = -1; // Знак левого числа, переменной или скобок "в основном тексте"
							int Pp_0M = 0; // Левое число, переменная, скобка, скобка с переменной (левая позиция) "в основном тексте"
							//int Pp_1M = 0; // Левое число, переменная, скобка, скобка с переменной (правая позиция) "в основном тексте"
							//int Pp__2M = -1; // Знак правого числа, переменной или скобок "в основном тексте"
							//int Pp_2M = 0; // Правое число, переменная, скобка, скобка с переменной (левая позиция) "в основном тексте"
							int Pp_3M = 0; // Правое число, переменная, скобка, скобка с переменной (правая позиция) "в основном тексте"

							if (AllActions[CountOfActions,1] > -1) { // Если у левого числа, переменной или скобок есть знак "+", "-"
								Pp__0 = AllSymbols1 [AllActions[CountOfActions,1], 0]; // Знак левого числа, переменной или скобок "в дополненном тексте"
								Pp__0M = AllSymbols1 [AllActions[CountOfActions,1], 3]; // Знак левого числа, переменной или скобок "в основном тексте"
							}

							if (AllActions[CountOfActions,2] == 0) { // Если число
								Pp_0 = AllNumbers1 [AllActions[CountOfActions,3], 0];	
								Pp_0M = AllNumbers1 [AllActions[CountOfActions,3], 4];	
								/*if (AllActions [CountOfActions, 4] == -1) { // Если одна позиция
									Pp_1 = AllNumbers1 [AllActions [CountOfActions, 3], 1];
									Pp_1M = AllNumbers1 [AllActions [CountOfActions, 3], 5];
								}*/
							} else if ((AllActions[CountOfActions,2] == 1) | (AllActions[CountOfActions,2] == 3)) { // Если переменная
								Pp_0 = AllVariables1 [AllActions[CountOfActions,3], 0];	
								Pp_0M = AllVariables1 [AllActions[CountOfActions,3], 6];	
								if (AllActions[CountOfActions,4] == -1) { // Если одна позиция
									/*if ((AllActions [CountOfActions, 2] == 1) | (AllVariables1 [AllActions [CountOfActions, 3], 2] < 0)) { // Если переменная без скобок
										Pp_1 = AllVariables1 [AllActions [CountOfActions, 3], 1];
										Pp_1M = AllVariables1 [AllActions [CountOfActions, 3], 7];
									} else { // Если переменная со скобками
										Pp_1 = BracketStep [AllVariables1 [AllActions [CountOfActions, 3], 2], 1];
										Pp_1M = BracketStep [AllVariables1 [AllActions [CountOfActions, 3], 2], 9];
									}*/
								}
							} else if (AllActions[CountOfActions,2] == 2) { // Если скобки
								Pp_0 = BracketStep [AllActions[CountOfActions,3], 0];
								Pp_0M = BracketStep [AllActions[CountOfActions,3], 8];
								/*if (AllActions [CountOfActions, 4] == -1) { // Если одна позиция
									Pp_1 = BracketStep [AllActions [CountOfActions, 3], 1];
									Pp_1M = BracketStep [AllActions [CountOfActions, 3], 9];
								}*/
							}

							/*if (AllActions[CountOfActions,4] == 0) { // Если число
								Pp_1 = AllNumbers1 [AllActions[CountOfActions,5], 1];	
								Pp_1M = AllNumbers1 [AllActions[CountOfActions,5], 5];	
							} else if ((AllActions[CountOfActions,4] == 1) | (AllActions[CountOfActions,4] == 3)) { // Если переменная
								if ((AllActions [CountOfActions, 4] == 1) | (AllVariables1 [AllActions [CountOfActions, 5], 2] < 0)) { // Если переменная без скобок
									Pp_1 = AllVariables1 [AllActions [CountOfActions, 5], 1];
									Pp_1M = AllVariables1 [AllActions [CountOfActions, 5], 7];
								} else { // Если переменная со скобками
									Pp_1 = BracketStep [AllVariables1 [AllActions [CountOfActions, 5], 2], 1];
									Pp_1M = BracketStep [AllVariables1 [AllActions [CountOfActions, 5], 2], 9];
								}
							} else if (AllActions[CountOfActions,4] == 2) { // Если скобки
								Pp_1 = BracketStep [AllActions[CountOfActions,5], 1];	
								Pp_1M = BracketStep [AllActions[CountOfActions,5], 9];
							}

							if (AllActions[CountOfActions,7] > -1) { // Если у правого числа, переменной или скобок есть знак "+", "-"
								Pp__2 = AllSymbols1 [AllActions[CountOfActions,7], 0]; // Знак правого числа, переменной или скобок "в дополненном тексте"
								Pp__2M = AllSymbols1 [AllActions[CountOfActions,7], 3]; // Знак правого числа, переменной или скобок "в основном тексте"
							}*/

							if (AllActions[CountOfActions,8] == 0) { // Если число
								//Pp_2 = AllNumbers1 [AllActions[CountOfActions,9], 0];
								//Pp_2M = AllNumbers1 [AllActions[CountOfActions,9], 4];
								Pp_3 = AllNumbers1 [AllActions[CountOfActions,9], 1];
								Pp_3M = AllNumbers1 [AllActions[CountOfActions,9], 5];
							} else if ((AllActions[CountOfActions,8] == 1) | (AllActions[CountOfActions,8] == 3)) { // Если переменная
								if ((AllActions[CountOfActions,8] == 1) | (AllVariables1 [AllActions[CountOfActions,9], 2] < 0)) { // Если переменная без скобок
									//Pp_2 = AllVariables1 [AllActions[CountOfActions,9], 0];
									//Pp_2M = AllVariables1 [AllActions[CountOfActions,9], 6];
									Pp_3 = AllVariables1 [AllActions[CountOfActions,9], 1];
									Pp_3M = AllVariables1 [AllActions[CountOfActions,9], 7];
								} else { // Если переменная со скобками
									//Pp_2 = BracketStep [AllVariables1 [AllActions[CountOfActions,9], 2], 0];
									//Pp_2M = BracketStep [AllVariables1 [AllActions[CountOfActions,9], 2], 8];
									Pp_3 = BracketStep [AllVariables1 [AllActions[CountOfActions,9], 2], 1];
									Pp_3M = BracketStep [AllVariables1 [AllActions[CountOfActions,9], 2], 9];
								}
							} else if (AllActions[CountOfActions,8] == 2) { // Если скобки
								//Pp_2 = BracketStep [AllActions[CountOfActions,9], 0];	
								//Pp_2M = BracketStep [AllActions[CountOfActions,9], 8];
								Pp_3 = BracketStep [AllActions[CountOfActions,9], 1];	
								Pp_3M = BracketStep [AllActions[CountOfActions,9], 9];	
							}							

							if (Pp__0 == -1) { // Если нет знака перед левым числом, переменной или скобками
								if (Pp_3 > Pp_0) {
									AllActions[CountOfActions,10] = Pp_0; // 10= левая позиция в дополненном тексте
									AllActions[CountOfActions,11] = Pp_3; // 11= правая позиция в допоненном тексте
									AllActions[CountOfActions,12] = -1; // 12= позиция знака в дополненном тексте
									AllActions[CountOfActions,13] = Pp_0M; // 13= левая позиция в основном тексте
									AllActions[CountOfActions,14] = Pp_3M; // 14= правая позиция в основном тексте
									AllActions[CountOfActions,15] = -1; // 15= позиция знака в основном тексте
									/*if (sActions2 != (AllActions_N [CountOfActions, 0].ToString ()
										+ sActions3)) { // Если текст отличается
										AllActions_T [CountOfActions] = sActions2
										+ " = " + AllActions_N [CountOfActions, 0].ToString ()
										+ sActions3; // Текст с действием
									} else {*/
										AllActions_T [CountOfActions] = AllActions_N [CountOfActions, 0].ToString ()
											+ sActions3; // Текст с действием
									//}
									/*print (sActions2 + System.Environment.NewLine
										+ CountOfActions + ":1@ " 
										+ stext.Substring (Pp_0, Pp_3 - Pp_0 + 1)
										+" = "+AllActions_N[CountOfActions,2]);*/

									CountOfActions = CountOfActions + 1; // Количество всех действий

									AllActions[CountOfActions,0] = AllActions[CountOfActions-1,0]; // Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой"
									AllActions[CountOfActions,1] = AllActions[CountOfActions-1,1]; // Порядковый номер левого знака (-1 если нет знака)
									AllActions[CountOfActions,2] = AllActions[CountOfActions-1,2]; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
									AllActions[CountOfActions,3] = AllActions[CountOfActions-1,3]; // Порядковый номер левого числа, переменной, или скобок (образует диапазон от)
									//AllActionSave1 = true; // true - сохранить действия в строку "sAllActions"
								}
							} else { // Если есть знак перед левым числом, переменной или скобками
								if (Pp_3 > Pp__0) {
									AllActions[CountOfActions,10] = Pp_0; // 10= левая позиция в дополненном тексте
									AllActions[CountOfActions,11] = Pp_3; // 11= правая позиция в допоненном тексте
									AllActions[CountOfActions,12] = Pp__0; // 12= позиция знака в дополненном тексте
									AllActions[CountOfActions,13] = Pp_0M; // 13= левая позиция в основном тексте
									AllActions[CountOfActions,14] = Pp_3M; // 14= правая позиция в основном тексте
									AllActions[CountOfActions,15] = Pp__0M; // 15= позиция знака в основном тексте
									/*if (sActions2 != (AllActions_N [CountOfActions, 0].ToString ()
										+ sActions3)) { // Если текст отличается
										AllActions_T [CountOfActions] = sActions2
											+ " = " + AllActions_N [CountOfActions, 0].ToString ()
											+ sActions3; // Текст с действием
									} else {*/
										AllActions_T [CountOfActions] = AllActions_N [CountOfActions, 0].ToString ()
											+ sActions3; // Текст с действием
									//}
									/*print (sActions2 + System.Environment.NewLine
										+ CountOfActions + ":2@ " 
										+ stext.Substring (Pp__0, Pp_3 - Pp__0 + 1)
										+" = "+AllActions_N[CountOfActions,2]);*/

									//sAllActions = sAllActions
									//	+ stext.Substring (Pp__0, Pp_3 - Pp__0 + 1)
									//	+ System.Environment.NewLine;

									CountOfActions = CountOfActions + 1; // Количество всех действий

									AllActions[CountOfActions,0] = AllActions[CountOfActions-1,0]; // Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой"
									AllActions[CountOfActions,1] = AllActions[CountOfActions-1,1]; // Порядковый номер левого знака (-1 если нет знака)
									AllActions[CountOfActions,2] = AllActions[CountOfActions-1,2]; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
									AllActions[CountOfActions,3] = AllActions[CountOfActions-1,3]; // Порядковый номер левого числа, переменной, или скобок (образует диапазон от)
									//AllActionSave1 = true; // true - сохранить действия в строку "sAllActions"
								}
							}

							/*if (AllActionSave1 == true) { // true - сохранить действия в строку "sAllActions"								
								sAllActions = sAllActions
									+ AllActions[CountOfActions-1,0].ToString () + ";"
									+ AllActions[CountOfActions-1,1].ToString () + ";"
									+ AllActions[CountOfActions-1,2].ToString () + ";"
									+ AllActions[CountOfActions-1,3].ToString () + ";"
									+ AllActions[CountOfActions-1,4].ToString () + ";"
									+ AllActions[CountOfActions-1,5].ToString () + ";"
									+ AllActions[CountOfActions-1,6].ToString () + ";"
									+ AllActions[CountOfActions-1,7].ToString () + ";"
									+ AllActions[CountOfActions-1,8].ToString () + ";"
									+ AllActions[CountOfActions-1,9].ToString () + ";"
									+ AllActions_N[CountOfActions-1,0].ToString () + ";"
									+ AllActions_N[CountOfActions-1,1].ToString () + ";"
									+ AllActions_N[CountOfActions-1,2].ToString () + "|";
								AllActionSave1 = false; // true - сохранить действия в строку "sAllActions"							
							}*/
						}
					} 
					//else { // Если скобки или переменная со скобками // Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой"						
					//}
					///////////////////////////////////////////////////////////////////////////

					//print (i + "D2: " + sActions2);
					TypeOfAction1 = -1; // Текущее дествие 0=+, 1=-, 2=*, 3=/, 4=^
					TypeOfSymbol = -1; // 0-число, 1-переменная, 2-скобки	

					// Для массива "AllActions" ///////////////////////////////////////////////
					//AllActions[CountOfActions,0] = -1; // Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой"
					//AllActions[CountOfActions,1] = -1; // Порядковый номер левого знака (-1 если нет знака)
					//AllActions[CountOfActions,2] = -1; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
					//AllActions[CountOfActions,3] = -1; // Порядковый номер левого числа, переменной, или скобок (образует диапазон от)
					AllActions[CountOfActions,4] = -1; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
					AllActions[CountOfActions,5] = -1; // Порядковый номер левого числа, переменной, или скобок (образует диапазон до)
					AllActions[CountOfActions,6] = -1; // Порядковый номер знака
					AllActions[CountOfActions,7] = -1; // Порядковый номер правого знака (-1 если нет знака)
					AllActions[CountOfActions,8] = -1; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
					AllActions[CountOfActions,9] = -1; // Порядковый номер правого числа, переменной, или скобок
					///////////////////////////////////////////////////////////////////////////
				}
			}
			Pp1 = Pp1 + 1;					
			//	print (i + "D2: " + BracketStep [i, 2] + " | "
			//		+ stext.Substring (BracketStep [i, 0],
			//			BracketStep [i, 1] - BracketStep [i, 0] + 1));		
		}			


		// Для массива "AllActions" ///////////////////////////////////////////////
		AllActions[CountOfActions,0] = -1; // Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой"
		AllActions[CountOfActions,1] = -1; // Порядковый номер левого знака (-1 если нет знака)
		AllActions[CountOfActions,2] = -1; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
		AllActions[CountOfActions,3] = -1; // Порядковый номер левого числа, переменной, или скобок (образует диапазон от)
		AllActions[CountOfActions,4] = -1; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
		AllActions[CountOfActions,5] = -1; // Порядковый номер левого числа, переменной, или скобок (образует диапазон до)
		AllActions[CountOfActions,6] = -1; // Порядковый номер знака
		AllActions[CountOfActions,7] = -1; // Порядковый номер правого знака (-1 если нет знака)
		AllActions[CountOfActions,8] = -1; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
		AllActions[CountOfActions,9] = -1; // Порядковый номер правого числа, переменной, или скобок
		AllActions_N[CountOfActions,0] = 0; // Результат левого числа, переменной или скобки действия
		AllActions_N[CountOfActions,1] = 0; // Результат правого числа, переменной или скобки действия
		AllActions_N[CountOfActions,2] = 0; // Результат выполненного действия
		///////////////////////////////////////////////////////////////////////////


		AllPartResultText = AllPartResult1.ToString ();

		if (BracketStep [i, 2] == 1) { // Если модульные скобки
			AllPartResult1 = Mathf.Abs (AllPartResult1);

			// Для массива "AllActions" ///////////////////////////////////////////////
			AllActions[CountOfActions,0] = 6; // Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой"
			///////////////////////////////////////////////////////////////////////////
		}			
		//else
		//AllPartResult1 = AllPartResult1;

		VariableBefore = ""; // название переменной если перед скобкой стоит переменная
		MinusBefore = ""; // "-" - если минус перед скобкой, числом или переменной	
		CountOfExcessCommas = 0; // Количество лишних запятых

		if (BracketStep [i, 5] > -1) { // Если у скобок есть переменная	
			// Для массива "AllActions" ///////////////////////////////////////////////
			AllActions[CountOfActions,0] = 10; // Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой"
			///////////////////////////////////////////////////////////////////////////	
			AllPartResultMass [0] = AllPartResult1;
			if ((BracketStep [i, 6] > 0) &
				(ResultVariables1 [AllVariables1 [BracketStep [i, 5], 5], 1] > 0)) { // Если есть запятые и они имеют место быть для выбранной переменной "AllVariables1 [BracketStep [i, 5], 5]"
				AllPartResultText = "";
				AllPartResultMass = new float[BracketStep [i, 6] + 1];
				o = 0;
				for (int j = 0; j <= i; j++) {	
					if (BracketStep [j, 7] == i) {
						AllPartResultMass [o] = BracketStep_N [j];
						//ResultVariables1[0,1] = 2; // Кол-во действий в скобках для переменной
						if (o < ResultVariables1 [AllVariables1 [BracketStep [i, 5], 5], 1]) { // Если кол-ва дейтвий достаточо
							AllPartResultText = AllPartResultText + ", " + AllPartResultMass [o].ToString ();
							//print (o + " awFfwawa: " + AllPartResultMass [o]);
						} else {
							CountOfExcessCommas = CountOfExcessCommas+1; // Количество лишних запятых
						}
						o = o + 1;
					}
				}
				if (AllPartResultText.Length > 1)
					AllPartResultText = AllPartResultText.Substring (2, AllPartResultText.Length - 2);
			}
			// Если минус перед переменной
			if ((AllVariables1 [BracketStep [i, 5], 4] == -3) |
				(AllVariables1 [BracketStep [i, 5], 4] == 1)) { // 4- -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной											
				if (AllVariables1 [BracketStep [i, 5], 5] >= CountVariables) { // Если стандартная переменная
					AllVariables_N [BracketStep [i, 5]] = 
						-FindVariables (AllVariables1 [BracketStep [i, 5], 5], (BracketStep [i, 6]+1), AllPartResultMass); // "FindVariables" Найти значение стандартной переменной
				} else { // Если своя переменная
					AllVariables_N [BracketStep [i, 5]] = 
						-FindMyVariables (AllVariables1 [BracketStep [i, 5], 5], (BracketStep [i, 6]+1), AllPartResultMass); // "FindMyVariables" Найти значение своей переменной
				}
				//AllVariables_N [BracketStep [i, 5]] = -AllPartResult1;
				MinusBefore = "-"; // "-" - если минус перед скобкой, числом или переменной

				// Для массива "AllActions" ///////////////////////////////////////////////
				for (int j = 0; j <= CountOfSymbols1 - 1; j++) {	
					if (AllSymbols1 [j, 0] == AllVariables1 [BracketStep [i, 5], 3]) { // Найти знак по позиции
						AllActions[CountOfActions,1] = j; // Порядковый номер левого знака (-1 если нет знака)
						break;
					}
				}
				///////////////////////////////////////////////////////////////////////////
			} else {								
				if (AllVariables1 [BracketStep [i, 5], 5] >= CountVariables) { // Если стандартная переменная
					AllVariables_N [BracketStep [i, 5]] = 
						FindVariables (AllVariables1 [BracketStep [i, 5], 5], (BracketStep [i, 6]+1), AllPartResultMass); // "FindVariables" Найти значение стандартной переменной
				} else { // Если своя переменная
					AllVariables_N [BracketStep [i, 5]] = 
						FindMyVariables (AllVariables1 [BracketStep [i, 5], 5], (BracketStep [i, 6]+1), AllPartResultMass); // "FindMyVariables" Найти значение своей переменной
				}
				//AllVariables_N [BracketStep [i, 5]] = AllPartResult1;
				// Если плюс перед переменной
				if (AllVariables1 [BracketStep [i, 5], 4] != -1) {
					MinusBefore = "+"; // "-" - если минус перед скобкой, числом или переменной
					// Для массива "AllActions" ///////////////////////////////////////////////
					for (int j = 0; j <= CountOfSymbols1 - 1; j++) {	
						if (AllSymbols1 [j, 0] == AllVariables1 [BracketStep [i, 5], 3]) { // Найти знак по позиции
							AllActions[CountOfActions,1] = j; // Порядковый номер левого знака (-1 если нет знака)
							break;
						}
					}
					///////////////////////////////////////////////////////////////////////////
				}
			}

			// Для массива "AllActions" ///////////////////////////////////////////////
			AllActions[CountOfActions,2] = 3; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
			AllActions[CountOfActions,3] = BracketStep [i, 5]; // Порядковый номер левого числа, переменной, или скобок (образует диапазон от)
			AllActions[CountOfActions,4] = 3; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
			AllActions[CountOfActions,5] = BracketStep [i, 5]; // Порядковый номер левого числа, переменной, или скобок (образует диапазон до)
			AllActions[CountOfActions,8] = 2; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
			AllActions[CountOfActions,9] = i; // Порядковый номер правого числа, переменной, или скобок
			AllActions_N[CountOfActions,2] = AllVariables_N [BracketStep [i, 5]]; // Результат выполненного действия
			///////////////////////////////////////////////////////////////////////////

			BracketStep_N [i] = AllVariables_N [BracketStep [i, 5]];
			VariableBefore = NameVariables1 [AllVariables1 [BracketStep [i, 5], 5], 0]; // название переменной если перед скобкой стоит переменная
		} else { // Если у скобок нет переменной
			// Для массива "AllActions" ///////////////////////////////////////////////
			AllActions[CountOfActions,0] = BracketStep [i, 2]+5; // Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой"
			///////////////////////////////////////////////////////////////////////////	
			// Если минус перед скобкой
			if ((BracketStep [i, 4] == -3) | (BracketStep [i, 4] == 1)) { // 4- -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной						
				BracketStep_N [i] = -AllPartResult1;
				MinusBefore = "-"; // "-" - если минус перед скобкой, числом или переменной

				// Для массива "AllActions" ///////////////////////////////////////////////
				for (int j = 0; j <= CountOfSymbols1 - 1; j++) {	
					if (AllSymbols1 [j, 0] == BracketStep [i, 3]) { // Найти знак по позиции
						AllActions[CountOfActions,1] = j; // Порядковый номер левого знака (-1 если нет знака)
						break;
					}
				}
				///////////////////////////////////////////////////////////////////////////
			} else {
				BracketStep_N [i] = AllPartResult1;	
				// Если плюс перед скобкой
				if (BracketStep [i, 4] != -1) 
				{
					MinusBefore = "+"; // "-" - если минус перед скобкой, числом или переменной
					// Для массива "AllActions" ///////////////////////////////////////////////
					for (int j = 0; j <= CountOfSymbols1 - 1; j++) {	
						if (AllSymbols1 [j, 0] == BracketStep [i, 3]) { // Найти знак по позиции
							AllActions[CountOfActions,1] = j; // Порядковый номер левого знака (-1 если нет знака)
							break;
						}
					}
					///////////////////////////////////////////////////////////////////////////
				}
			}
			// Для массива "AllActions" ///////////////////////////////////////////////
			AllActions[CountOfActions,2] = 2; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
			AllActions[CountOfActions,3] = i; // Порядковый номер левого числа, переменной, или скобок (образует диапазон от)
			AllActions[CountOfActions,4] = 2; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
			AllActions[CountOfActions,5] = i; // Порядковый номер левого числа, переменной, или скобок (образует диапазон до)
			AllActions[CountOfActions,8] = 2; // Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками
			AllActions[CountOfActions,9] = i; // Порядковый номер правого числа, переменной, или скобок
			AllActions_N[CountOfActions,2] = BracketStep_N [i]; // Результат выполненного действия
			///////////////////////////////////////////////////////////////////////////
		}

		if ((BracketStep [i, 2] == 4) | (i == (CountBracket-1))) { // Если дополнительная или последняя скобка
			TextMainBracket = "*"; // " "-не добавленная скобка, "*"-добавленная (дополнительная) скобка
		}
		else TextMainBracket = " "; // " "-не добавленная скобка, "*"-добавленная (дополнительная) скобка

		BracketStep [i, 13] = CountOfActions; // 13-номер действия в массиве "AllActions"

		/*sActions = MinusBefore + VariableBefore
			+ Bracket_L [BracketStep [i, 2]].ToString () + sActions2
			+ Bracket_R [BracketStep [i, 2]].ToString () + " = "
			+ MinusBefore + VariableBefore
			+ Bracket_L [BracketStep [i, 2]].ToString () + AllPartResultText
			+ Bracket_R [BracketStep [i, 2]].ToString () + " = "
			+ BracketStep_N [i];*/

		//print (i + ": " + sActions);

		/*sActions = sActions+TextMainBracket+i + ": " + MinusBefore + VariableBefore
			+ Bracket_L [BracketStep [i, 2]].ToString () + sActions2
			+ Bracket_R [BracketStep [i, 2]].ToString () + " = "
			+ MinusBefore + VariableBefore
			+ Bracket_L [BracketStep [i, 2]].ToString () + AllPartResultText
			+ Bracket_R [BracketStep [i, 2]].ToString () + " = "
			+ BracketStep_N [i] + System.Environment.NewLine;*/


		// "2 часть" Для массива "AllActions" ///////////////////////////////////////////////
		/*s__0 = TextMainBracket+i + ": " + MinusBefore + VariableBefore
			+ Bracket_L [BracketStep [i, 2]].ToString () + sActions2
			+ Bracket_R [BracketStep [i, 2]].ToString () + " = "
			+ MinusBefore + VariableBefore
			+ Bracket_L [BracketStep [i, 2]].ToString () + AllPartResultText
			+ Bracket_R [BracketStep [i, 2]].ToString () + " = "
			+ BracketStep_N [i];*/

		//s__0 = MinusBefore + VariableBefore
		//	+ Bracket_L [BracketStep [i, 2]].ToString () + sActions2
		//	+ Bracket_R [BracketStep [i, 2]].ToString ();

		s__0 = MinusBefore + VariableBefore
			+ Bracket_L [BracketStep [i, 2]].ToString () + AllPartResultText
			+ Bracket_R [BracketStep [i, 2]].ToString ();


		if (CountOfExcessCommas>0) { // Если есть лишние запятые у переменной со скобками
			s__1 = MinusBefore + VariableBefore
				+ Bracket_L [BracketStep [i, 2]].ToString () + sActions2
				+ Bracket_R [BracketStep [i, 2]].ToString ();
			if (sActions2 != AllPartResultText) {		
				s__0 = s__1 + " = " + s__0;
			}
		}

		sActions = sActions+TextMainBracket+(i+1).ToString() + ": " + s__0 + " = "
			+ BracketStep_N [i] + System.Environment.NewLine;

		BracketStep_T[i] = s__0;

		if (AllActions[CountOfActions,0] < 5) { // Если обычное действие // Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой"
		} else { // Если скобки или переменная со скобками // Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой"
			int Pp__0 = -1; // Знак левой переменной или скобок "в дополненном тексте"
			int Pp_0 = 0; // Левая скобка, переменная (левая позиция) "в дополненном тексте"
			//int Pp_1 = 0; // Левая скобка, переменная (правая позиция) "в дополненном тексте"
			//int Pp_2 = 0; // Правая скобка (левая позиция) "в дополненном тексте"
			int Pp_3 = 0; // Правая скобка (правая позиция) "в дополненном тексте"
			int Pp__0M = -1; // Знак левой переменной или скобок "в основном тексте"
			int Pp_0M = 0; // Левая скобка, переменная (левая позиция) "в основном тексте"
			//int Pp_1M = 0; // Левая скобка, переменная (правая позиция) "в основном тексте"
			//int Pp_2M = 0; // Правая скобка (левая позиция) "в основном тексте"
			int Pp_3M = 0; // Правая скобка (правая позиция) "в основном тексте"

			if (AllActions[CountOfActions,1] > -1) { // Если у левого числа, переменной или скобок есть знак "+", "-"
				Pp__0 = AllSymbols1 [AllActions[CountOfActions,1], 0]; // Знак левого числа, переменной или скобок "в дополненном тексте"
				Pp__0M = AllSymbols1 [AllActions[CountOfActions,1], 3]; // Знак левого числа, переменной или скобок "в основном тексте"
			}

			//if (AllActions[CountOfActions,0] < 5) { // Если обычное действие // Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой"
			if (AllActions[CountOfActions,2] == 3) { // Если переменная со скобкой
				Pp_0 = AllVariables1 [AllActions[CountOfActions,3], 0];	
				Pp_0M = AllVariables1 [AllActions[CountOfActions,3], 6];	
				//Pp_1 = AllVariables1 [AllActions[CountOfActions,3], 1];
				//Pp_1M = AllVariables1 [AllActions[CountOfActions,3], 7];
			} else if (AllActions[CountOfActions,2] == 2) { // Если скобки
				Pp_0 = BracketStep [AllActions[CountOfActions,3], 0];
				Pp_0M = BracketStep [AllActions[CountOfActions,3], 8];
				//Pp_1 = BracketStep [AllActions[CountOfActions,3], 0];
				//Pp_1M = BracketStep [AllActions[CountOfActions,3], 8];
			}

			//Pp_2 = BracketStep [AllActions[CountOfActions,9], 0];
			//Pp_2M = BracketStep [AllActions[CountOfActions,9], 8];
			Pp_3 = BracketStep [AllActions[CountOfActions,9], 1];
			Pp_3M = BracketStep [AllActions[CountOfActions,9], 9];

			if (Pp__0 == -1) { // Если нет знака перед левой, переменной или скобками
				if (Pp_3 > Pp_0) {
					AllActions[CountOfActions,10] = Pp_0; // 10= левая позиция в дополненном тексте
					AllActions[CountOfActions,11] = Pp_3; // 11= правая позиция в допоненном тексте
					AllActions[CountOfActions,12] = -1; // 12= позиция знака в дополненном тексте
					AllActions[CountOfActions,13] = Pp_0M; // 13= левая позиция в основном тексте
					AllActions[CountOfActions,14] = Pp_3M; // 14= правая позиция в основном тексте
					AllActions[CountOfActions,15] = -1; // 15= позиция знака в основном тексте
					AllActions_T[CountOfActions] = s__0; // Текст с действием
					/*print (s__0 + System.Environment.NewLine
						+ CountOfActions + ":1# "
						+ AllActions[CountOfActions,2]+" # "
						+ stext.Substring (Pp_0, Pp_3 - Pp_0 + 1)
						+" = "+AllActions_N[CountOfActions,2]);*/

					CountOfActions = CountOfActions + 1; // Количество всех действий
					//AllActionSave1 = true; // true - сохранить действия в строку "sAllActions"
				}
			} else { // Если есть знак перед левой, переменной или скобками
				if (Pp_3 > Pp__0) {
					AllActions[CountOfActions,10] = Pp_0; // 10= левая позиция в дополненном тексте
					AllActions[CountOfActions,11] = Pp_3; // 11= правая позиция в допоненном тексте
					AllActions[CountOfActions,12] = Pp__0; // 12= позиция знака в дополненном тексте
					AllActions[CountOfActions,13] = Pp_0M; // 13= левая позиция в основном тексте
					AllActions[CountOfActions,14] = Pp_3M; // 14= правая позиция в основном тексте
					AllActions[CountOfActions,15] = Pp__0M; // 15= позиция знака в основном тексте
					AllActions_T[CountOfActions] = s__0; // Текст с действием
					/*print (s__0 + System.Environment.NewLine
						+ CountOfActions + ":2# " 
						+ AllActions[CountOfActions,2]+" # "
						+ stext.Substring (Pp__0, Pp_3 - Pp__0 + 1)
						+" = "+AllActions_N[CountOfActions,2]);*/

					CountOfActions = CountOfActions + 1; // Количество всех действий
					//AllActionSave1 = true; // true - сохранить действия в строку "sAllActions"
				}
			}

			/*if (AllActionSave1 == true) { // true - сохранить действия в строку "sAllActions"								
				sAllActions = sAllActions
					+ AllActions[CountOfActions-1,0].ToString () + ";"
					+ AllActions[CountOfActions-1,1].ToString () + ";"
					+ AllActions[CountOfActions-1,2].ToString () + ";"
					+ AllActions[CountOfActions-1,3].ToString () + ";"
					+ AllActions[CountOfActions-1,4].ToString () + ";"
					+ AllActions[CountOfActions-1,5].ToString () + ";"
					+ AllActions[CountOfActions-1,6].ToString () + ";"
					+ AllActions[CountOfActions-1,7].ToString () + ";"
					+ AllActions[CountOfActions-1,8].ToString () + ";"
					+ AllActions[CountOfActions-1,9].ToString () + ";"
					+ AllActions_N[CountOfActions-1,0].ToString () + ";"
					+ AllActions_N[CountOfActions-1,1].ToString () + ";"
					+ AllActions_N[CountOfActions-1,2].ToString () + "|";
				AllActionSave1 = false; // true - сохранить действия в строку "sAllActions"							
			}*/
		}
		///////////////////////////////////////////////////////////////////////////
	}
}

//print (sAllActions);
//print ((CountBracket+CountOfSymbols1-CountOfCommas1-CountOfUnActSymbols1));
//CountOfUnActSymbols = CountOfUnActSymbols+1; // Количество знаков меняющих значение числа, скобки переменной




// Убрать пробелы из формулы с дополненным текстом ///////////////////////////////////////////////////////////////

if ((FindResultOnly == false)  // false - будет изменен текст и сопутствующие позиции, true - текст и позиции не меняются
	& (CleanSpaces == true)) { // false - оставить пробелы в тексте как есть, true - убрать из текста лишние пробелы
// s1 - текст с формулой
   // sClean - текст с исправленной формулой
   // stext - текст с формулой, дополнено скобками
   // sActions - текст, каждое действие с новой строки
   // sTextProperty - массив (основной, дополненный) текст, со свойствами формулы (5+RGB*2) = (№+...+№)
   // AllSymbols1 = массив со знаками. [ порядковый номер знака в тексте , 0..3 ]; // 0-Позиция знака. 1-Тип знака  0=+, 1=-, 2=*, 3=/, 4=^. 2-0=обычный знак, 1=знак меняющий результат, 3-первоначальная позиция знака
   // CountOfSymbols1 - количество знаков
   // CountOfUnActSymbols1 - количество знаков меняющих значение числа, скобки переменной
   // CountOfCommas1 - количество запятых
   // AllNumbers1 = массив с числами. [ порядковый номер числа в тексте , 0..5 ]; // 0-левая позиция, 1-правая позиция переменной, 2-порядковый номер знака в массиве "AllSymbols1", если перед числом есть знак меняющий результат "+","-" (-1=если перед числом нет знака "+","-"), 3- -3=обычный знак "-" перед числом, -2=обычный знак "+" перед числом, -1=нет меняющего знака перед числом, 0=плюс перед числом, 1=минус перед числом, 4-первоначальная левая позиция, 5-первоначальная правая позиция числа
   // CountOfNumbers1 - количество чисел
   // AllVariables1 - массив с переменными. [ порядковый номер переменной в тексте , 0..8 ]; // 0-левая позиция, 1-правая позиция переменной, 2-номер скобки в массиве "BracketStep2" (-1) если нет скобок, 3-"в конце процедуры изменено значение на": позиция знака перед скобкой, 4- -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной, 5-номер переменной в массиве "NameVariables1", 6-первоначальная позиция левой переменной, 7-первоначальная позиция правой переменной, 8-первоначальная позиция знака перед переменной  
   // CountOfVariables1 - количество переменных в тексте
   // AllVariables_N - массив с результатами переменных. [ порядковый номер переменной в тексте ]; // Чему равна переменная
   // BracketStep - массив с позициями скобок. [ порядковый номер пар скобок , 0..12 ]; // 0-позиция левой скобки, 1-позиция правой скобки, 2-тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные), 3-позиция знака перед скобкой, 4- -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой, 5- номер переменной "AllVariables1" для данных скобок (-1 если нет переменной), 6-кол-во запятых внутри выбранных скобок, 7-к какой скобке относится эта часть (-1=не связано с запятыми), 8-первоначальная позиция левой скобки, 9-первоначальная позиция правой скобки, 10-первоначальная позиция знака перед собкой, 11-Если дополненная скобка, то номер первоначальной скобки в которой находится данная скобка, иначе -1, 12-номер скобки в которой находится данная скобка, 13-номер действия в массиве "AllActions"
   // CountBracket - количество пар скобок
   // CountAddBracket - количество добавленных пар скобок
   // BracketStep_N - массив с результатами в скобках. [ порядковый номер пар скобок ]; // Чему равны действия в скобках
   // BracketStep_T - массив с текстом действий в скобках. [ порядковый номер пар скобок ]; // Текст с действием в скобках
   // AllActions - массив с позициями действий в тексте. [ порядковый номер действия, 0..15 ]; // 0= Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой", 1= Порядковый номер левого знака (-1 если нет знака), 2= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 3= Порядковый номер левого числа, переменной, или скобок (образует диапазон от), 4= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 5= Порядковый номер левого числа, переменной, или скобок (образует диапазон до), 6= Порядковый номер знака, 7= Порядковый номер правого знака (-1 если нет знака), 8= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 9= Порядковый номер правого числа, переменной, или скобок, 10= левая позиция в дополненном тексте, 11= правая позиция в допоненном тексте, 12= позиция знака в дополненном тексте, 13= левая позиция в основном тексте, 14= правая позиция в основном тексте, 15= позиция знака в основном тексте
   // CountOfActions - количество всех действий
   // AllActions_N - массив с результатами действий. [ порядковый номер действия, 0..2 ]; // 0= Результат левого числа, переменной или скобки действия, 1= Результат правого числа, переменной или скобки действия, 2= Результат выполненного действия
   // AllActions_T - массив с текстом действий. [ порядковый номер действия ]; // Текст с действием


//string sCleanCopy = sClean;
//string sCleanVariableCopy = sCleanVariable;
//string sTextCopy = stext;
//string sVariableCopy = sVariable;

	/*char[] sCleanCopy = new char[sClean.Length];
	sCleanCopy = sClean.ToCharArray();
	char[] sCleanVariableCopy = new char[sCleanVariable.Length];
	sCleanVariableCopy = sCleanVariable.ToCharArray();
	char[] sTextCopy = new char[stext.Length];
	sTextCopy = stext.ToCharArray();
	char[] sVariableCopy = new char[sVariable.Length];
	sVariableCopy = sVariable.ToCharArray();*/

	//print ("-1: "+stext.Length+"\n"+sVariable.Length);
	// Основной текст
	//print ("0: "+sClean+"\n"+sCleanVariable+"\n"+stext+"\n"+sVariable);
	int i1 = 0;
	int k1 = 0;

			if (ChangeMainFormula == true) { // true - менять основную формулу и её позиции

				while (i1 <= sCleanVariable.Length - 1) {
					if (sCleanVariable [i1] == " ".ToCharArray () [0]) {
						sClean = sClean.Remove (i1, 1);
						sCleanVariable = sCleanVariable.Remove (i1, 1);	

						// Сдвинуть массив "AllSymbols1"
						for (k1 = 0; k1 <= CountOfSymbols1 - 1; k1++) {
							if (i1 < AllSymbols1 [k1, 3]) { // 3-первоначальная позиция знака
								AllSymbols1 [k1, 3] = AllSymbols1 [k1, 3] - 1;
							}
						}

						
						// Сдвинуть массив "AllNumbers1"
						for (k1 = 0; k1 <= CountOfNumbers1 - 1; k1++) {
							if (i1 < AllNumbers1 [k1, 4]) { // 4-первоначальная левая позиция, 5-первоначальная правая позиция числа
								AllNumbers1 [k1, 4] = AllNumbers1 [k1, 4] - 1;	
								AllNumbers1 [k1, 5] = AllNumbers1 [k1, 5] - 1;		
							}
							//if (i1 < AllNumbers1 [k1, 5]) { // 5-первоначальная правая позиция числа
							//	AllNumbers1 [k1, 5] = AllNumbers1 [k1, 5] - 1;		
							//}
						}
				

						// Сдвинуть массив "AllVariables1"
						for (k1 = 0; k1 <= CountOfVariables1 - 1; k1++) {
							if (i1 < AllVariables1 [k1, 8]) { // 8-первоначальная позиция знака перед переменной 					
								AllVariables1 [k1, 8] = AllVariables1 [k1, 8] - 1;		
							}
							if (i1 < AllVariables1 [k1, 6]) { // 6-первоначальная позиция левой переменной, 7-первоначальная позиция правой переменной
								AllVariables1 [k1, 6] = AllVariables1 [k1, 6] - 1;	
								AllVariables1 [k1, 7] = AllVariables1 [k1, 7] - 1;		
							}
							//if (i1 < AllVariables1 [k1, 7]) { // 7-первоначальная позиция правой переменной
							//	AllVariables1 [k1, 7] = AllVariables1 [k1, 7] - 1;		
							//}
						}


						// Сдвинуть массив "BracketStep"
						for (k1 = 0; k1 <= CountBracket - 1; k1++) {
							if (i1 < BracketStep [k1, 10]) { // 10-первоначальная позиция знака перед собкой
								BracketStep [k1, 10] = BracketStep [k1, 10] - 1;		
							}
							if (i1 < BracketStep [k1, 8]) { // 8-первоначальная позиция левой скобки
								BracketStep [k1, 8] = BracketStep [k1, 8] - 1;	
							}
							if (i1 < BracketStep [k1, 9]) { // 9-первоначальная позиция правой скобки
								BracketStep [k1, 9] = BracketStep [k1, 9] - 1;		
							}
						}

						// AllActions - массив с позициями действий в тексте. [ порядковый номер действия, 0..15 ]; // 0= Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой", 1= Порядковый номер левого знака (-1 если нет знака), 2= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 3= Порядковый номер левого числа, переменной, или скобок (образует диапазон от), 4= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 5= Порядковый номер левого числа, переменной, или скобок (образует диапазон до), 6= Порядковый номер знака, 7= Порядковый номер правого знака (-1 если нет знака), 8= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 9= Порядковый номер правого числа, переменной, или скобок, 10= левая позиция в дополненном тексте, 11= правая позиция в допоненном тексте, 12= позиция знака в дополненном тексте, 13= левая позиция в основном тексте, 14= правая позиция в основном тексте, 15= позиция знака в основном тексте
						// CountOfActions - количество всех действий

						// Сдвинуть массив "AllActions"
						for (k1 = 0; k1 <= CountOfActions - 1; k1++) {
							if (i1 < AllActions [k1, 15]) { // 15= позиция знака в основном тексте
								AllActions [k1, 15] = AllActions [k1, 15] - 1;		
							}
							if (i1 < AllActions [k1, 13]) { // 13= левая позиция в основном тексте
								AllActions [k1, 13] = AllActions [k1, 13] - 1;			
							}
							if (i1 < AllActions [k1, 14]) { // 14= правая позиция в основном тексте
								AllActions [k1, 14] = AllActions [k1, 14] - 1;		
							}
						}


						i1 = i1 - 1;
					}
					i1 = i1 + 1;
				}
			}

	// Дополненный текст
	//for (int i = 0; i <= sClean.Length - 1; i++) {	
	i1 = 0;
	while (i1<=sVariable.Length - 1) {
		if (sVariable[i1] == " ".ToCharArray()[0]) {
			stext = stext.Remove (i1,1);
			sVariable = sVariable.Remove (i1,1);	


			// Сдвинуть массив "AllSymbols1"
			for (k1 = 0; k1 <= CountOfSymbols1-1; k1++) {
				if (i1 < AllSymbols1 [k1, 0]) { // 0-Позиция знака
					AllSymbols1 [k1, 0] = AllSymbols1 [k1, 0] - 1;
				}
			}
				

				
			// Сдвинуть массив "AllNumbers1"
			for (k1 = 0; k1 <= CountOfNumbers1-1; k1++) {
				if (i1 < AllNumbers1 [k1, 0]) { // 0-левая позиция числа, 1-правая позиция числа
					AllNumbers1 [k1, 0] = AllNumbers1 [k1, 0] - 1;	
					AllNumbers1 [k1, 1] = AllNumbers1 [k1, 1] - 1;	
				}
				//if (i1 < AllNumbers1 [k1, 1]) { // 1-правая позиция переменной
				//	AllNumbers1 [k1, 1] = AllNumbers1 [k1, 1] - 1;		
				//}
			}
						

			// Сдвинуть массив "AllVariables1"
			for (k1 = 0; k1 <= CountOfVariables1-1; k1++) {
				if (i1 < AllVariables1 [k1, 3]) { // 3-"в конце процедуры изменено значение на": позиция знака перед скобкой
					AllVariables1 [k1, 3] = AllVariables1 [k1, 3] - 1;		
				}
				if (i1 < AllVariables1 [k1, 0]) { // 0-левая позиция переменной, 1-правая позиция переменной
					AllVariables1 [k1, 0] = AllVariables1 [k1, 0] - 1;	
					AllVariables1 [k1, 1] = AllVariables1 [k1, 1] - 1;		
				}
				//if (i1 < AllVariables1 [k1, 1]) { // 1-правая позиция переменной
				//	AllVariables1 [k1, 1] = AllVariables1 [k1, 1] - 1;		
				//}
			}


			// Сдвинуть массив "BracketStep"
			for (k1 = 0; k1 <= CountBracket-1; k1++) {
				if (i1 < BracketStep [k1, 3]) { // 3-позиция знака перед скобкой
					BracketStep [k1, 3] = BracketStep [k1, 3] - 1;		
				}
				if (i1 < BracketStep [k1, 0]) { // 0-позиция левой скобки
					BracketStep [k1, 0] = BracketStep [k1, 0] - 1;		
				}
				if (i1 < BracketStep [k1, 1]) { // 1-позиция правой скобки
					BracketStep [k1, 1] = BracketStep [k1, 1] - 1;		
				}
			}

			// Сдвинуть массив "AllActions"
			for (k1 = 0; k1 <= CountOfActions-1; k1++) {
				if (i1 < AllActions [k1, 12]) { // 12= позиция знака в дополненном тексте
					AllActions [k1, 12] = AllActions [k1, 12] - 1;		
				}
				if (i1 < AllActions [k1, 10]) { // 10= левая позиция в дополненном тексте
					AllActions [k1, 10] = AllActions [k1, 10] - 1;			
				}
				if (i1 < AllActions [k1, 11]) { // 11= правая позиция в допоненном тексте
					AllActions [k1, 11] = AllActions [k1, 11] - 1;		
				}
			}

			i1 = i1-1;
		}
		i1 = i1 + 1;
	}

	//print ("1: "+sClean+"\n"+sCleanVariable+"\n"+stext+"\n"+sVariable);
}


// Установить пред каждой переменной или скобками знаки, + или -

// Сохранить действия в массив "BracketStep_text"  ///////////////////////////////////////////////////////////////
// 0-текст без скобок (числа вместо переменных), 
// 1-доп. текст без скобок (числа вместо переменных),
// 2-знак перед скобками "+" или "-",
// 3-результат действий



/*for (int i = 0; i <= CountBracket2_4 - 1; i++) {	
	if (BracketStep2 [i, 2] == 4) {
		print (i + "D: " + BracketStep2 [i, 2] + " | "
			+ stext.Substring (BracketStep2 [i, 0],
				BracketStep2 [i, 1] - BracketStep2 [i, 0]+1));		
	}
}*/

/*for (int i = 0; i <= CountBracket2_2 - 1; i++) {			
//if (Bracket3 [Bracket3_r [i, 0], 1] == 1) {
print (i + ":  "
	+ stext.Substring (Bracket3 [Bracket3_r [i, 0], 0] + 1,
		Bracket3 [Bracket3_r [i, 1], 0] - Bracket3 [Bracket3_r [i, 0], 0] - 1));		
//}
}*/			

// Проверить скобки /////////////////////////////////////////
/*for (int i = 0; i <= CountBracket2_3 - 1; i++) {			
if (BracketStep2 [i, 5] > -1) {
	print (i + ": "
		+ stext.Substring (AllSymbols1 [BracketStep2 [i, 5], 0],
			BracketStep2 [i, 1] - AllSymbols1 [BracketStep2 [i, 5], 0]+1));		
}
else
	print (i + ":  "
		+ stext.Substring (BracketStep2 [i, 0],
			BracketStep2 [i, 1] - BracketStep2 [i, 0]+1));		
}*/	

/*
int CountOfNumbers,CountOfSignes,textnumber1;
bool BoolTryParse;

CountOfNumbers = 0;
for (int i = 0; i <= stext.Length-1; i++) {
	// Найти цифру
	BoolTryParse = int.TryParse(s[i], out textnumber1); 
	if (!BoolTryParse) textnumber1 = -1;
	if (textnumber1>-1) { // Если цифра
		CountOfNumbers = CountOfNumbers+1;
	}
	else
	{				
		if (CountOfNumbers > 0) { // Сформировать число из цифр
			CountOfNumbers = 0;
		}
	}

}

int[] StepWhatAsign; */

sActions = BracketStep_N [CountBracket-1].ToString () 
	+ System.Environment.NewLine+sActions;

sTextProperty = new string[2];
sTextProperty[0] = sCleanVariable; // основной текст, со свойствами формулы (5+RGB*2) = (№+...+№)
sTextProperty[1] = sVariable; // дополненный текст, со свойствами формулы (5+RGB*2) = (№+...+№)

FindResultOnly = false; // false - будет изменен текст и сопутствующие позиции, true - текст и позиции не меняются
//print (sActions);


return BracketStep_N [CountBracket-1];
}

public static bool AddVariables () { // Добавить стандартные переменные
	NameVariables1 [CountVariables,0] = "Abs";
	NameVariables1 [CountVariables + 1,0] = "Floor";
	NameVariables1 [CountVariables + 2,0] = "Ceil";
	NameVariables1 [CountVariables + 3,0] = "Round";

	for (int i = 0; i <= (CountVariables+CountVariables2)-1; i++) {
		NameVariables1[i,1] = NameVariables1[i,0].ToUpper(); // Название переменной в верхнем регистре
	}
	return true;
}

public static float FindVariables (int NumOfVariable, int CountOfNumber_1, float[] Number_1) { // Найти значение стандартной переменной

	if (NumOfVariable == CountVariables) { // Если "Abs"		
		return Mathf.Abs (Number_1[0]); // Модуль числа
	} else if (NumOfVariable == CountVariables + 1) { // Если "Floor"
		return Mathf.Floor (Number_1[0]); // Округлить к меньшему
	} else if (NumOfVariable == CountVariables + 2) { // Если "Ceil"
		return Mathf.Ceil (Number_1[0]); // Округлить к большему
	} else if (NumOfVariable == CountVariables + 3) { // Если "Round"
		return Mathf.Round (Number_1[0]); // Округлить к ближайшему
	}
	return ResultVariables1[NumOfVariable,0];
}

public static float FindMyVariables (int NumOfVariable, int CountOfNumber_1, float[] Number_1) { // Найти значение своей переменной ()
	string [] WhatToCompare = new string[2];
	WhatToCompare[0] = "Gg1".ToUpper();
	WhatToCompare[1] = "K+Jf".ToUpper();

	if (NameVariables1[NumOfVariable,1] == WhatToCompare[0]) { // Если "Gg1"
		//ResultVariables1[NumOfVariable,1] = 2; // Кол-во действий в скобках для переменной
		if (CountOfNumber_1 >= ResultVariables1 [NumOfVariable, 1] & 
			(Number_1.Length>=2)) { // Если кол-во значений совпадает
			return (Number_1 [0] * 2 - Number_1 [1]);
		} else  // Если кол-ва значений недостаточно
			return (Number_1 [0]);

	} else if (NameVariables1[NumOfVariable,1] == WhatToCompare[1]) { // Если "K+Jf"
		//ResultVariables1[NumOfVariable,1] = 2; // Кол-во действий в скобках для переменной
		if ((CountOfNumber_1 >= ResultVariables1 [NumOfVariable, 1]) & 
			(Number_1.Length>=2)) { // Если кол-во значений совпадает
			return (Number_1 [0] + Number_1 [1]);
		} else  // Если кол-ва значений недостаточно
			return (Number_1 [0]);
	}
	return ResultVariables1 [NumOfVariable, 0];
}
}