﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System; // Для изменения размеров многомерного массива
using UnityEngine.EventSystems; // Чтобы узнать какой объект активен
using System.IO; // Используем библиотеку ввода вывода
using System.Text.RegularExpressions; // Для работы с текстом "Regex.Replace"

public class Formula1_Properties : MonoBehaviour
{
	// Для решения формул: /////////////////////////////////////////////////
	//private string Text_Formula = "((((1+1)*-2)*3)/4)+5"; // текст с формулой
	[HideInInspector]
	public string Text_Formula = "(+AbsG(---(R+|B|^+2)-(-2*-|G[R]|)"
		+ "+-+-RoundB[+-+-K+Jf[-(10+5/2.3)+R,-(10+5/2.3)-5,-(10+5/2.3)+5]*2])+(|-B/2-R*-2|)*4+|"
		+ "-+-Gg1R[-1.5,-2]|)"; // текст с формулой
	//private string Text_Formula = "5+(-(4+2)+3*2)-(-4/8)^2"; // текст с формулой	
	[HideInInspector]
	public string Text_Formula2 = " "; // *Не обязательно* Отображаемый текст "Text_Formula", с выбранным действием
	[HideInInspector]
	public string Text_Formula_ch = " "; // текст с формулой, дополнено скобками
	[HideInInspector]
	public string Text_Formula_ch2 = " "; // *Не обязательно* Отображаемый текст "Text_Formula_ch", с выбранным действием
	[HideInInspector]
	public string Text_Action = " "; // текст, каждое действие с новой строки
	[HideInInspector]
	public string[] Text_Property; // массив (основной, дополненный) текст, со свойствами формулы (5+RGB*2) = (№+...+№)
	[HideInInspector]
	public int[,] AllSymbols1; // массив со знаками. [ порядковый номер знака в тексте , 0..3 ]; // 0-Позиция знака. 1-Тип знака  0=+, 1=-, 2=*, 3=/, 4=^. 2-0=обычный знак, 1=знак меняющий результат, 3-первоначальная позиция знака
	[HideInInspector]
	public int CountOfSymbols1 = 0; // количество знаков
	[HideInInspector]
	public int CountOfUnActSymbols1 = 0; // количество знаков меняющих значение числа, скобки переменной
	[HideInInspector]
	public int CountOfCommas1 = 0; // количество запятых
	[HideInInspector]
	public int[,] AllNumbers1; // массив с числами. [ порядковый номер числа в тексте , 0..5 ]; // 0-левая позиция, 1-правая позиция числа, 2-порядковый номер знака в массиве "AllSymbols1", если перед числом есть знак меняющий результат "+","-" (-1=если перед числом нет знака "+","-"), 3- -3=обычный знак "-" перед числом, -2=обычный знак "+" перед числом, -1=нет меняющего знака перед числом, 0=плюс перед числом, 1=минус перед числом, 4-первоначальная левая позиция, 5-первоначальная правая позиция числа
	[HideInInspector]
	public int CountOfNumbers1 = 0; // количество чисел
	[HideInInspector]
	public int[,] AllVariables1; // массив с переменными. [ порядковый номер переменной в тексте , 0..8 ]; // 0-левая позиция, 1-правая позиция переменной, 2-номер скобки в массиве "BracketStep" (-1) если нет скобок, 3-"в конце процедуры изменено значение на": позиция знака перед скобкой, 4- -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной, 5-номер переменной в массиве "NameVariables1", 6-первоначальная позиция левой переменной, 7-первоначальная позиция правой переменной, 8-первоначальная позиция знака перед переменной  
	[HideInInspector]
	public int CountOfVariables1 = 0; // количество переменных в тексте
	[HideInInspector]
	public float[] AllVariables_N; // массив с результатами переменных. [ порядковый номер переменной в тексте ]; // Чему равна переменная
	[HideInInspector]
	public int[,] BracketStep; // массив с позициями скобок. [ порядковый номер пар скобок , 0..12 ]; // 0-позиция левой скобки, 1-позиция правой скобки, 2-тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные), 3-позиция знака перед скобкой, 4- -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой, 5- номер переменной "AllVariables1" для данных скобок (-1 если нет переменной), 6-кол-во запятых внутри выбранных скобок, 7-к какой скобке относится эта часть (-1=не связано с запятыми), 8-первоначальная позиция левой скобки, 9-первоначальная позиция правой скобки, 10-первоначальная позиция знака перед собкой, 11-Если дополненная скобка, то номер первоначальной скобки в которой находится данная скобка, иначе -1, 12-номер скобки в которой находится данная скобка, 13-номер действия в массиве "AllActions"
	[HideInInspector]
	public int CountBracket = 0; // количество пар скобок
	[HideInInspector]
	public int CountAddBracket = 0; // количество добавленных пар скобок
	[HideInInspector]
	public float[] BracketStep_N; // массив с результатами в скобках. [ порядковый номер пар скобок ]; // Чему равны действия в скобках
	[HideInInspector]
	public string[] BracketStep_T; // массив с текстом действий в скобках. [ порядковый номер пар скобок ]; // Текст с действием в скобках
	[HideInInspector]
	public int[,] AllActions; // массив с позициями действий в тексте. [ порядковый номер действия, 0..15 ]; // 0= Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой", 1= Порядковый номер левого знака (-1 если нет знака), 2= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 3= Порядковый номер левого числа, переменной, или скобок (образует диапазон от), 4= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 5= Порядковый номер левого числа, переменной, или скобок (образует диапазон до), 6= Порядковый номер знака, 7= Порядковый номер правого знака (-1 если нет знака), 8= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 9= Порядковый номер правого числа, переменной, или скобок, 10= левая позиция в дополненном тексте, 11= правая позиция в допоненном тексте, 12= позиция знака в дополненном тексте, 13= левая позиция в основном тексте, 14= правая позиция в основном тексте, 15= позиция знака в основном тексте
	[HideInInspector]
	public int CountOfActions = 0; // количество всех действий
	[HideInInspector]
	public float[,] AllActions_N; // массив с результатами действий. [ порядковый номер действия, 0..2 ]; // 0= Результат левого числа, переменной или скобки действия, 1= Результат правого числа, переменной или скобки действия, 2= Результат выполненного действия
	[HideInInspector]
	public string[] AllActions_T; // массив с текстом действий. [ порядковый номер действия ]; // Текст с действием
	// AllActions - массив с позициями действий в тексте. [ порядковый номер действия ]; // 0= Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой", 1= Порядковый номер левого знака (-1 если нет знака), 2= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 3= Порядковый номер левого числа, переменной, или скобок (образует диапазон от), 4= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 5= Порядковый номер левого числа, переменной, или скобок (образует диапазон до), 6= Порядковый номер знака, 7= Порядковый номер правого знака (-1 если нет знака), 8= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 9= Порядковый номер правого числа, переменной, или скобок, 10= левая позиция в дополненном тексте, 11= правая позиция в допоненном тексте, 12= позиция знака в дополненном тексте, 13= левая позиция в основном тексте, 14= правая позиция в основном тексте, 15= позиция знака в основном тексте
	// CountOfActions - количество всех действий
	// AllActions_N - массив с результатами действий. [ порядковый номер действия ]; // 0= Результат левого числа, переменной или скобки действия, 1= Результат правого числа, переменной или скобки действия, 2= Результат выполненного действия
	// AllActions_T - массив с текстом действий в тексте. [ порядковый номер действия ]; // Текст с действием
	////////////////////////////////////////////////////////////////////////

	// Дополнительно
	public int[,] PosOfBracketAction; // Позиции действий в тексте "Text_Action"

	public ListView ListView1;
	[HideInInspector]
	public string[] NameOfActions = { "+ сложение", "- вычитание", "* умножение",
		"/ деление", "^ степень", "( круглая скобка", "| модульная скобка",
		"[ квадратная скобка", "{ фигурная скобка", "( доп. круглая скобка", 
		"переменная со скобкой" }; // Названия действий (0..10)


	void Start()
	{

	}
		
	public bool SolveFormulaProcedure() { // Решить формулу
		
		Text_Formula2 = ListView1.TextField_1 [0];

		Formula1.CleanVariables = ListView1.Show_Hide [5]; // true = Убирать из текста лишние символы

		Formula1.CleanSpaces = ListView1.Show_Hide [6]; // true = Убирать пробелы

		Formula1.ChangeMainFormula = ListView1.Show_Hide [4]; // true - Менять основную формулу

		if (ListView1.Show_Hide [7]==true) { // true - Учитывать регистр названия переменной
			Formula1.CheckRegistr = 0; // 0 - учитывать (A<>a, B=B), 1 - не учитывать (A=a, B=B) регистр символов
		} else {
			Formula1.CheckRegistr = 1; // 0 - учитывать (A<>a, B=B), 1 - не учитывать (A=a, B=B) регистр символов
		}
			
		string sClean = ""; // текст с исправленной формулой

		Formula1.SolveFormula (Text_Formula2 
			, out sClean
			, out Text_Formula_ch, out Text_Action, out Text_Property
			, out AllSymbols1, out CountOfSymbols1
			, out CountOfUnActSymbols1, out CountOfCommas1
			, out AllNumbers1, out CountOfNumbers1
			, out AllVariables1, out CountOfVariables1
			, out AllVariables_N
			, out BracketStep, out CountBracket, out CountAddBracket
			, out BracketStep_N
			, out BracketStep_T
			, out AllActions, out CountOfActions
			, out AllActions_N
			, out AllActions_T); // Решить формулу из текста	

		if (ListView1.Show_Hide [4] == true) { // true - Менять основную формулу
			Text_Formula = sClean;
			Text_Formula2 = sClean;
			ListView1.TextField_1 [0] = sClean;
		}			
			
		Text_Formula = Text_Formula2; // *Не обязательно*
		Text_Formula_ch2 = Text_Formula_ch; // *Не обязательно*

		ShowPosInBracketAction (); // Определить позиции действий "PosOfBracketAction" в тексте "Text_Action"

		ListView1.TextField_1 [0] = Text_Formula;
		ListView1.TextField_1 [1] = Text_Formula_ch;
		ListView1.TextField_1 [2] = Text_Action;

		ListView1.ChangeRowsInTable (1, CountOfActions); // Поменять количество рядов "CountRows1", в таблице "LViewSelected1"	

		MakeTextWithActions (); // Собрать массив с текстом из "AllActions"
		ListView1.AddActionsInTable2 (); // Добавить массив с текстом действий в формате уменьшения основной формулы в таблицу

		ListView1.ChangeHeightOfTF (0, Text_Formula); // Поменять размер текстового поля "TFSelected1", под текст "TextInField1"
		ListView1.ChangeHeightOfTF (1, Text_Formula_ch); // Поменять размер текстового поля "TFSelected1", под текст "TextInField1"	
		ListView1.ChangeHeightOfTF (2, Text_Action); // Поменять размер текстового поля "TFSelected1", под текст "TextInField1"

		return true;
	}
		

	[HideInInspector]
	public int[,] changed_AllActions; // массив с позициями действий в тексте. [ порядковый номер действия, 0..15 ]; // 0= Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой", 1= Порядковый номер левого знака (-1 если нет знака), 2= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 3= Порядковый номер левого числа, переменной, или скобок (образует диапазон от), 4= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 5= Порядковый номер левого числа, переменной, или скобок (образует диапазон до), 6= Порядковый номер знака, 7= Порядковый номер правого знака (-1 если нет знака), 8= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 9= Порядковый номер правого числа, переменной, или скобок, 10= левая позиция в дополненном тексте, 11= правая позиция в допоненном тексте, 12= позиция знака в дополненном тексте, 13= левая позиция в основном тексте, 14= правая позиция в основном тексте, 15= позиция знака в основном тексте
	[HideInInspector]
	public int[,] changed_AllVariables1; // массив с переменными. [ порядковый номер переменной в тексте , 0..8 ]; // 0-левая позиция, 1-правая позиция переменной, 2-номер скобки в массиве "BracketStep" (-1) если нет скобок, 3-"в конце процедуры изменено значение на": позиция знака перед скобкой, 4- -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной, 5-номер переменной в массиве "NameVariables1", 6-первоначальная позиция левой переменной, 7-первоначальная позиция правой переменной, 8-первоначальная позиция знака перед переменной  
	[HideInInspector]
	public int[,] changed_BracketStep; // массив с позициями скобок. [ порядковый номер пар скобок , 0..12 ]; // 0-позиция левой скобки, 1-позиция правой скобки, 2-тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные), 3-позиция знака перед скобкой, 4- -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой, 5- номер переменной "AllVariables1" для данных скобок (-1 если нет переменной), 6-кол-во запятых внутри выбранных скобок, 7-к какой скобке относится эта часть (-1=не связано с запятыми), 8-первоначальная позиция левой скобки, 9-первоначальная позиция правой скобки, 10-первоначальная позиция знака перед собкой, 11-Если дополненная скобка, то номер первоначальной скобки в которой находится данная скобка, иначе -1, 12-номер скобки в которой находится данная скобка, 13-номер действия в массиве "AllActions"
	[HideInInspector]
	public string[] AllActionsPlus1; // массив с текстом действий в формате уменьшения основной формулы
	[HideInInspector]
	public int[,] AllPosPlus1; // позиции действий в массиве "AllActionsPlus1"
	[HideInInspector]
	public int[] MaxLengthOfText; // максимальная длина одного из текстов массива "AllActionsPlus1"

	public bool MakeTextWithActions ()
	{ // Собрать массив с текстом из "AllActions"


		changed_AllActions = new int[CountOfActions,16];
		for (int k1 = 0; k1 < CountOfActions; k1++) {
			for (int k2 = 0; k2 < 16; k2++) {
				changed_AllActions[k1,k2] = AllActions[k1,k2]; // массив с позициями действий в тексте. [ порядковый номер действия, 0..15 ]; // 0= Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой", 1= Порядковый номер левого знака (-1 если нет знака), 2= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 3= Порядковый номер левого числа, переменной, или скобок (образует диапазон от), 4= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 5= Порядковый номер левого числа, переменной, или скобок (образует диапазон до), 6= Порядковый номер знака, 7= Порядковый номер правого знака (-1 если нет знака), 8= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 9= Порядковый номер правого числа, переменной, или скобок, 10= левая позиция в дополненном тексте, 11= правая позиция в допоненном тексте, 12= позиция знака в дополненном тексте, 13= левая позиция в основном тексте, 14= правая позиция в основном тексте, 15= позиция знака в основном тексте
			}
		}

		changed_AllVariables1 = new int[CountOfVariables1,9];
		for (int k1 = 0; k1 < CountOfVariables1; k1++) {
			for (int k2 = 0; k2 < 9; k2++) {
				changed_AllVariables1[k1,k2] = AllVariables1[k1,k2]; // массив с переменными. [ порядковый номер переменной в тексте , 0..8 ]; // 0-левая позиция, 1-правая позиция переменной, 2-номер скобки в массиве "BracketStep" (-1) если нет скобок, 3-"в конце процедуры изменено значение на": позиция знака перед скобкой, 4- -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной, 5-номер переменной в массиве "NameVariables1", 6-первоначальная позиция левой переменной, 7-первоначальная позиция правой переменной, 8-первоначальная позиция знака перед переменной  
			}
		}
			
		changed_BracketStep = new int[CountBracket,14];
		for (int k1 = 0; k1 < CountBracket; k1++) {
			for (int k2 = 0; k2 < 14; k2++) {
				changed_BracketStep[k1,k2] = BracketStep[k1,k2]; // массив с позициями скобок. [ порядковый номер пар скобок , 0..12 ]; // 0-позиция левой скобки, 1-позиция правой скобки, 2-тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные), 3-позиция знака перед скобкой, 4- -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой, 5- номер переменной "AllVariables1" для данных скобок (-1 если нет переменной), 6-кол-во запятых внутри выбранных скобок, 7-к какой скобке относится эта часть (-1=не связано с запятыми), 8-первоначальная позиция левой скобки, 9-первоначальная позиция правой скобки, 10-первоначальная позиция знака перед собкой, 11-Если дополненная скобка, то номер первоначальной скобки в которой находится данная скобка, иначе -1, 12-номер скобки в которой находится данная скобка, 13-номер действия в массиве "AllActions"
			}
		}
			
		AllActionsPlus1 = new string[CountOfActions+1];
		AllPosPlus1 = new int[CountOfActions+1,5];
		MaxLengthOfText = new int[2]; // максимальная длина одного из текстов массива "AllActionsPlus1"
		MaxLengthOfText[0] = -1; // максимальная длина одного из текстов массива "AllActionsPlus1"
		MaxLengthOfText[1] = -1; // номер одного из текстов массива "AllActionsPlus1"


		int[] PosInText = new int[5];
		//Vector2 posTextField1 = new Vector2 (0, 0);
		//Vector2 posTextField2 = new Vector2 (0, 0);
		int Length1 = 0;
		//int NewLine1 = 0;
		int NewLine2 = 0;
		float NewResult1 = 0;
		AllActionsPlus1 [0] = Text_Formula_ch;
		AllActionsPlus1 [1] = Text_Formula_ch;


		PosInText = ChangeShowPosInText_Action (0); // Определить позицию действий в тексте "TextField_1[0..1]" (от 0 до (CountBracket-1))	
		Length1 = PosInText [4]-PosInText [3]+1;
		//NewLine1 = AllActionsPlus1 [0].Length+1;
		NewLine2 = AllActionsPlus1 [0].Length+1;

		AllPosPlus1[0,0] = 0;
		AllPosPlus1[0,1] = 0;
		AllPosPlus1[0,2] = 0;
		AllPosPlus1[0,3] = PosInText [3];
		AllPosPlus1[0,4] = AllPosPlus1[0,3]+Length1;

		if (AllActionsPlus1 [0].Length>MaxLengthOfText[0]) {
			MaxLengthOfText[0] = AllActionsPlus1 [0].Length; // максимальная длина одного из текстов массива "AllActionsPlus1"
			MaxLengthOfText[1] = 0; // номер одного из текстов массива "AllActionsPlus1"
		}



		for (int k1 = 0; k1 < CountOfActions; k1++) {
			PosInText = ChangeShowPosInText_Action (k1); // Определить позицию действий в тексте "TextField_1[0..1]" (от 0 до (CountBracket-1))
			//posTextField1 = new Vector2 (PosInText [1], PosInText [2]);
			//posTextField2 = new Vector2 (PosInText [3], PosInText [4]);		
			Length1 = PosInText [4]-PosInText [3]+1;

			/*if (changed_AllActions [k1, 1] > -1) { // Если плюс или минус					
				if (AllSymbols1 [changed_AllActions [k1, 1], 2] == 1) { // Если знак меняющий результат (удалять знак)
					NewResult1 = AllActions_N [k1, 2];
				} else {
					NewResult1 = Mathf.Abs(AllActions_N[k1,2]);
				}
			} else {				
				NewResult1 = Mathf.Abs(AllActions_N[k1,2]);
			}*/

			if (changed_AllActions [k1, 1] > -1) { // Если плюс или минус 
				if (AllSymbols1 [changed_AllActions [k1, 1], 2] == 1) { // Если знак меняющий результат 
					NewResult1 = AllActions_N [k1, 2]; // Со знаком
					//print("123");
				} else { // Если знак обозначает дейсвтие
					if (AllSymbols1 [changed_AllActions [k1, 1], 1] == 1) { // Если минус						
						NewResult1 = Mathf.Abs (AllActions_N [k1, 2]); // Без знака
						//print ("ABC");
					} else { // Если плюс
						NewResult1 = AllActions_N [k1, 2]; // Со знаком
						//print ("456");
					}
				}
			} else {
				NewResult1 = AllActions_N [k1, 2]; // Со знаком
				//print("789");
			}
				
			AllPosPlus1[k1+1,0] = NewLine2;
			AllActionsPlus1 [k1+1] = AllActionsPlus1 [k1+1].Remove(PosInText [3], Length1);
			AllActionsPlus1 [k1+1] = AllActionsPlus1 [k1+1].Insert(PosInText [3], NewResult1.ToString());
			AllPosPlus1[k1+1,1] = PosInText [3];
			AllPosPlus1[k1+1,2] = PosInText [3]+(NewResult1.ToString().Length);
			AllPosPlus1[k1+1,3] = PosInText [3];
			AllPosPlus1[k1+1,4] = AllPosPlus1[k1+1,3]+Length1;
			if (k1 + 2 <= CountOfActions) {
				AllActionsPlus1 [k1 + 2] = AllActionsPlus1 [k1+1];			
			}

			//NewLine1 = AllActionsPlus1 [k1+1].Length+1;
			NewLine2 = NewLine2+AllActionsPlus1 [k1+1].Length+1;
			if (AllActionsPlus1 [k1+1].Length>MaxLengthOfText[0]) {
				MaxLengthOfText[0] = AllActionsPlus1 [k1+1].Length; // максимальная длина одного из текстов массива "AllActionsPlus1"
				MaxLengthOfText[1] = k1+1; // номер одного из текстов массива "AllActionsPlus1"
			}
				
			Length1 = NewResult1.ToString().Length-(Length1);
			ChangePosWithActions (PosInText [3], Length1); // Сдвинуть массивы "changed_"

			//print ((PosInText [4]-PosInText [3])+"  "
			//	+NewResult1.ToString().Length+"  "+Length1+"  "
			//	+NewResult1.ToString()
			//	+"\n"+AllPosPlus1[k1+1,0]);
			
			//if ((PosInText >= AllActions [k1, TN1]) & 
			//	(PosInText <= AllActions [k1, TN2])) {
			//	ACtionNumber1 = k1;
			//	break;
			//}
		}

		return true;
	}


	public bool ChangePosWithActions (int Pos1, int Length1)
	{ // Сдвинуть массивы "changed_"

		string[] AllActionsPlus = new string[CountOfActions];
		int[] PosInText = new int[5];
		//Vector2 posTextField1 = new Vector2 (0, 0);
		//Vector2 posTextField2 = new Vector2 (0, 0);

		for (int k1 = 0; k1 < CountOfActions; k1++) {
			for (int k2 = 10; k2 < 16; k2++) {	
				if (Pos1 < changed_AllActions [k1, k2]) {
					changed_AllActions [k1, k2] = changed_AllActions [k1, k2] + Length1; // начальная позиция в первоначальном тексте			
				}
			}
		}

		for (int k1 = 0; k1 < CountBracket; k1++)
		{
			for (int k2 = 0; k2 < 2; k2++) {	
				if (Pos1 < changed_BracketStep[k1, k2]) {
					changed_BracketStep[k1, k2] = changed_BracketStep[k1, k2] + Length1; // начальная позиция в первоначальном тексте			
				}
			}
		}

		/*for (int k1 = 0; k1 < CountOfVariables1; k1++)
		{
			changed_AllVariables1[k1, 2];
		}*/

		return true;
	}


	public int [] ChangeShowPosInText_Action(int Numline)
	{ // Определить позицию действий в тексте (от 0 до (CountOfActions-1))		
		// Numline- номер действия в скобках
		int[] Varriables123 = new int[5];
		int StartPos = 0; // начальная позиция в первоначальном тексте
		int EndPos = 0; // конечная позиция в первоначальном тексте
		int StartPos2 = 0; // начальная позиция в дополненном тексте
		int EndPos2 = 0; // конечная позиция в дополненном тексте

		if ((Numline > -1) & (Numline < CountOfActions))
		{ // Если в пределах кол-ва действий
			

			if (changed_AllActions[Numline, 15] == -1)
			{ // Если нет знака перед числом, переменной или скобкой
				StartPos = changed_AllActions[Numline, 13] - 1; // начальная позиция в первоначальном тексте
			}
			else
			{ // Если есть знак перед числом, переменной или скобкой
				
				//StartPos = changed_AllActions[Numline, 15] - 1; // начальная позиция в первоначальном тексте

				if (changed_AllActions [Numline, 1] > -1) { // Если плюс или минус
					if (AllSymbols1[changed_AllActions [Numline, 1],2] == 1) { // Если знак меняющий результат (удалять знак)
						
						StartPos = changed_AllActions[Numline, 15] - 1; // начальная позиция в первоначальном тексте

					} else { // Если не знак меняющий результат (не удалять знак)
						
						StartPos = changed_AllActions[Numline, 13] - 1; // начальная позиция в первоначальном тексте
					}	
				} else { // Если "*", "/", "^" (не удалять знак)
					
					StartPos = changed_AllActions[Numline, 13] - 1; // начальная позиция в первоначальном тексте
				}			
			}
			EndPos = changed_AllActions[Numline, 14] - 1; // конечная позиция в первоначальном тексте


			if (changed_AllActions [Numline, 12] == -1) { // Если нет знака перед числом, переменной или скобкой
				
				StartPos2 = changed_AllActions [Numline, 10]; // начальная позиция в дополненном тексте

			} else { // Если есть знак перед числом, переменной или скобкой

				//StartPos2 = changed_AllActions[Numline, 12]; // начальная позиция в дополненном тексте

				if (changed_AllActions [Numline, 1] > -1) { // Если плюс или минус				
				//if ((changed_AllActions [Numline, 1] > -1) & // Если плюс или минус
				//	(changed_AllActions [Numline, 0] == 1)) { // Если минус				
					if (AllSymbols1[changed_AllActions [Numline, 1],2] == 1) { // Если знак меняющий результат (удалять знак)
						
						StartPos2 = changed_AllActions[Numline, 12]; // начальная позиция в дополненном тексте

					} else { // Если не знак меняющий результат (не удалять знак)
						
						StartPos2 = changed_AllActions[Numline, 10]; // начальная позиция в дополненном тексте
					}	
				} else { // Если "*", "/", "^" (не удалять знак)
					
					StartPos2 = changed_AllActions[Numline, 10]; // начальная позиция в дополненном тексте
				}

				/*if (changed_AllActions [Numline, 1] > -1) { // Если плюс или минус (удалять знак)					
					if (AllSymbols1[changed_AllActions [Numline, 1],2] == 1) { // Если знак меняющий результат (удалять знак)
						StartPos2 = changed_AllActions[Numline, 12]; // начальная позиция в дополненном тексте
					} else { // Если не знак меняющий результат (не удалять знак)
						StartPos2 = changed_AllActions[Numline, 10]; // начальная позиция в дополненном тексте
					}	
				} else { // Если "*", "/", "^" (не удалять знак)
					StartPos2 = changed_AllActions[Numline, 10]; // начальная позиция в дополненном тексте
				}	*/		
			}
			EndPos2 = changed_AllActions[Numline, 11]; // конечная позиция в дополненном тексте
					

			if (StartPos < 0)
				StartPos = 0;
			if (EndPos < 0)
				EndPos = 0;
			else if (EndPos >= Text_Formula.Length)
				EndPos = Text_Formula.Length - 1;
			if (StartPos2 < 0)
				StartPos2 = 0;
			if (EndPos2 < 0)
				EndPos2 = 0;
			else if (EndPos2 >= Text_Formula_ch.Length)
				EndPos2 = Text_Formula_ch.Length - 1;

			//print (Numline + " 1: " + StartPos + " | " + EndPos + " | "
			//   + Text_Formula.Substring (StartPos, EndPos - StartPos + 1));
			//print (Numline + " 2: " + StartPos2 + " | " + EndPos2 + " | "
			//	+ Text_Formula_ch.Substring (StartPos2, EndPos2 - StartPos2 + 1));

			int Numline1 = 0;
			if ((changed_AllActions[Numline, 0] > 4) & (changed_AllActions[Numline, 0] < 10))
			{ // Если скобки
				Numline1 = changed_AllActions[Numline, 3];
				//print ("0:");
			}
			else if (changed_AllActions[Numline, 0] == 10)
			{ // Если переменная со скобками
				Numline1 = changed_AllVariables1[changed_AllActions[Numline, 3], 2];
				//print ("1:");
			}
			else
			{
				for (int i = 0; i < CountBracket; i++)
				{
					if ((changed_BracketStep[i, 0] < StartPos2) &
						(changed_BracketStep[i, 1] > StartPos2))
					{ // Если найдена позиция
						Numline1 = i;
						//print ("2: "+Numline1);
						break;
					}
				}		    	
			}

			Varriables123[0] = Numline1; // номер действия в скобках
			Varriables123[1] = StartPos; // начальная позиция в первоначальном тексте
			Varriables123[2] = EndPos; // конечная позиция в первоначальном тексте
			Varriables123[3] = StartPos2; // начальная позиция в дополненном тексте
			Varriables123[4] = EndPos2; // конечная позиция в дополненном тексте

			return Varriables123;

			//print (StartPos + "  " + EndPos
			//+ "\n" + StartPos2 + "  " + EndPos2);
		}
		else
		{
			Varriables123[0] = -1;
			Varriables123[1] = -1;
			Varriables123[2] = -1;
			Varriables123[3] = -1;
			Varriables123[4] = -1;
		}

		return Varriables123;
	}








	public int NumberBracketsInText (int TextNumber, int PosInText)
	{ // Номер действия, по текущей позиции в тексте

		PosInText = PosInText+(1-TextNumber);
		int TN1 = 10+(1-TextNumber)*3;
		int TN2 = 11+(1-TextNumber)*3;
		int ACtionNumber1 = -1;

		for (int k1 = 0; k1 < CountOfActions; k1++) {
			if ((PosInText >= AllActions [k1, TN1]) & 
				(PosInText <= AllActions [k1, TN2])) {
				ACtionNumber1 = k1;
				break;
			}
		}

		return ACtionNumber1;
	}
		


	public int [] ShowPosInText_Action(int Numline)
	{ // Определить позицию действий в тексте (от 0 до (CountOfActions-1))		
		// Numline- номер действия в скобках
		int[] Varriables123 = new int[5];
		int StartPos = 0; // начальная позиция в первоначальном тексте
		int EndPos = 0; // конечная позиция в первоначальном тексте
		int StartPos2 = 0; // начальная позиция в дополненном тексте
		int EndPos2 = 0; // конечная позиция в дополненном тексте

		if ((Numline > -1) & (Numline < CountOfActions))
		{ // Если в пределах кол-ва действий

			if (AllActions[Numline, 15] == -1)
			{ // Если нет знака перед числом, переменной или скобкой
				StartPos = AllActions[Numline, 13] - 1; // начальная позиция в первоначальном тексте
			}
			else
			{ // Если есть знак перед числом, переменной или скобкой
				StartPos = AllActions[Numline, 15] - 1; // начальная позиция в первоначальном тексте
			}
			EndPos = AllActions[Numline, 14] - 1; // конечная позиция в первоначальном тексте


			if (AllActions[Numline, 12] == -1)
			{ // Если нет знака перед числом, переменной или скобкой
				StartPos2 = AllActions[Numline, 10]; // начальная позиция в дополненном тексте
			}
			else
			{ // Если есть знак перед числом, переменной или скобкой
				StartPos2 = AllActions[Numline, 12]; // начальная позиция в дополненном тексте
			}
			EndPos2 = AllActions[Numline, 11]; // конечная позиция в дополненном тексте

			if (StartPos < 0)
				StartPos = 0;
			if (EndPos < 0)
				EndPos = 0;
			else if (EndPos >= Text_Formula.Length)
				EndPos = Text_Formula.Length - 1;
			if (StartPos2 < 0)
				StartPos2 = 0;
			if (EndPos2 < 0)
				EndPos2 = 0;
			else if (EndPos2 >= Text_Formula_ch.Length)
				EndPos2 = Text_Formula_ch.Length - 1;

			//print (Numline + " 1: " + StartPos + " | " + EndPos + " | "
			//   + Text_Formula.Substring (StartPos, EndPos - StartPos + 1));
			//print (Numline + " 2: " + StartPos2 + " | " + EndPos2 + " | "
			//	+ Text_Formula_ch.Substring (StartPos2, EndPos2 - StartPos2 + 1));

			int Numline1 = 0;
			if ((AllActions[Numline, 0] > 4) & (AllActions[Numline, 0] < 10))
			{ // Если скобки
				Numline1 = AllActions[Numline, 3];
				//print ("0:");
			}
			else if (AllActions[Numline, 0] == 10)
			{ // Если переменная со скобками
				Numline1 = AllVariables1[AllActions[Numline, 3], 2];
				//print ("1:");
			}
			else
			{
				for (int i = 0; i < CountBracket; i++)
				{
					if ((BracketStep[i, 0] < StartPos2) &
						(BracketStep[i, 1] > StartPos2))
					{ // Если найдена позиция
						Numline1 = i;
						//print ("2: "+Numline1);
						break;
					}
				}		    	
			}
				
			Varriables123[0] = Numline1; // номер действия в скобках
			Varriables123[1] = StartPos; // начальная позиция в первоначальном тексте
			Varriables123[2] = EndPos; // конечная позиция в первоначальном тексте
			Varriables123[3] = StartPos2; // начальная позиция в дополненном тексте
			Varriables123[4] = EndPos2; // конечная позиция в дополненном тексте

			return Varriables123;

			//print (StartPos + "  " + EndPos
			//+ "\n" + StartPos2 + "  " + EndPos2);
		}
		else
		{
			Varriables123[0] = -1;
			Varriables123[1] = -1;
			Varriables123[2] = -1;
			Varriables123[3] = -1;
			Varriables123[4] = -1;
		}

		return Varriables123;
	}



	public bool ShowPosInBracketAction () { // Определить позиции действий "PosOfBracketAction" в тексте "Text_Action"
	string NewText1 = "";
	string DopSkobki = "";
	int Correction1;
	#if UNITY_WEBGL
	Correction1 = 1; // for WebGL
	#else
	Correction1 = 0;
	#endif

	int CountOfSymbols1 = BracketStep_N[CountBracket-1].ToString().Length+(2-Correction1);

	PosOfBracketAction = new int[CountBracket + 1, 5];

		for (int k1 = 0; k1 < CountBracket; k1++) {		
			DopSkobki = " ";
			if ((BracketStep [k1, 2] == 4) |
			    (k1 == CountBracket - 1)) {
				DopSkobki = "*";			
			}

			// Действие в скобках № "k1"
			NewText1 = DopSkobki + (k1+1).ToString () + ": "
			+ BracketStep_T [k1] + " = " + BracketStep_N [k1].ToString ();

			PosOfBracketAction [k1, 0] = CountOfSymbols1;
			// Позиции в самом тексте "Text_Action"
			PosOfBracketAction [k1, 1] = CountOfSymbols1+(k1+1).ToString ().Length+3;
			PosOfBracketAction [k1, 2] = PosOfBracketAction [k1, 1] + BracketStep_T [k1].Length-1;
			PosOfBracketAction [k1, 3] = PosOfBracketAction [k1, 2] + 4;
			PosOfBracketAction [k1, 4] = PosOfBracketAction [k1, 3] + BracketStep_N [k1].ToString ().Length-Correction1;

			//print (CountOfSymbols1.ToString()+" | "+PosOfBracketAction [k1 + 1, 1].ToString()
			//	+" | "+PosOfBracketAction [k1, 2].ToString()+" | "+BracketStep_T [k1]+" | "+BracketStep_T [k1].Length
			//	+"\n"+PosOfBracketAction [k1 + 1, 3].ToString()
			//	+" | "+PosOfBracketAction [k1 + 1, 4].ToString());

			CountOfSymbols1 = CountOfSymbols1 + NewText1.Length + (2-Correction1);
		}

		PosOfBracketAction [CountBracket, 0] = CountOfSymbols1;
		// Позиции в самом тексте "Text_Action"
		PosOfBracketAction [CountBracket, 1] = CountOfSymbols1+CountBracket.ToString ().Length+3;
		PosOfBracketAction [CountBracket, 2] = PosOfBracketAction [CountBracket, 1] + BracketStep_T [CountBracket-1].Length-1;
		PosOfBracketAction [CountBracket, 3] = PosOfBracketAction [CountBracket, 2] + 4;
		PosOfBracketAction [CountBracket, 4] = PosOfBracketAction [CountBracket, 3] + BracketStep_N [CountBracket-1].ToString ().Length-Correction1;

		//print (CountOfSymbols1 + "\n" + Text_Action.Length);
		return true;						
	}



	public Rect ShowPosInText (int Numline) { // Определить позицию действий в тексте "Text_Formula, Text_Formula_ch" (от 0 до (CountBracket-1))
			// Numline- номер действия в скобках
			int StartPos = 0; // начальная позиция в первоначальном тексте
			int EndPos = 0; // конечная позиция в первоначальном тексте
			int StartPos2 = 0; // начальная позиция в дополненном тексте
			int EndPos2 = 0; // конечная позиция в дополненном тексте
			if ((Numline > -1) & (Numline < CountBracket))
			{ // Если в пределах кол-ва действий
				if ((BracketStep[Numline, 0] > -1) &
					(BracketStep[Numline, 1] > -1))
				{
					if (BracketStep[Numline, 5] > -1)
					{ // Если у скобок есть переменная				          	

						//if ((AllVariables1 [BracketStep [Numline, 5], 4] == -3) |
						//	(AllVariables1 [BracketStep [Numline, 5], 4] > -1)) { // Если минус перед переменной или знак меняющий результат
						if (AllVariables1[BracketStep[Numline, 5], 4] != -1)
						{ // Если плюс,минус перед скобкой или знак меняющий результат
							if ((AllVariables1[BracketStep[Numline, 5], 8] > -1) &
								(BracketStep[Numline, 9] > -1))
							{
								StartPos = AllVariables1[BracketStep[Numline, 5], 8] - 1; // начальная позиция в первоначальном тексте
								EndPos = BracketStep[Numline, 9] - 1; // конечная позиция в первоначальном тексте
								//print (Numline + "C1: " + BracketStep [Numline, 2] + " | "
								//+ Text_Formula.Substring (StartPos, EndPos - StartPos + 1));
							}
							if ((AllVariables1[BracketStep[Numline, 5], 3] > -1) &
								(BracketStep[Numline, 1] > -1))
							{
								StartPos2 = AllVariables1[BracketStep[Numline, 5], 3]; // начальная позиция в дополненном тексте
								EndPos2 = BracketStep[Numline, 1]; // конечная позиция в дополненном тексте
								//print (Numline + "D1: " + BracketStep [Numline, 2] + " | "
								//	+ Text_Formula_ch.Substring (StartPos2, EndPos2 - StartPos2 + 1));
							}
						}
						else
						{ // Если нет знака "+","-" перед переменной
							if ((AllVariables1[BracketStep[Numline, 5], 6] > -1) &
								(BracketStep[Numline, 9] > -1))
							{
								StartPos = AllVariables1[BracketStep[Numline, 5], 6] - 1; // начальная позиция в первоначальном тексте
								EndPos = BracketStep[Numline, 9] - 1; // конечная позиция в первоначальном тексте
								//print (Numline + "C2: " + BracketStep [Numline, 2] + " | "
								//+ Text_Formula.Substring (StartPos, EndPos - StartPos + 1));
							}
							if ((AllVariables1[BracketStep[Numline, 5], 0] > -1) &
								(BracketStep[Numline, 1] > -1))
							{
								StartPos2 = AllVariables1[BracketStep[Numline, 5], 0]; // начальная позиция в дополненном тексте
								EndPos2 = BracketStep[Numline, 1]; // конечная позиция в дополненном тексте
								//print (Numline + "D2: " + BracketStep [Numline, 2] + " | "
								//	+ Text_Formula_ch.Substring (StartPos2, EndPos2 - StartPos2 + 1));
							}
						}
					}
					else
					{ // Если нет переменной
						//if ((BracketStep [Numline, 4] == -3) | 
						//	(BracketStep [Numline, 4] > -1)) { // Если минус перед скобкой или знак меняющий результат
						if (BracketStep[Numline, 4] != -1)
						{ // Если плюс,минус перед скобкой или знак меняющий результат						
							if ((BracketStep[Numline, 10] > -1) &
								(BracketStep[Numline, 9] > -1))
							{
								StartPos = BracketStep[Numline, 10] - 1; // начальная позиция в первоначальном тексте
								EndPos = BracketStep[Numline, 9] - 1; // конечная позиция в первоначальном тексте
								//print (Numline + "C4: " + BracketStep [Numline, 2] + " | "
								//	+ Text_Formula.Substring (StartPos, EndPos - StartPos + 1));
							}
							if ((BracketStep[Numline, 3] > -1) &
								(BracketStep[Numline, 1] > -1))
							{
								StartPos2 = BracketStep[Numline, 3]; // начальная позиция в дополненном тексте
								EndPos2 = BracketStep[Numline, 1]; // конечная позиция в дополненном тексте
								//print (Numline + "D3: " + BracketStep [Numline, 2] + " | "
								//+ Text_Formula_ch.Substring (StartPos2, EndPos2 - StartPos2 + 1));
							}
						}
						else
						{ // Если нет знака "+","-" перед скобкой

							if ((BracketStep[Numline, 8] > -1) &
								(BracketStep[Numline, 9] > -1))
							{
								StartPos = BracketStep[Numline, 8] - 1; // начальная позиция в первоначальном тексте
								EndPos = BracketStep[Numline, 9] - 1; // конечная позиция в первоначальном тексте
								//print (Numline + "C4: " + BracketStep [Numline, 2] + " | "
								//+ Text_Formula.Substring (StartPos, EndPos - StartPos + 1));
							}
							if ((BracketStep[Numline, 0] > -1) &
								(BracketStep[Numline, 1] > -1))
							{
								StartPos2 = BracketStep[Numline, 0]; // начальная позиция в дополненном тексте
								EndPos2 = BracketStep[Numline, 1]; // конечная позиция в дополненном тексте
								//print (Numline + "D4: " + BracketStep [Numline, 2] + " | "
								//+ Text_Formula_ch.Substring (StartPos2, EndPos2 - StartPos2 + 1));
							}
						}
					}
					if (StartPos < 0) StartPos = 0;
					if (EndPos < 0) EndPos = 0;
					else if (EndPos >= Text_Formula.Length)
						EndPos = Text_Formula.Length - 1;
					if (StartPos2 < 0) StartPos2 = 0;
					if (EndPos2 < 0) EndPos2 = 0;
					else if (EndPos2 >= Text_Formula_ch.Length)
						EndPos2 = Text_Formula_ch.Length - 1;
				//print (Numline + " 1: " + BracketStep [Numline, 8] + " | " 
				//	+ BracketStep [Numline, 9] + " | "
				//	+ Text_Formula.Substring (StartPos, EndPos - StartPos + 1));
				//print (Numline + " 2: " + StartPos2 + " | " + EndPos2 + " | "
				//	+ Text_Formula_ch.Substring (StartPos2, EndPos2 - StartPos2 + 1));
				//print (StartPos + " | " + EndPos + "\n"
				//	+ StartPos2 + " | " + EndPos2);

				return new Rect(StartPos,EndPos,StartPos2,EndPos2);

				//ShowPosInText2 (StartPos, EndPos); // Выделить часть текста в первоначальном тексте
				//ShowPosInText_ch2 (StartPos2, EndPos2); // Выделить часть текста в дополненном тексте
			}
		} else {
			Text_Formula2 = Text_Formula;
			Text_Formula_ch2 = Text_Formula_ch;
		}
		return new Rect(-1,-1,-1,-1);
	}

	/*public bool ShowPosInText2 (int StartPos, int EndPos) { // Выделить часть текста в первоначальном тексте
		if ((StartPos > -1) & 
			(StartPos < EndPos) &
			(EndPos<Text_Formula.Length)) {
			string s1 = Text_Formula.Substring (0,StartPos);
			string s2 = Text_Formula.Substring (StartPos,
				EndPos - StartPos + 1);
			string s3 = Text_Formula.Substring (EndPos+1,
				Text_Formula.Length - EndPos - 1);
			Text_Formula2 = s1+" >>>  "+s2+"  <<< "+s3;
			//print (s1+" >>>  "+s2+"  <<< "+s3);
		}
		return true;
	}		

	public bool ShowPosInText_ch2 (int StartPos2, int EndPos2) { // Выделить часть текста в дополненном тексте
		if ((StartPos2 > -1) & 
			(StartPos2 < EndPos2) &
			(EndPos2<Text_Formula_ch.Length)) {
			string s1 = Text_Formula_ch.Substring (0,StartPos2);
			string s2 = Text_Formula_ch.Substring (StartPos2,
				EndPos2 - StartPos2 + 1);
			string s3 = Text_Formula_ch.Substring (EndPos2+1,
				Text_Formula_ch.Length - EndPos2 - 1);
			Text_Formula_ch2 = s1+" >>>  "+s2+"  <<< "+s3;
			//print (s1+" >>>  "+s2+"  <<< "+s3);
		}
		return true;
	}*/










	public int[] BracketsInText (int BracketLine1, int ActionLine1)
	{ // Найти позиции скобок в "Text_Formula" и "Text_Formula_ch", по номеру скобок
		int[] AllPositions1 = new int[14];

		for (int k1 = 0; k1 < 14; k1++) {
			AllPositions1[k1] = -1;
		}

		if (BracketLine1 > -1) {
			bool Variable1B = true;

			if (ActionLine1 > -1) {
				if (AllActions [ActionLine1, 0] == 10) { // Если переменная со скобкой
					Variable1B = true;
				} else {
					Variable1B = false;
				}

				if (AllActions[ActionLine1, 0] < 5) { // Если обычное действие
					int[] PosInText1 = new int[6];

					findAllPosTextAction(ActionLine1, out PosInText1);  // Найти позиции действий левой части в тексте

					// Действие и крайние символы
					AllPositions1 [8] = PosInText1[0]-1; // Позиция символа в основном тексте (начальная позиция)
					AllPositions1 [9] = PosInText1[1]; // Позиция символа в основном тексте (конечная позиция)
					AllPositions1 [10] = PosInText1[4]-1; // Позиция действия в основном тексте
					AllPositions1 [11] = PosInText1[2]; // Позиция символа в дополненном тексте (начальная позиция)
					AllPositions1 [12] = PosInText1[3] + 1; // Позиция символа в дополненном тексте (конечная позиция)
					AllPositions1 [13] = PosInText1[5]; // Позиция действия в дополненном тексте
				}

			}
				
			// Позиции переменной
			if ((Variable1B == true) & (BracketStep [BracketLine1, 5] > -1)) { // Если есть переменная
				AllPositions1 [4] = AllVariables1 [BracketStep [BracketLine1, 5], 6]-1; // Левая позиция переменной, в основном тексте			
				AllPositions1 [5] = AllVariables1 [BracketStep [BracketLine1, 5], 7]; // Правая позиция переменной, в основном тексте
				AllPositions1 [6] = AllVariables1 [BracketStep [BracketLine1, 5], 0]; // Левая позиция переменной, в дополненном тексте			
				AllPositions1 [7] = AllVariables1 [BracketStep [BracketLine1, 5], 1] + 1; // Правая позиция переменной, в дополненном тексте
			}

			// Позиции скобок

			/*if ((BracketStep [BracketLine1, 1] == 4) |
			    (BracketLine1 == CountBracket - 1)) { // Если есть дополнительные скобки

				AllPositions1 [0] = BracketStep [BracketLine1, 8]; // Позиция левой скобки в основом тексте	
				AllPositions1 [1] = BracketStep [BracketLine1, 9]; // Позиция правой скобки в основном тексте	

			} else { // Если нет дополнительных скобок
				AllPositions1 [0] = BracketStep [BracketLine1, 8]; // Позиция левой скобки в основом тексте	
				AllPositions1 [1] = BracketStep [BracketLine1, 9]; // Позиция правой скобки в основном тексте				
			}*/

			if (BracketStep [BracketLine1, 11] > -1) { // Если есть дополнительные скобки

				AllPositions1 [0] = BracketStep [BracketStep [BracketLine1, 11], 8]-1; // Позиция левой скобки в основом тексте	
				AllPositions1 [1] = BracketStep [BracketStep [BracketLine1, 11], 9]-1; // Позиция правой скобки в основном тексте	

			} else { // Если нет дополнительных скобок
				AllPositions1 [0] = BracketStep [BracketLine1, 8]-1; // Позиция левой скобки в основом тексте	
				AllPositions1 [1] = BracketStep [BracketLine1, 9]-1; // Позиция правой скобки в основном тексте				
			}

			AllPositions1[2] = BracketStep[BracketLine1, 0]; // Позиция левой скобки в дополненном тексте	
			AllPositions1[3] = BracketStep[BracketLine1, 1]; // Позиция правой скобки в дополненном тексте	

		}
		return AllPositions1;
	}



	public bool findAllPosTextAction(int StepAction1, out int[] PosInText1)
	{ // Найти позиции действий левой части в тексте
		PosInText1 = new int[6];
		PosInText1[0] = 0; // Позиция символа в основном тексте (начальная позиция)
		PosInText1[1] = 0; // Позиция символа в основном тексте (конечная позиция)
		PosInText1[2] = 0; // Позиция символа в дополненном тексте (начальная позиция)
		PosInText1[3] = 0; // Позиция символа в дополненном тексте (конечная позиция)
		PosInText1[4] = 0; // Позиция действия в основном тексте
		PosInText1[5] = 0; // Позиция действия в дополненном тексте
		int Pp__0 = -1; // Знак левого числа, переменной или скобок
		int Pp_0 = 0; // Левое число, переменная, скобка, скобка с переменной (левая позиция) "в дополненном тексте"
		//int Pp_1 = 0; // Левое число, переменная, скобка, скобка с переменной (правая позиция) "в дополненном тексте"
		//int Pp__2 = -1; // Знак правого числа, переменной или скобок "в дополненном тексте"
		//int Pp_2 = 0; // Правое число, переменная, скобка, скобка с переменной (левая позиция) "в дополненном тексте"
		//int Pp_3 = 0; // Правое число, переменная, скобка, скобка с переменной (правая позиция) "в дополненном тексте"
		int Pp4 = -1; // Знак действия "в дополненном тексте"
		int Pp__0M = -1; // Знак левого числа, переменной или скобок "в основном тексте"
		int Pp_0M = 0; // Левое число, переменная, скобка, скобка с переменной (левая позиция) "в основном тексте"
		//int Pp_1M = 0; // Левое число, переменная, скобка, скобка с переменной (правая позиция) "в основном тексте"
		//int Pp__2M = -1; // Знак правого числа, переменной или скобок "в основном тексте"
		//int Pp_2M = 0; // Правое число, переменная, скобка, скобка с переменной (левая позиция) "в основном тексте"
		//int Pp_3M = 0; // Правое число, переменная, скобка, скобка с переменной (правая позиция) "в основном тексте"
		int Pp4M = -1; // Знак действия "в основном тексте"

		if (AllActions[StepAction1, 6] > -1)
		{ // Если есть знак действия
			Pp4 = AllSymbols1[AllActions[StepAction1, 6], 0]; // Знак действия "в дополненном тексте"
			Pp4M = AllSymbols1[AllActions[StepAction1, 6], 3]; // Знак действия "в основном тексте"
		}

		if (AllActions[StepAction1, 1] > -1)
		{ // Если у левого числа, переменной или скобок есть знак "+", "-"
			Pp__0 = AllSymbols1[AllActions[StepAction1, 1], 0]; // Знак левого числа, переменной или скобок "в дополненном тексте"
			Pp__0M = AllSymbols1[AllActions[StepAction1, 1], 3]; // Знак левого числа, переменной или скобок "в основном тексте"
		}

		if (AllActions[StepAction1, 2] == 0)
		{ // Если число
			Pp_0 = AllNumbers1[AllActions[StepAction1, 3], 0];
			Pp_0M = AllNumbers1[AllActions[StepAction1, 3], 4];
			/*if (AllActions [StepAction1, 4] == -1) { // Если одна позиция
				Pp_1 = AllNumbers1 [AllActions [StepAction1, 3], 1];
				Pp_1M = AllNumbers1 [AllActions [StepAction1, 3], 5];
			}*/
		}
		else if ((AllActions[StepAction1, 2] == 1) | (AllActions[StepAction1, 2] == 3))
		{ // Если переменная
			Pp_0 = AllVariables1[AllActions[StepAction1, 3], 0];
			Pp_0M = AllVariables1[AllActions[StepAction1, 3], 6];
			if (AllActions[StepAction1, 4] == -1)
			{ // Если одна позиция
				/*if ((AllActions [StepAction1, 2] == 1) | (AllVariables1 [AllActions [StepAction1, 3], 2] < 0)) { // Если переменная без скобок
                  Pp_1 = AllVariables1 [AllActions [StepAction1, 3], 1];
                  Pp_1M = AllVariables1 [AllActions [StepAction1, 3], 7];
              } else { // Если переменная со скобками
                  Pp_1 = BracketStep [AllVariables1 [AllActions [StepAction1, 3], 2], 1];
                  Pp_1M = BracketStep [AllVariables1 [AllActions [StepAction1, 3], 2], 9];
              }*/
			}
		}
		else if (AllActions[StepAction1, 2] == 2)
		{ // Если скобки
			Pp_0 = BracketStep[AllActions[StepAction1, 3], 0];
			Pp_0M = BracketStep[AllActions[StepAction1, 3], 8];
			/*if (AllActions [StepAction1, 4] == -1) { // Если одна позиция
				Pp_1 = BracketStep [AllActions [StepAction1, 3], 1];
				Pp_1M = BracketStep [AllActions [StepAction1, 3], 9];
			}*/
		}

		/*if (AllActions[StepAction1,4] == 0) { // Если число
			Pp_1 = AllNumbers1 [AllActions[StepAction1,5], 1];	
			Pp_1M = AllNumbers1 [AllActions[StepAction1,5], 5];	
		} else if ((AllActions[StepAction1,4] == 1) | (AllActions[StepAction1,4] == 3)) { // Если переменная
			if ((AllActions [StepAction1, 4] == 1) | (AllVariables1 [AllActions [StepAction1, 5], 2] < 0)) { // Если переменная без скобок
				Pp_1 = AllVariables1 [AllActions [StepAction1, 5], 1];
				Pp_1M = AllVariables1 [AllActions [StepAction1, 5], 7];
			} else { // Если переменная со скобками
				Pp_1 = BracketStep [AllVariables1 [AllActions [StepAction1, 5], 2], 1];
				Pp_1M = BracketStep [AllVariables1 [AllActions [StepAction1, 5], 2], 9];
			}
		} else if (AllActions[StepAction1,4] == 2) { // Если скобки
			Pp_1 = BracketStep [AllActions[StepAction1,5], 1];	
			Pp_1M = BracketStep [AllActions[StepAction1,5], 9];
		}*/

		/*if (AllActions[StepAction1,7] > -1) { // Если у правого числа, переменной или скобок есть знак "+", "-"
		Pp__2 = AllSymbols1 [AllActions[StepAction1,7], 0]; // Знак правого числа, переменной или скобок "в дополненном тексте"
		Pp__2M = AllSymbols1 [AllActions[StepAction1,7], 3]; // Знак правого числа, переменной или скобок "в основном тексте"
	}*/

	/*if (AllActions[StepAction1,8] == 0) { // Если число
	//Pp_2 = AllNumbers1 [AllActions[StepAction1,9], 0];
	//Pp_2M = AllNumbers1 [AllActions[StepAction1,9], 4];
	Pp_3 = AllNumbers1 [AllActions[StepAction1,9], 1];
	Pp_3M = AllNumbers1 [AllActions[StepAction1,9], 5];
} else if ((AllActions[StepAction1,8] == 1) | (AllActions[StepAction1,8] == 3)) { // Если переменная
	if ((AllActions[StepAction1,8] == 1) | (AllVariables1 [AllActions[StepAction1,9], 2] < 0)) { // Если переменная без скобок
		//Pp_2 = AllVariables1 [AllActions[StepAction1,9], 0];
		//Pp_2M = AllVariables1 [AllActions[StepAction1,9], 6];
		Pp_3 = AllVariables1 [AllActions[StepAction1,9], 1];
		Pp_3M = AllVariables1 [AllActions[StepAction1,9], 7];
	} else { // Если переменная со скобками
		//Pp_2 = BracketStep [AllVariables1 [AllActions[StepAction1,9], 2], 0];
		//Pp_2M = BracketStep [AllVariables1 [AllActions[StepAction1,9], 2], 8];
		Pp_3 = BracketStep [AllVariables1 [AllActions[StepAction1,9], 2], 1];
		Pp_3M = BracketStep [AllVariables1 [AllActions[StepAction1,9], 2], 9];
	}
} else if (AllActions[StepAction1,8] == 2) { // Если скобки
	//Pp_2 = BracketStep [AllActions[StepAction1,9], 0];	
	//Pp_2M = BracketStep [AllActions[StepAction1,9], 8];
	Pp_3 = BracketStep [AllActions[StepAction1,9], 1];	
	Pp_3M = BracketStep [AllActions[StepAction1,9], 9];	
}	*/

if (Pp__0 == -1)
{ // Если нет знака перед левым числом, переменной или скобками
	if (AllSymbols1[AllActions[StepAction1, 6], 0] > Pp_0)
	{
		PosInText1[0] = Pp_0M; // Позиция символа в основном тексте (начальная позиция)
		PosInText1[1] = AllSymbols1[AllActions[StepAction1, 6], 3] - 1; // Знак левого числа, переменной или скобок "в основном тексте"
		//PosInText1[1] = Pp_1M; // Позиция символа в основном тексте (конечная позиция)
		PosInText1[2] = Pp_0; // Позиция символа в дополненном тексте (начальная позиция)
		PosInText1[3] = AllSymbols1[AllActions[StepAction1, 6], 0] - 1; // Знак левого числа, переменной или скобок "в дополненном тексте"
		//PosInText1[3] = Pp_1; // Позиция символа в дополненном тексте (конечная позиция)
		PosInText1[4] = Pp4M; // Позиция действия в основном тексте
		PosInText1[5] = Pp4; // Позиция действия в дополненном тексте
		/*AllActions[StepAction1,10] = Pp_0; // 10= левая позиция в дополненном тексте
                                             AllActions[StepAction1,11] = Pp_3; // 11= правая позиция в допоненном тексте
                                             AllActions[StepAction1,12] = -1; // 12= позиция знака в дополненном тексте
                                             AllActions[StepAction1,13] = Pp_0M; // 13= левая позиция в основном тексте
                                             AllActions[StepAction1,14] = Pp_3M; // 14= правая позиция в основном тексте
                                             AllActions[StepAction1,15] = -1; // 15= позиция знака в основном тексте
                                             */
		//AllActions_T[StepAction1] = sActions2
		//	+" = "+AllActions_N[StepAction1,0].ToString ()
		//	+sActions3; // Текст с действием
		/*print (sActions2 + System.Environment.NewLine
                                                                     + StepAction1 + ":1@ " 
                                                                     + stext.Substring (Pp_0, Pp_3 - Pp_0 + 1)
                                                                     +" = "+AllActions_N[StepAction1,2]);*/
	}
}
else
{ // Если есть знак перед левым числом, переменной или скобками
	if (AllSymbols1[AllActions[StepAction1, 6], 0] > Pp__0)
	{
		PosInText1[0] = Pp__0M; // Позиция символа в основном тексте (начальная позиция)
		PosInText1[1] = AllSymbols1[AllActions[StepAction1, 6], 3] - 1; // Знак левого числа, переменной или скобок "в основном тексте"
		//PosInText1[1] = Pp_1M; // Позиция символа в основном тексте (конечная позиция)
		PosInText1[2] = Pp__0; // Позиция символа в дополненном тексте (начальная позиция)
		PosInText1[3] = AllSymbols1[AllActions[StepAction1, 6], 0] - 1; // Знак левого числа, переменной или скобок "в дополненном тексте"
		//PosInText1[3] = Pp_1; // Позиция символа в дополненном тексте (конечная позиция)
		PosInText1[4] = Pp4M; // Позиция действия в основном тексте
		PosInText1[5] = Pp4; // Позиция действия в дополненном тексте
		/*AllActions[StepAction1,10] = Pp_0; // 10= левая позиция в дополненном тексте
                                             AllActions[StepAction1,11] = Pp_3; // 11= правая позиция в допоненном тексте
                                             AllActions[StepAction1,12] = Pp__0; // 12= позиция знака в дополненном тексте
                                             AllActions[StepAction1,13] = Pp_0M; // 13= левая позиция в основном тексте
                                             AllActions[StepAction1,14] = Pp_3M; // 14= правая позиция в основном тексте
                                             AllActions[StepAction1,15] = Pp__0M; // 15= позиция знака в основном тексте
                                             */
		//AllActions_T[StepAction1] = sActions2
		//	+" = "+AllActions_N[StepAction1,0].ToString ()
		//	+sActions3; // Текст с действием
		/*print (sActions2 + System.Environment.NewLine
                                                                     + StepAction1 + ":2@ " 
                                                                     + stext.Substring (Pp__0, Pp_3 - Pp__0 + 1)
                                                                     +" = "+AllActions_N[StepAction1,2]);*/

		//sAllActions = sAllActions
		//	+ stext.Substring (Pp__0, Pp_3 - Pp__0 + 1)
		//	+ System.Environment.NewLine;
	}
}
return true;
}










// Для цикла решений формулы: /////////////////////////////////////////////////
//private string Text_Formula = "((((1+1)*-2)*3)/4)+5"; // текст с формулой
[HideInInspector]
public string cikle_Text_Formula = "(+AbsG(---(R+|B|^+2)-(-2*-|G[R]|)"
	+ "+-+-RoundB[+-+-K+Jf[-(10+5/2.3)+R,-(10+5/2.3)-5,-(10+5/2.3)+5]*2])+(|-B/2-R*-2|)*4+|"
	+ "-+-Gg1R[-1.5,-2]|)"; // текст с формулой
//private string Text_Formula = "5+(-(4+2)+3*2)-(-4/8)^2"; // текст с формулой	
[HideInInspector]
public string cikle_Text_Formula2 = " "; // *Не обязательно* Отображаемый текст "Text_Formula", с выбранным действием
[HideInInspector]
public string cikle_Text_Formula_ch = " "; // текст с формулой, дополнено скобками
[HideInInspector]
public string cikle_Text_Formula_ch2 = " "; // *Не обязательно* Отображаемый текст "Text_Formula_ch", с выбранным действием
[HideInInspector]
public string cikle_Text_Action = " "; // текст, каждое действие с новой строки
[HideInInspector]
public string[] cikle_Text_Property; // массив (основной, дополненный) текст, со свойствами формулы (5+RGB*2) = (№+...+№)
[HideInInspector]
public int[,] cikle_AllSymbols1; // массив со знаками. [ порядковый номер знака в тексте , 0..3 ]; // 0-Позиция знака. 1-Тип знака  0=+, 1=-, 2=*, 3=/, 4=^. 2-0=обычный знак, 1=знак меняющий результат, 3-первоначальная позиция знака
[HideInInspector]
public int cikle_CountOfSymbols1 = 0; // количество знаков
[HideInInspector]
public int cikle_CountOfUnActSymbols1 = 0; // количество знаков меняющих значение числа, скобки переменной
[HideInInspector]
public int cikle_CountOfCommas1 = 0; // количество запятых
[HideInInspector]
public int[,] cikle_AllNumbers1; // массив с числами. [ порядковый номер числа в тексте , 0..5 ]; // 0-левая позиция, 1-правая позиция числа, 2-порядковый номер знака в массиве "AllSymbols1", если перед числом есть знак меняющий результат "+","-" (-1=если перед числом нет знака "+","-"), 3- -3=обычный знак "-" перед числом, -2=обычный знак "+" перед числом, -1=нет меняющего знака перед числом, 0=плюс перед числом, 1=минус перед числом, 4-первоначальная левая позиция, 5-первоначальная правая позиция числа
[HideInInspector]
public int cikle_CountOfNumbers1 = 0; // количество чисел
[HideInInspector]
public int[,] cikle_AllVariables1; // массив с переменными. [ порядковый номер переменной в тексте , 0..8 ]; // 0-левая позиция, 1-правая позиция переменной, 2-номер скобки в массиве "BracketStep" (-1) если нет скобок, 3-"в конце процедуры изменено значение на": позиция знака перед скобкой, 4- -3=обычный знак "-" перед переменной, -2=обычный знак "+" перед переменной, -1=нет меняющего знака перед переменной, 0=плюс перед переменной, 1=минус перед переменной, 5-номер переменной в массиве "NameVariables1", 6-первоначальная позиция левой переменной, 7-первоначальная позиция правой переменной, 8-первоначальная позиция знака перед переменной  
[HideInInspector]
public int cikle_CountOfVariables1 = 0; // количество переменных в тексте
[HideInInspector]
public float[] cikle_AllVariables_N; // массив с результатами переменных. [ порядковый номер переменной в тексте ]; // Чему равна переменная
[HideInInspector]
public int[,] cikle_BracketStep; // массив с позициями скобок. [ порядковый номер пар скобок , 0..12 ]; // 0-позиция левой скобки, 1-позиция правой скобки, 2-тип скобки (0-круглые, 1-модуль, 2-квадратные, 3-полукруглые, 4-дополнительные), 3-позиция знака перед скобкой, 4- -3=обычный знак "-" перед скобкой, -2=обычный знак "+" перед скобкой, -1=нет меняющего знака перед скобкой, 0=плюс перед скобкой, 1=минус перед скобкой, 5- номер переменной "AllVariables1" для данных скобок (-1 если нет переменной), 6-кол-во запятых внутри выбранных скобок, 7-к какой скобке относится эта часть (-1=не связано с запятыми), 8-первоначальная позиция левой скобки, 9-первоначальная позиция правой скобки, 10-первоначальная позиция знака перед собкой, 11-Если дополненная скобка, то номер первоначальной скобки в которой находится данная скобка, иначе -1, 12-номер скобки в которой находится данная скобка, 13-номер действия в массиве "AllActions"
[HideInInspector]
public int cikle_CountBracket = 0; // количество пар скобок
[HideInInspector]
public int cikle_CountAddBracket = 0; // количество добавленных пар скобок
[HideInInspector]
public float[] cikle_BracketStep_N; // массив с результатами в скобках. [ порядковый номер пар скобок ]; // Чему равны действия в скобках
[HideInInspector]
public string[] cikle_BracketStep_T; // массив с текстом действий в скобках. [ порядковый номер пар скобок ]; // Текст с действием в скобках
[HideInInspector]
public int[,] cikle_AllActions; // массив с позициями действий в тексте. [ порядковый номер действия, 0..15 ]; // 0= Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой", 1= Порядковый номер левого знака (-1 если нет знака), 2= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 3= Порядковый номер левого числа, переменной, или скобок (образует диапазон от), 4= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 5= Порядковый номер левого числа, переменной, или скобок (образует диапазон до), 6= Порядковый номер знака, 7= Порядковый номер правого знака (-1 если нет знака), 8= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 9= Порядковый номер правого числа, переменной, или скобок, 10= левая позиция в дополненном тексте, 11= правая позиция в допоненном тексте, 12= позиция знака в дополненном тексте, 13= левая позиция в основном тексте, 14= правая позиция в основном тексте, 15= позиция знака в основном тексте
[HideInInspector]
public int cikle_CountOfActions = 0; // количество всех действий
[HideInInspector]
public float[,] cikle_AllActions_N; // массив с результатами действий. [ порядковый номер действия, 0..2 ]; // 0= Результат левого числа, переменной или скобки действия, 1= Результат правого числа, переменной или скобки действия, 2= Результат выполненного действия
[HideInInspector]
public string[] cikle_AllActions_T; // массив с текстом действий. [ порядковый номер действия ]; // Текст с действием
// AllActions - массив с позициями действий в тексте. [ порядковый номер действия ]; // 0= Тип действия: 0-"+" 1-"-" 2-"*" 3-"/" 4-"^", 5-"(", 6-"|", 7-"[", 8-"{", 9-"Дополненная скобка", 10-"Переменная со скобкой", 1= Порядковый номер левого знака (-1 если нет знака), 2= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 3= Порядковый номер левого числа, переменной, или скобок (образует диапазон от), 4= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 5= Порядковый номер левого числа, переменной, или скобок (образует диапазон до), 6= Порядковый номер знака, 7= Порядковый номер правого знака (-1 если нет знака), 8= Тип символа: 0-число, 1-переменная, 2-скобки, 3-перменная со скобками, 9= Порядковый номер правого числа, переменной, или скобок, 10= левая позиция в дополненном тексте, 11= правая позиция в допоненном тексте, 12= позиция знака в дополненном тексте, 13= левая позиция в основном тексте, 14= правая позиция в основном тексте, 15= позиция знака в основном тексте
// CountOfActions - количество всех действий
// AllActions_N - массив с результатами действий. [ порядковый номер действия ]; // 0= Результат левого числа, переменной или скобки действия, 1= Результат правого числа, переменной или скобки действия, 2= Результат выполненного действия
// AllActions_T - массив с текстом действий в тексте. [ порядковый номер действия ]; // Текст с действием
////////////////////////////////////////////////////////////////////////


public float cikle_SolveFormulaProcedure() { // Цикл решений формулы

	cikle_Text_Formula2 = ListView1.TextField_1 [0];

	Formula1.CleanVariables = ListView1.Show_Hide [5]; // true = Убирать из текста лишние символы

	Formula1.CleanSpaces = ListView1.Show_Hide [6]; // true = Убирать пробелы

	Formula1.ChangeMainFormula = ListView1.Show_Hide [4]; // true - Менять основную формулу

	if (ListView1.Show_Hide [7]==true) { // true - Учитывать регистр названия переменной
		Formula1.CheckRegistr = 0; // 0 - учитывать (A<>a, B=B), 1 - не учитывать (A=a, B=B) регистр символов
	} else {
		Formula1.CheckRegistr = 1; // 0 - учитывать (A<>a, B=B), 1 - не учитывать (A=a, B=B) регистр символов
	}

	string cikle_sClean = ""; // текст с исправленной формулой

	/*if (ListView1.Show_Hide [4] == true) { // true - Менять основную формулу
		Text_Formula = cikle_sClean;
		Text_Formula2 = cikle_sClean;
		ListView1.TextField_1 [0] = cikle_sClean;
	}		

	cikle_Text_Formula = cikle_Text_Formula2; // *Не обязательно*
	cikle_Text_Formula_ch2 = cikle_Text_Formula_ch; // *Не обязательно*
*/
	/*cikle_ShowPosInBracketAction (); // Определить позиции действий "PosOfBracketAction" в тексте "Text_Action"

	ListView1.TextField_1 [0] = cikle_Text_Formula;
	ListView1.TextField_1 [1] = cikle_Text_Formula_ch;
	ListView1.TextField_1 [2] = cikle_Text_Action;

	ListView1.ChangeRowsInTable (1, cikle_CountOfActions); // Поменять количество рядов "CountRows1", в таблице "LViewSelected1"	

	cikle_MakeTextWithActions (); // Собрать массив с текстом из "AllActions"
	ListView1.AddActionsInTable2 (); // Добавить массив с текстом действий в формате уменьшения основной формулы в таблицу

	ListView1.ChangeHeightOfTF (0, cikle_Text_Formula); // Поменять размер текстового поля "TFSelected1", под текст "TextInField1"
	ListView1.ChangeHeightOfTF (1, cikle_Text_Formula_ch); // Поменять размер текстового поля "TFSelected1", под текст "TextInField1"	
	ListView1.ChangeHeightOfTF (2, cikle_Text_Action); // Поменять размер текстового поля "TFSelected1", под текст "TextInField1"
*/
	Formula1.FindResultOnly = true; // false - будет изменен текст и сопутствующие позиции, true - текст и позиции не меняются

	return Formula1.SolveFormula (cikle_Text_Formula2 
		, out cikle_sClean
		, out cikle_Text_Formula_ch, out cikle_Text_Action, out cikle_Text_Property
		, out cikle_AllSymbols1, out cikle_CountOfSymbols1
		, out cikle_CountOfUnActSymbols1, out cikle_CountOfCommas1
		, out cikle_AllNumbers1, out cikle_CountOfNumbers1
		, out cikle_AllVariables1, out cikle_CountOfVariables1
		, out cikle_AllVariables_N
		, out cikle_BracketStep, out cikle_CountBracket, out cikle_CountAddBracket
		, out cikle_BracketStep_N
		, out cikle_BracketStep_T
		, out cikle_AllActions, out cikle_CountOfActions
		, out cikle_AllActions_N
		, out cikle_AllActions_T); // Решить формулу из текста	;
}



}